<?php

/*
	插件安装文件
*/

!defined('DEBUG') AND exit('Forbidden');


?>