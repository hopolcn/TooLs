<?php

!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	

	$setting['ADopen'] = setting_get('ADopen');
	$setting['ADimg'] = setting_get('ADimg');
	$setting['ADurl'] = setting_get('ADurl');

	
	include _include(APP_PATH.'plugin/a8c5_footer_AD/setting.htm');
	
} else {

	setting_set('ADopen', param('ADopen', '', FALSE));
	setting_set('ADimg', param('ADimg', '', FALSE));
	setting_set('ADurl', param('ADurl', '', FALSE));

	message(0, '修改成功');
}
	
?>