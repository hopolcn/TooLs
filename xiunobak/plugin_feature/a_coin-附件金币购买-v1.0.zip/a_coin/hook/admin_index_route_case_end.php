case 'part_log': include APP_PATH.'plugin/a_coin/part_log.php'; break;
