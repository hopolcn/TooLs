'__user_notice__' => '通知',
'__search__' => '搜索（链接）',
'__search_box__' => '搜索框',
'__btn_search__' => '搜索按钮',