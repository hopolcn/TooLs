<?php
!defined('DEBUG') and exit('Forbidden');
if (function_exists("xn_nav_menu_slot_add")) {
    xn_nav_menu_slot_add('appbar_menu', array(
        array('lid' => 1, 'icon' => 'icon-home', 'name' => '首页', 'title' => '', 'href' => '.', 'order' => 1, 'class' => '', 'submenu' => ''),
        array('lid' => 2, 'icon' => 'icon-comments-o', 'name' => '分类', 'title' => '', 'href' => '#', 'order' => 2, 'class' => '', 'attr' => "data-toggle='modal' data-target='#forum'", 'submenu' => ''),
        array('lid' => 3, 'icon' => 'icon-plus', 'name' => ' ', 'title' => '发帖', 'href' => '__btn_thread_new__', 'order' => 3, 'class' => 'big_button', 'submenu' => ''),
        array('lid' => 4, 'icon' => 'icon-plus', 'name' => ' ', 'title' => '登录', 'href' => '__btn_login__', 'order' => 3, 'class' => 'big_button', 'submenu' => ''),
        array('lid' => 5, 'icon' => 'icon-bell-o', 'name' => '消息', 'title' => '', 'href' => '__user_notice__', 'order' => 4, 'class' => '', 'submenu' => ''),
        array('lid' => 6, 'icon' => 'icon-user', 'name' => '我', 'title' => '', 'href' => 'my.htm', 'order' => 5, 'class' => '', 'submenu' => ''),
    ));
}