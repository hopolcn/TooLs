<?php
!defined('DEBUG') and exit('Forbidden');
if (function_exists("xn_nav_menu_slot_add")) {
    xn_nav_menu_slot_add('friendlink', array(
        array(
            'lid' => 1,
            'icon' => 'view/img/logo.png',
            'name' => 'Xiuno BBS',
            'desc' => 'GitHub 存储库',
            'href' => 'https://github.com/jiix/xiunobbs',
            'order' => 0,
            'class' => '',
            'submenu' => '',
        ),
    ));
}