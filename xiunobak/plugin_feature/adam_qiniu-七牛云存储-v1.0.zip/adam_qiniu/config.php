<?php
        return array(
            'bucket' => '七牛bucket名称',
            'accessKey' => 'ak',
            'secretKey' => 'sk',
            'cdnurl' => '上传url',
        );