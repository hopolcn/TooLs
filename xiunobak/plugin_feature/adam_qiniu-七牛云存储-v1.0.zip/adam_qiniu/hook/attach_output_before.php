
$type='adam_qiniu';