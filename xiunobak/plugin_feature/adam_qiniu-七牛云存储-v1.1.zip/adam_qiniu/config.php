<?php

return array(
    'accessKey' => 'ak',
    'secretKey' => 'sk',
    'bucket' => 'bucket',
    'cdnurl' => '七牛绑定的域名',
);