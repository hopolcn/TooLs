
$type='adam_qiniu';