<?php

return array(
    'accessKey' => '',
    'secretKey' => '',
    'bucket' => '',
    'cdnurl' => '',
);