<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;

$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}advertisement (
  `adid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '广告id',
  `available` tinyint(1) NOT NULL COMMENT '是否启用',
  `type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '类型',
  `displayorder` tinyint(3) NOT NULL COMMENT '显示顺序',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '广告标题',
  `parameters` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '参数 序列化存放的数组数据',
  `code` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '代码',
  `starttime` int(10) UNSIGNED NOT NULL COMMENT '开始时间',
  `endtime` int(10) UNSIGNED NOT NULL COMMENT '结束时间',
  PRIMARY KEY (`adid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8";

$r = db_exec($sql);
?>