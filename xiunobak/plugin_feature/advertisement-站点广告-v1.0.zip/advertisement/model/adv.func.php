<?php
function adv_type($type) {
	$adv__type = db_find('advertisement', array('type'=>$type,'available'=>'1'),array('displayorder'=>1));
	return $adv__type;
}
function form_date($name, $value, $width = FALSE, $holdplacer = '') {
	$style = '';
	if($width !== FALSE) {
		is_numeric($width) AND $width .= 'px';
		$style = " style=\"width: $width\"";
	}
	$s = "<input type=\"date\" name=\"$name\" id=\"$name\" placeholder=\"$holdplacer\" value=\"$value\" class=\"form-control\"$style />";
	return $s;
}
function adv__read($adid) {
	$adv = db_find_one('advertisement', array('adid'=>$adid));
	return $adv;
}
function adv_read($adid) {
	if(empty($adid)) return array();
	$adv = adv__read($adid);
	return $adv;
}

function adv__create($arr) {
	$r = db_insert('advertisement', $arr);
	return $r;
}
function adv_create($arr) {
	global $conf;
	$r = adv__create($arr);
	return $r;
}
function adv__update($adid, $arr) {
	$r = db_update('advertisement', array('adid'=>$adid), $arr);
	return $r;
}
function adv_update($adid, $arr) {
	$r = adv__update($adid, $arr);
	return $r;
}
function adv__delete($adid) {
	$r = db_delete('advertisement', array('adid'=>$adid));
	return $r;
}
function adv_delete($adid) {
	$r = adv__delete($adid);
	return $r;
}
?>