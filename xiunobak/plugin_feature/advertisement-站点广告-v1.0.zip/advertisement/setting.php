<?php !defined('DEBUG') AND exit('Access Denied.');
$action = param(3);
if(empty($action)){
    if($method == 'GET') {
		function adv_count($type) {
			$n = db_count('advertisement',array('type'=>$type));
			return $n;
		}
        include _include(APP_PATH . 'plugin/advertisement/setting.htm');
    }elseif($method=='POST'){
		
    }
}elseif($action && $action != 'update' && $action != 'create' && $action != 'delete'){
    if($method == 'GET') {
		$pagesize = 10;
		$page = param(4, 1);
		if($action == 'list'){
			$count = db_count('advertisement',array());
			$adlist = db_find('advertisement',array(),array('displayorder'=>1), $page, $pagesize);
			$pagination = pagination(url("plugin-setting-advertisement-list-{page}"), $count, $page, $pagesize);
		}else{
			$count = db_count('advertisement',array('type'=>$action));
			$adlist = db_find('advertisement',array('type'=>$action),array('displayorder'=>1), $page, $pagesize);
			$pagination = pagination(url("plugin-setting-advertisement-$action-{page}"), $count, $page, $pagesize);
			
		}
        include _include(APP_PATH . 'plugin/advertisement/list.htm');
    }elseif($method=='POST'){
		$displayorder = param('displayorder', array(0));
		foreach($displayorder as $k=>$v) {
			$arr = array(
				'adid'=>$k,
				'displayorder'=>array_value($displayorder, $k)
			);
			adv_update($k, $arr);
		}
		message(0, lang('save_successfully'));
    }
}elseif($action == 'create'){
	$_type = param(4);
    if($method == 'GET') {
		$input['available'] = form_radio_yes_no('available', $adlist['available']);
		$input['title'] = form_text('title', '');
		$input['starttime'] = form_date('starttime', '');
		$input['endtime'] = form_date('endtime', '');
		$input['advnew'] = form_radio('advnew[style]', array('code'=>'代码','text'=>'文字','image'=>'图片'),'');
		$input['code'] = form_textarea('code', '', '100%', 80);
        include _include(APP_PATH . 'plugin/advertisement/create.htm');
    }elseif($method=='POST'){
		$_type = param(4);
		$available = param('available',0);
		$title = param('title');
		$starttime = strtotime(param('starttime'));
		$endtime = strtotime(param('endtime'));
		$advnew = param('advnew');
		$code = param('code', '', FALSE);
		
		$parameters = serialize(array($_type,$available,$title,$starttime,$endtime,$advnew,$code));
		$r = adv_create(array(
			'available'=>$available,
			'type'=>$_type,
			'displayorder'=>0,
			'title'=>$title,
			'parameters'=>$parameters,
			'code'=>$code,
			'starttime'=>$starttime,
			'endtime'=>$endtime
		));
		message(0, lang('create_successfully'));
    }
}elseif($action == 'update'){
	$_adid = param(4, 0);
    if($method == 'GET') {
		$adlist = adv__read($_adid);
		$input['available'] = form_radio_yes_no('available', $adlist['available']);
		$input['title'] = form_text('title', $adlist['title']);
		$input['starttime'] = form_date('starttime', $adlist['starttime'] ? date('Y-m-d',$adlist['starttime']) : $adlist['starttime']);
		$input['endtime'] = form_date('endtime', $adlist['endtime'] ? date('Y-m-d',$adlist['endtime']) : $adlist['endtime']);
		$input['advnew'] = form_radio('advnew', array('code'=>'代码','text'=>'文字','image'=>'图片'),'');
		$input['code'] = form_textarea('code', $adlist['code'], '100%', 80);
        include _include(APP_PATH . 'plugin/advertisement/update.htm');
    }elseif($method=='POST'){
		$_adid = param(4, 0);
		$available = param('available',0);
		$title = param('title');
		$starttime = strtotime(param('starttime'));
		$endtime = strtotime(param('endtime'));
		$advnew = param('advnew');
		$code = param('code', '', FALSE);
		$advold = adv_read($_adid);
		$parameters = serialize(array($available,$title,$starttime,$endtime,$advnew,$code));
		
		$arr = array();
		$arr['available'] = $available;
		$arr['title'] = $title;
		$arr['starttime'] = $starttime;
		$arr['endtime'] = $endtime;
		$arr['parameters'] = $parameters;
		$arr['code'] = $code;
		
		$update = array_diff_value($arr, $advold);
		adv_update($_adid, $update);
		message(0, lang('update_successfully'));
    }
}elseif($action == 'delete'){
	if($method != 'POST') message(-1, 'Method Error.');
	$_advid = param('advid', 0);
	
	$_adv = adv_read($_advid);
	empty($_adv) AND message(-1, '广告不存在');
	
	$r = adv_delete($_advid);
	$r === FALSE AND message(-1, lang('delete_failed'));
	message(0, lang('delete_successfully'));
}

?>