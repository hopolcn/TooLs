<?php

!defined('DEBUG') AND exit('Forbidden');


$ap['aplayer'] = '
	<!--请自行阅读官方文档后进行配置。此处初始化默认为MetingJS，server处填写音乐服务器名（netease, tencent, kugou, xiami, baidu），id填写自己在当前音乐服务器创建的歌单、单曲等id（song id / playlist id / album id / search keyword）-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="plugin/airh_aplayer/aplayer/APlayer.min.css" rel="stylesheet">
	<script src="plugin/airh_aplayer/aplayer/APlayer.min.js"></script>
	<script src="plugin/airh_aplayer/aplayer/Meting.min.js"></script>
	<div id="aplayer"></div>
	<meting-js
	    server="netease" 
	    type="playlist" 
	    id="60198" 
	    fixed="ture"
	    volume="0.1" 
	    mini="true">
	</meting-js>
';
kv_set('airh_aplayer', $ap);

?>