<?php
!defined('DEBUG') AND exit('Access Denied.');
if ($method == 'GET') {
    $ap = kv_get('airh_aplayer');

    $aplayer = $ap['aplayer'];
 
    include _include(APP_PATH . 'plugin/airh_aplayer/setting.htm');
	
} else {

    $aplayer = param('aplayer');
    $ap['aplayer'] = $aplayer;

    kv_set('airh_aplayer', $ap);
    message(0, '提交成功！');
}
