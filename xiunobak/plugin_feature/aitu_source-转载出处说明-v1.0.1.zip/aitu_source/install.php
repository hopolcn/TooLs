<?php

!defined('DEBUG') and exit('Forbidden');
$tablepre = $db->tablepre;
$sql = "ALTER TABLE {$tablepre}post ADD COLUMN source VARCHAR(255) NOT NULL DEFAULT '' COMMENT '转载出处'";
$r = db_exec($sql);

$r === false and message(-1, '创建表结构失败，请检查数据库是否已存在相同source字段。');