<?php
exit;
$get_signature = kv_get('user_signature');
?>