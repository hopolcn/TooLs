# ass_push
xiuno新帖推送插件
使用说明：https://www.sjfn.com/post-2.html
