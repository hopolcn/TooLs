case 'sx': include _include(APP_PATH.'plugin/ax_notice_sx/route/sx.php'); break;



