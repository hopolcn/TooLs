<?php

/*
	QQ:1446342488
  网站搭建、开发、维护，欢迎联系！
*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}xzad_img (
  `adid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imgurl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `style` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `sort` int(255) NOT NULL DEFAULT '0',
  `status` int(255) NOT NULL DEFAULT '1',
  PRIMARY KEY (`adid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
";
$r = db_exec($sql);

$sql = "INSERT INTO {$tablepre}xzad_img(`adid`, `name`, `imgurl`, `url`, `style`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (1, '08娱乐网', 'xxx', 'https://www.08ylw.top/', '', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1);
";

$r = db_exec($sql);
?>