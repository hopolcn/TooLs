<?php

/*
	QQ:1446342488
  网站搭建、开发、维护，欢迎联系！
*/


!defined('DEBUG') AND exit('Access Denied.');

$xz_v = '1.3';
$xz_time = time();//实时更新

$action = param(3);

if(empty($action)) {
	
	$adlist = db_find('xzad_img', array(), array('sort'=>-1), 1, 1000, 'adid');
	$maxid = db_maxid('xzad_img', 'adid');
	// print_r($maxid);
	
	if($method == 'GET') {
		include _include(APP_PATH.'plugin/axz_ad_img/setting.htm');
	} else {
		$arr_adid = param('adid', array(0));
		$name = param('name', array(''));
		$imgurl = param('imgurl', array(''));
		$url = param('url', array(''));
		$style = param('style', array(''));
		$starttime = param('starttime', array(''));
		$endtime = param('endtime', array(''));
		$sort = param('sort', array(0));
		
		$arrlist = array();
		foreach($arr_adid as $k=>$v) {
			if(empty($name[$k]) && empty($imgurl[$k])) continue;
			$arr = array(
				'adid'=>$k,
				'name'=>$name[$k],
				'imgurl'=>$imgurl[$k],
				'url'=>$url[$k],
				'style'=>$style[$k],
				'starttime'=>$starttime[$k],
				'endtime'=>$endtime[$k],
				'sort'=>$sort[$k],
			);
			if(!isset($adlist[$k])) {
				db_create('xzad_img', $arr);
			} else {
				db_update('xzad_img', array('adid'=>$k), $arr);
			}
		}
		
		// 删除
		$deletearr = array_diff_key($adlist, $arr_adid);
		foreach($deletearr as $k=>$v) {
			db_delete('xzad_img', array('adid'=>$k));
		}
		
		message(0, '保存成功');
	}
}
?>