<?php

/*
	QQ:1446342488
  网站搭建、开发、维护，欢迎联系！
*/


!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$sql = "DROP TABLE IF EXISTS {$tablepre}xzad_img;";

$r = db_exec($sql);
$r === FALSE AND message(-1, '卸载A.XZ文字广告位失败');

?>