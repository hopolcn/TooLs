<?php

/*
	QQ:1446342488
  网站搭建、开发、维护，欢迎联系！
*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}xzad (
  `adid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ico` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bgcolor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `sort` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(255) DEFAULT '1',
  PRIMARY KEY (`adid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
";
$r = db_exec($sql);

$sql = "INSERT INTO {$tablepre}xzad(`adid`, `title`, `url`, `ico`, `color`, `bgcolor`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (1, '08娱乐网', 'https://www.08ylw.top/', '', '#d3e8fc', '#007ef7', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '9', 1);
INSERT INTO {$tablepre}xzad(`adid`, `title`, `url`, `ico`, `color`, `bgcolor`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (2, '薅羊毛/线报小程序', 'https://www.08ylw.top/thread-8546.htm', '', '#fd5f78', '#fcdcdc', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 1);
INSERT INTO {$tablepre}xzad(`adid`, `title`, `url`, `ico`, `color`, `bgcolor`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (3, 'PDF文档转换器', 'https://www.08ylw.top/thread-8518.htm', '', '', '0', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '3', 1);
INSERT INTO {$tablepre}xzad(`adid`, `title`, `url`, `ico`, `color`, `bgcolor`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (4, '文档转换器', 'https://www.08ylw.top/thread-8518.htm', '', '', '0', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 1);
INSERT INTO {$tablepre}xzad(`adid`, `title`, `url`, `ico`, `color`, `bgcolor`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (5, '测试一', '/', '', '', '0', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 1);
INSERT INTO {$tablepre}xzad(`adid`, `title`, `url`, `ico`, `color`, `bgcolor`, `addtime`, `starttime`, `endtime`, `sort`, `status`) VALUES (6, '测试二', '/', '', '', '', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 1);

";

$r = db_exec($sql);
?>