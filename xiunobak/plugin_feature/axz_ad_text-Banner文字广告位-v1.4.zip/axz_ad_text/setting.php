<?php

/*
	QQ:1446342488
  网站搭建、开发、维护，欢迎联系！
*/


!defined('DEBUG') AND exit('Access Denied.');

$xz_v = '1.4';
$xz_time = time();//实时更新

$action = param(3);
if(empty($action)) {
	
	$adlist = db_find('xzad', array(), array('sort'=>-1), 1, 1000, 'adid');
	$maxid = db_maxid('xzad', 'adid');
	// print_r($maxid);
	
	if($method == 'GET') {
		include _include(APP_PATH.'plugin/axz_ad_text/setting.htm');
	} else {
		$arr_adid = param('adid', array(0));
		$title = param('title', array(''));
		$url = param('url', array(''));
		$ico = param('ico', array(''));
		$color = param('color', array(''));
		$bgcolor = param('bgcolor', array(''));
		$starttime = param('starttime', array(''));
		$endtime = param('endtime', array(''));
		$sort = param('sort', array(0));
		
		$arrlist = array();
		foreach($arr_adid as $k=>$v) {
			if(empty($title[$k]) && empty($url[$k])) continue;
			$arr = array(
				'adid'=>$k,
				'title'=>$title[$k],
				'url'=>$url[$k],
				// 'ico'=>$ico[$k],
				'url'=>$url[$k],
				'color'=>$color[$k],
				'bgcolor'=>$bgcolor[$k],
				// 'starttime'=>$starttime[$k],
				// 'endtime'=>$endtime[$k],
				'sort'=>$sort[$k],
			);
			if(!isset($adlist[$k])) {
				db_create('xzad', $arr);
			} else {
				db_update('xzad', array('adid'=>$k), $arr);
			}
		}
		
		// 删除
		$deletearr = array_diff_key($adlist, $arr_adid);
		foreach($deletearr as $k=>$v) {
			db_delete('xzad', array('adid'=>$k));
		}
		
		message(0, '保存成功');
	}
}
?>