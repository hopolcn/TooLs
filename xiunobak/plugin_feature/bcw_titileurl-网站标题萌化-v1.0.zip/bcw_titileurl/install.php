<?php

!defined('DEBUG') AND exit('Forbidden');

$setting = setting_get('bcw_titileurl_setting');
if(empty($setting)) {
	$setting = array('data_time'=>1000, 'data_title2'=>'(つェ?)我藏好了哦~ ', 'data_title1'=>'(*′?｀*) 被你发现啦~ ');
	setting_set('bcw_titileurl_setting', $setting);
}

?>