<?php

!defined('DEBUG') AND exit('Access Denied.');

$setting = setting_get('bcw_titileurl_setting');

if($method == 'GET') {
	
	include _include(APP_PATH.'plugin/bcw_titileurl/setting.htm');
	
} else {

	$setting['data_time'] = param('data_time', 1000);
	$setting['data_title2'] = param('data_title2', '');
	$setting['data_title1'] = param('data_title1', '');
	
	setting_set('bcw_titileurl_setting', $setting);
	
	message(0, '修改成功');
}
	
?>