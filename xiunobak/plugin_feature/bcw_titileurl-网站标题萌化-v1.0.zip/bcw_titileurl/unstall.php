<?php

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('bcw_titileurl_setting');

?>