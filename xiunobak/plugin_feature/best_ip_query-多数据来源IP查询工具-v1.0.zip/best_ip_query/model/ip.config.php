<?php
    //定义项目绝对路径，如果不清楚请先访问check.php获取
	$thedir = $_SERVER['DOCUMENT_ROOT'];
    define("APP", $thedir);
    //载入数据库类
    include_once('ip.medoo.php');
    //初始化Medoo
    use Medoo\Medoo;
    $database = new medoo([
        'database_type' => 'sqlite',
        'database_file' => $thedir.'/plugin/best_ip_query/model/ip.cache.db3'
    ]);
