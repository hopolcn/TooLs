<?php
    include_once('ip.config.php');
    include_once('ip.qqwry.php');
    include_once('ip.query.class.php');
    @$ip = htmlspecialchars($_GET['ip']);
    @$source = htmlspecialchars($_GET['source']);
    $query->delcache($ip, $source);
