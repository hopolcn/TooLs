<?php
    error_reporting(E_ALL^E_NOTICE^E_WARNING^E_DEPRECATED);
    /*
        查询所有IP数据
    */
    include_once('ip.config.php');
    include_once('ip.qqwry.php');
    include_once('ip.query.class.php');
    //获取IP
    @$ip = $_GET['ip'];

    //如果不是一个IP
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        //正则获取主机名
        $content = strtolower($ip);
        $content = trim($content);
        $content = str_replace('http://', '', $content);
        $content = str_replace('https://', '', $content);
        $content = str_replace('ftp://', '', $content);
        $pattern = '/^[0-9a-z]+[0-9a-z-\.]+\.[a-z]{2,6}/';
        preg_match($pattern, $content, $arr);
        $host = $arr[0];
        
        @$ip = gethostbyname($host);
        //如果没有解析出IP
        if ((!isset($ip)) || ($ip == '') || ($host == '')) {
            echo '<span class="my-4 alert alert-warning text-center d-block">URL格式不正确或者域名未绑定IP，所以未解析到正确的IP地址。</span>';
            exit;
        }
        //如果是正常的URL
        //if(filter_var($ip, FILTER_VALIDATE_URL)){
        //	$domain = parse_url($ip);
        //	$host = $domain['host'];
        //	@$ip = gethostbyname($host);
        //}
        //else{
        //	echo "<h1>不是有效的IP或URL！</h1>";
        //	exit;
        //}
    }

    //查询接口数据
    $ipip = $query->caches($ip, 'ipip');
    if ($ipip == null) {
        $ipip = $query->caches($ip, 'ipip');
    }
    $ipip = json_decode($ipip);
    

    $taobao = $query->caches($ip, 'taobao');
    if ($taobao == null) {
        $taobao = $query->caches($ip, 'taobao');
    }
    $taobao = json_decode($taobao);

    $geoip = $query->caches($ip, 'geoip');
    if ($geoip == null) {
        $geoip = $query->caches($ip, 'geoip');
    }
    $geoip = json_decode($geoip);

    $pure = $query->caches($ip, 'qqwry');
    if ($pure == null) {
        $pure = $query->caches($ip, 'qqwry');
    }
    $pure = json_decode($pure);

    //腾讯数据
    //判断是否启用了腾讯数据
    
    if (LBSQQ != '') {
        $lbsqq = $query->caches($ip, 'lbsqq');
        if ($lbsqq == null) {
            $lbsqq = $query->caches($ip, 'lbsqq');
        }
        $lbsqq = json_decode($lbsqq);
        $style = 'block';
    }
    //返回所有接口数据
?>
<div id = "allinfo">
<table class="table table-bordered bg-white">
  <thead>
    <tr>
		<th scope="col" colspan="3" id="allip" class="text-center">
		  <h4 class="mb-0">【<?php echo $ipip->ip; ?><?php if ($host != '') {echo '（'.$host.'）';}?>】 的查询结果</h4>
		</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row" class="text-right">淘宝</th>
      <td id="taobao"><?php echo $taobao->address; ?></td>
    </tr>
    <tr>
      <th scope="row" class="text-right">纯真</th>
      <td id="qqwry"><?php echo $pure->address; ?></td>
    </tr>
    <tr>
      <th scope="row" class="text-right">IPIP</th>
      <td id="ipip"><?php echo $ipip->address; ?></td>
    </tr>
    <tr>
      <th scope="row" class="text-right">IPAPI</th>
      <td id="ipapi"><?php echo $lbsqq->address; ?></td>
    </tr>
    <tr>
      <th scope="row" class="text-right">GeoIP</th>
      <td id="geoip"><?php echo $geoip->address; ?></td>
    </tr>
  </tbody>
</table>
</div>
