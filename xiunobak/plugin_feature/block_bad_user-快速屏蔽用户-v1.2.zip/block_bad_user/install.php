<?php
/*** @技术支持 一起smart https://www.iqismart.com***/
!defined('DEBUG') and exit('Forbidden');
$get_bad_user = kv_get('block_bad_user');
$settingurl= url('plugin-setting-block_bad_user');
if (!$get_bad_user) {
	$bad_user = array('mod1'=>'1','mod2'=>'1','mod3'=>'1','mod4'=>'1','mod5'=>'1','mod6'=>'1','blocktip'=>'该用户因违反社区规则被屏蔽，相关帖子内容被隐藏。');
	kv_set('block_bad_user', $bad_user);
	message(0, '<p>快速屏蔽安装成功，请进入设置对相关选项进行设定。</p> <a role="button" class="btn btn-info m-t-1" href="'.$settingurl.'">进入设置</a> <a role="button" class="btn btn-secondary m-t-1" href="javascript:history.back();">返回前一页</a>');
} else {
	message(-1, '<p>您已安装过 快速屏蔽 插件了。</p> <a role="button" class="btn btn-info m-t-1" href="'.$settingurl.'">直接进入设置</a> <a role="button" class="btn btn-secondary m-t-1" href="javascript:history.back();">返回前一页</a>');
}