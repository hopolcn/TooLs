<?php exit; //assbbs.com
case 'c_tinymce_save':
//sleep(6); //测试用模拟慢速上传
$c_tinymce_file=array('user'=>G('uid'),'mode'=>c_tinymce_mode(empty($_GET['act'])?'':$_GET['act']),'time'=>sprintf('%.0f',microtime(true)*1000));
if(empty($c_tinymce['tinymce']) || empty($c_tinymce_file['mode']) || empty($c_tinymce[G('gid').'_'.$_GET['act'].'_size'])){die('{"shit":"auth"}');}
if(!empty($c_tinymce[G('gid').'_'.$_GET['act'].'_amount'])){
$c_tinymce_file_head=db_sql_find_one('SELECT `time` FROM `'.$db->tablepre.'c_tinymce_file` WHERE `user`='.$c_tinymce_file['user'].' AND `mode`='.$c_tinymce_file['mode'].' ORDER BY `time` DESC LIMIT '.($c_tinymce[G('gid').'_'.$_GET['act'].'_amount']-1).',1');
if($c_tinymce_file_head && (empty($c_tinymce[G('gid').'_'.$_GET['act'].'_interval']) || ($c_tinymce_file['time']-$c_tinymce_file_head['time'])<$c_tinymce[G('gid').'_'.$_GET['act'].'_interval']*60000)){die('{"shit":"over"}');}
}
if(empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name']) || $_FILES['file']['error']>0 || $_FILES['file']['size']<12){die('{"shit":"file"}');}
$c_tinymce_file['size']=$_FILES['file']['size'];
if($c_tinymce_file['size']>$c_tinymce[G('gid').'_'.$_GET['act'].'_size']*1048576){die('{"shit":"size"}');}
$c_tinymce_file['type']=null;
if($_GET['act']=='image'){$type=getimagesize($_FILES['file']['tmp_name']);$type=$type['mime'];}
elseif($_GET['act']=='media' && extension_loaded('fileinfo')){$type=mime_content_type($_FILES['file']['tmp_name']);}
else{$type=strrchr($_FILES['file']['name'],'.');}
foreach((($_GET['act']=='media')?array_merge($c_tinymce['video_use'],$c_tinymce['audio_use']):$c_tinymce[$_GET['act'].'_use']) as $key=>$row){
if(in_array($type,explode(',',$row))){$c_tinymce_file['type']=$key;}
}
if(!$c_tinymce_file['type']){die('{"shit":"type"}');}
$c_tinymce_file['zone']=0; //上传到本地
$c_tinymce_file['date']=date('Ym');
if(db_exec('CREATE TABLE IF NOT EXISTS `'.$db->tablepre.'c_tinymce_file` ( `user` int(11) unsigned NOT NULL, `time` bigint(13) unsigned NOT NULL, `date` varchar(10) COLLATE utf8_unicode_ci NOT NULL, `zone` tinyint(3) unsigned NOT NULL, `mode` tinyint(1) unsigned NOT NULL, `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL, `size` bigint(13) unsigned NOT NULL, `used` int(11) unsigned NOT NULL, UNIQUE KEY `user_mode_time` (`user`,`mode`,`time`), KEY `used_time` (`used`,`time`) ) ENGINE='.$db->rconf['engine'].' DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; INSERT INTO `'.$db->tablepre.'c_tinymce_file` SET `user`='.$c_tinymce_file['user'].',`date`="'.$c_tinymce_file['date'].'",`time`='.$c_tinymce_file['time'].',`zone`='.$c_tinymce_file['zone'].',`mode`='.$c_tinymce_file['mode'].',`type`="'.$c_tinymce_file['type'].'",`size`='.$c_tinymce_file['size'].',`used`=0;')===false){die('{"shit":"data"}');}
if(!is_dir('upload/attach/'.$c_tinymce_file['date']) && !mkdir('upload/attach/'.$c_tinymce_file['date'],0755,true)){die('{"shit":"path"}');}
if(!file_exists($_FILES['file']['tmp_name']) || !move_uploaded_file($_FILES['file']['tmp_name'],'upload/attach/'.$c_tinymce_file['date'].'/'.$c_tinymce_file['user'].'_'.$c_tinymce_file['time'].'.'.$c_tinymce_file['type'])){die('{"shit":"move"}');}
die('{"shit":"done","zone":"'.$c_tinymce_file['zone'].'","date":"'.$c_tinymce_file['date'].'","user":"'.$c_tinymce_file['user'].'","time":"'.$c_tinymce_file['time'].'","type":"'.$c_tinymce_file['type'].'"}');
break;
case 'c_tinymce_auth':
$c_tinymce_file=array('user'=>G('uid'),'mode'=>c_tinymce_mode(empty($_GET['act'])?'':$_GET['act']),'time'=>sprintf('%.0f',microtime(true)*1000));
if(empty($c_tinymce['tinymce']) || empty($c_tinymce_file['mode']) || empty($c_tinymce[G('gid').'_'.$_GET['act'].'_size'])){die('{"shit":"auth"}');}
if(!empty($c_tinymce[G('gid').'_'.$_GET['act'].'_amount'])){
$c_tinymce_file_head=db_sql_find_one('SELECT `time` FROM `'.$db->tablepre.'c_tinymce_file` WHERE `user`='.$c_tinymce_file['user'].' AND `mode`='.$c_tinymce_file['mode'].' ORDER BY `time` DESC LIMIT '.($c_tinymce[G('gid').'_'.$_GET['act'].'_amount']-1).',1');
if($c_tinymce_file_head && (empty($c_tinymce[G('gid').'_'.$_GET['act'].'_interval']) || ($c_tinymce_file['time']-$c_tinymce_file_head['time'])<$c_tinymce[G('gid').'_'.$_GET['act'].'_interval']*60000)){die('{"shit":"over"}');}
}
die('{"shit":"done"}');
break;
case 'c_tinymce_jump':
if(!$c_tinymce['jumplast'] || empty($_GET['shit'])){die;}
$shit=thread__read(intval($_GET['shit']));
if(!$shit){die;}
$last=ceil(($shit['posts']+1)/$conf['postlist_pagesize']);
if(isset($_GET['suck'])){header('Location:'.url('thread-'.$shit['tid'].'-'.$last).'#jumplast');}
else{echo $last;}
break;
?>