<?php exit; //assbbs.com
$c_tinymce=kv_get('c_tinymce');
$c_tinymce=array_merge(array(
	'prism_theme'=>array(
		'prism'=>'Default', 
		'prism-dark'=>'Dark', 
		'prism-funky'=>'Funky', 
		'prism-okaidia'=>'Okaidia', 
		'prism-twilight'=>'Twilight', 
		'prism-coy'=>'Coy', 
		'prism-solarizedlight'=>'Solarized Light', 
		'prism-tomorrow'=>'Tomorrow Night', 
	), 
	'prism_plugin'=>array(
		'line-highlight'=>'Line Highlight',
		'line-numbers'=>'Line Numbers',
		'show-invisibles'=>'Show Invisibles', 
		'autolinker'=>'Autolinker', 
		'wpd'=>'WebPlatform Docs', 
		'custom-class'=>'Custom Class', 
		'file-highlight'=>'File Highlight', 
		'jsonp-highlight'=>'JSONP Highlight', 
		'highlight-keywords'=>'Highlight Keywords', 
		'remove-initial-line-feed'=>'Remove initial line feed', 
		'inline-color'=>'Inline color', 
		//'previewers'=>'Previewers', 
		'autoloader'=>'Autoloader', 
		'keep-markup'=>'Keep Markup', 
		'command-line'=>'Command Line', 
		'unescaped-markup'=>'Unescaped Markup', 
		'normalize-whitespace'=>'Normalize Whitespace', 
		'data-uri-highlight'=>'Data-URI Highlight', 
		'toolbar'=>'Toolbar', 
		'copy-to-clipboard'=>'Copy to Clipboard Button', 
		'download-button'=>'Download Button', 
		'show-language'=>'Show Language', 
		'match-braces'=>'Match braces', 
		'diff-highlight'=>'Diff Highlight', 
		'filter-highlight-all'=>'Filter highlightAll', 
		'treeview'=>'Treeview', 
	), 
	'image'=>array(
		'gif'=>'.gif,image/gif',
		'jpg'=>'.jpg,.jpeg,image/jpeg,image/pjpeg',
		'png'=>'.png,image/png,image/x-png',
		'bmp'=>'.bmp,.dib,image/bmp,image/x-ms-bmp',
		'ico'=>'.ico,.cur,image/icon,image/x-icon,image/vnd.microsoft.icon',
		'webp'=>'.webp,image/webp',
	),
	'video'=>array(
		'mp4'=>'.mp4,.m4v,.mp4v,video/mp4,video/m4v,video/x-m4v',
		'mov'=>'.mov,.qtm,.qt,video/quicktime,video/x-quicktime',
		'ogv'=>'.ogv,.ogg,.ogx,.ogm,video/ogg',
		'webm'=>'.webm,video/webm',
	),
	'audio'=>array(
		'm4a'=>'.m4a,.mp4a,audio/mp4,audio/m4a,audio/x-m4a',
		'aac'=>'.aac,.adts,audio/aac,audio/x-aac,audio/hx-aac-adts,audio/x-hx-aac-adts',
		'oga'=>'.oga,.spx,.opus,audio/ogg',
		'weba'=>'.weba,audio/webm',
		'wav'=>'.wav,audio/wav,audio/wave,audio/x-wav,audio/x-pn-wav',
		'mp3'=>'.mp3,audio/mpeg,audio/x-mpeg',
		'flac'=>'.flac,audio/flac,audio/x-flac',
	),
),($c_tinymce?$c_tinymce:array()));
function c_tinymce_mode($act){
switch($act){
case 'image':return 1;break;
case 'media':return 2;break;
default:return 0;break;
}
};
function c_tinymce_sync($oldhtml,$newhtml,$pid=0,$tid=0){
global $db,$c_tinymce;
$olditem=$oldhtml?(preg_match_all('/\"upload\/attach\/[\w\/]+\/([\d]+_[\d]{13})\./',$oldhtml,$oldfind)?array_unique($oldfind['1']):array()):array();
$newitem=$newhtml?(preg_match_all('/\"upload\/attach\/[\w\/]+\/([\d]+_[\d]{13})\./',$newhtml,$newfind)?array_unique($newfind['1']):array()):array();
$sql='';
foreach(array_diff($olditem,$newitem) as $row){$spl=explode('_',$row);$sql.='UPDATE `'.$db->tablepre.'c_tinymce_file` SET `used`=`used`-1 WHERE `user`='.$spl['0'].' AND `mode` IN (1,2,3) AND `time`='.$spl['1'].';';}
foreach(array_diff($newitem,$olditem) as $row){$spl=explode('_',$row);$sql.='UPDATE `'.$db->tablepre.'c_tinymce_file` SET `used`=`used`+1 WHERE `user`='.$spl['0'].' AND `mode` IN (1,2,3) AND `time`='.$spl['1'].';';}
if($pid){$sql.='UPDATE `'.$db->tablepre.'post` SET `images`='.count($newfind['1']).' WHERE `pid`='.$pid.';';}
if($tid){$sql.='UPDATE `'.$db->tablepre.'thread` SET `images`='.count($newfind['1']).' WHERE `tid`='.$tid.';';}
if(!empty($sql)){db_exec($sql);}
}
function c_tinymce_clean($days){
global $db;
foreach(db_sql_find('SELECT * FROM `'.$db->tablepre.'c_tinymce_file` WHERE `used`=0 '.(empty($days)?'':'AND `time`<'.(sprintf('%.0f',microtime(true)*1000)-$days*86400000)).' ORDER BY `time` ASC LIMIT 100;') as $row){
$file=APP_PATH.'upload/attach/'.$row['date'].'/'.$row['user'].'_'.$row['time'].'.'.$row['type'];
if(is_file($file)){unlink($file);}
}
db_exec('DELETE FROM `'.$db->tablepre.'c_tinymce_file` WHERE `used`=0 '.(empty($days)?'':'AND `time`<'.(sprintf('%.0f',microtime(true)*1000)-$days*86400000)).' ORDER BY `time` ASC LIMIT 100;');
}

$c_tinymce['prism_plugin_use']=array_intersect_key($c_tinymce['prism_plugin'],array_flip(empty($c_tinymce['prism_plugin_use'])?array():explode(',',$c_tinymce['prism_plugin_use'])));
$c_tinymce['image_use']=array_intersect_key($c_tinymce['image'],array_flip(empty($c_tinymce['image_use'])?array():explode(',',$c_tinymce['image_use'])));
$c_tinymce['video_use']=array_intersect_key($c_tinymce['video'],array_flip(empty($c_tinymce['video_use'])?array():explode(',',$c_tinymce['video_use'])));
$c_tinymce['audio_use']=array_intersect_key($c_tinymce['audio'],array_flip(empty($c_tinymce['audio_use'])?array():explode(',',$c_tinymce['audio_use'])));
?>
