<?php exit; //assbbs.com
$arr['message_fmt']=post_quote($post['quotepid']).$arr['message_fmt'];
?>