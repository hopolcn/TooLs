<?php exit; //assbbs.com
global $c_tinymce;
c_tinymce_sync($post['message'],null);
if(!empty($c_tinymce['auto_clean'])){c_tinymce_clean($c_tinymce['auto_clean']);}
?>