<?php exit; //assbbs.com
global $c_tinymce;
c_tinymce_sync($post['message'],$arr['message'],$pid,$isfirst?$tid:0);
if(!empty($c_tinymce['auto_clean'])){c_tinymce_clean($c_tinymce['auto_clean']);}
?>