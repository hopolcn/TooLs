<?php exit; //assbbs.com
foreach($c_tinymce_media_src as $c_tinymce_src_key=>$c_tinymce_src_row){
$result=str_replace('&c_tinymce_src_'.$c_tinymce_src_key.'="'.$c_tinymce_src_row,'src="'.$c_tinymce_src_row,$result);
}
?>