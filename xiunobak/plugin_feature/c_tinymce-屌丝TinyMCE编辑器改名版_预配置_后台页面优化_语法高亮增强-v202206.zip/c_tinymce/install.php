<?php //assbbs.com;
!defined('DEBUG') AND exit('Forbidden');

$kv=kv_get('c_tinymce');
if(!empty($kv)){
	$post=array();
	$post['tinymce']="plugin/c_tinymce/tinymce/5.10.5";
	$post['tidyicon']=1;
	$post['noautowh']=1;
	$post['inner_style']="*{max-width:100% !important;}/*元素不超出编辑器宽度*/\nbody{color:#333 !important;font-size:15px !important;}/*字色字号*/\nimg{height:auto !important;}/*图片高度跟随比例*/";
	$post['outer_style']=".message *{max-width:100% !important;}/*元素不超出内容页宽度*/\n.message a{text-decoration:underline !important;}/*链接下划线*/\n.message img{height:auto !important;max-width:100% !important;}/*图片高宽度跟随比例*/\n@media(min-width:1000px){.message img{max-width:699px !important;}}/*图片在大屏幕中最宽720px*/\n.message img,.message audio,.message video{margin-top:8px !important;}/*媒体顶部间距*/\n.message table,.message th,.message td{border:1px solid #999 !important;}/*表格简易样式*/\n.message pre[class^=language-]{padding:8px 12px !important;background:#DDD !important;}/*代码示例简易样式*/\n.message iframe[src^=\"//music.163.com/\"]{height:86px !important;}.message iframe[src^=\"https://h5.xiami.com/\"]{height:110px !important;}/*音频嵌入高度修正*/\n@media(min-width:1000px){.message iframe[src^=\"//player.bilibili.com/\"],.message iframe[src^=\"https://v.qq.com/\"],.message iframe[src^=\"https://tv.sohu.com/\"],.message iframe[src^=\"https://player.youku.com/\"]{width:600px !important;height:400px !important;}}@media(max-width:1000px){.message iframe[src^=\"//player.bilibili.com/\"],.message iframe[src^=\"https://v.qq.com/\"],.message iframe[src^=\"https://tv.sohu.com/\"],.message iframe[src^=\"https://player.youku.com/\"]{width:100% !important;height:50vw !important;}}/*视频嵌入宽高统一*/";
	$post['postprocess']="for(let row of args.node.getElementsByTagName(\"a\")){row.target=\"_blank\";};/*统一链接指向新窗口*/";
	$post['plugins']="toc code lists advlist codesample hr image link media paste table wordcount fullscreen autolink charmap emoticons autosave";
	$post['toolbar']="undo redo | code removeformat toc restoredraft | formatselect bold italic underline strikethrough forecolor backcolor align bullist numlist | charmap emoticons image media link unlink | hr blockquote codesample table | fullscreen";
	$post['moreset']="block_formats:'P=p;H1=h1;H2=h2;H3=h3;H4=h4;H5=h5;H6=h6;',formats:{blockquote:{block:'blockquote',classes:'blockquote',wrapper:true}},branding: false,codesample_languages:[{text:'ASP.NET(C#)',value:'aspnet'},{text:'AutoIt',value:'autoIt'},{text:'Bash',value:'bash'},{text:'BASIC',value:'basic'},{text:'BBcode',value:'bbcode'},{text:'C',value:'c'},{text:'C#',value:'csharp'},{text:'C++',value:'cpp'},{text:'CMake',value:'cmake'},{text:'CSS',value:'css'},{text:'CSS Extras',value:'css-extras'},{text:'CSV',value:'csv'},{text:'Docker',value:'docker, dockerfile'},{text:'Excel Formula',value:'excel-formula, xlsx, xls'},{text:'Git',value:'git'},{text:'Go',value:'go'},{text:'Go module',value:'go-module, go-mod'},{text:'GraphQL',value:'graphql'},{text:'HTML',value:'html'},{text:'Ini',value:'ini'},{text:'Java',value:'java'},{text:'JavaScript',value:'javascript'},{text:'JavaDoc',value:'javadoc'},{text:'JavaDoc-like',value:'javadoclike'},{text:'Java stack trace',value:'javastacktrace'},{text:'JSON',value:'json'},{text:'JSON5',value:'json5'},{text:'JSONP',value:'jsonp'},{text:'Log file',value:'log'},{text:'Lua',value:'lua'},{text:'Makefile',value:'makefile'},{text:'Markdown',value:'markdown, md'},{text:'MATLAB',value:'matlab'},{text:'MongoDB',value:'mongodb'},{text:'N4JS',value:'n4js, n4jsd'},{text:'Nginx',value:'nginx'},{text:'NSIS',value:'nsis'},{text:'Perl',value:'perl'},{text:'PHP',value:'php'},{text:'PHPDoc',value:'phpdoc'},{text:'PHP Extras',value:'php-extras'},{text:'PL/SQL',value:'plsql'},{text:'PowerShell',value:'powershell'},{text:'Python',value:'python'},{text:'QML',value:'qml'},{text:'R',value:'r'},{text:'Regex',value:'regex'},{text:'Ruby',value:'ruby'},{text:'Rust',value:'rust'},{text:'SQL',value:'sql'},{text:'Swift',value:'swift'},{text:'URI',value:'uri, url'},{text:'VB.Net',value:'vbnet'},{text:'VIM',value:'vim'},{text:'Visual Basic',value:'visual-basic, vb, vba'},{text:'Wiki markup',value:'wiki'},{text:'YAML',value:'yaml'},{text:'XML',value:'xml'}],";
	$post['prism']="plugin/c_tinymce/prismjs/1.28.0";
	$post['prism_theme_use']="prism-tomorrow";
	$post['prism_plugin_use']="line-numbers,autoloader,toolbar,copy-to-clipboard,show-language";
	$post['keeptext']=1;
	$post['newlinep']=1;
	$post['jumplast']=1;
	$post['jumpedit']=1;
	foreach($grouplist as $row){
		if(!in_array($row['gid'], array('0', '7'))){
			$post[$row['gid'].'_image_interval']=1440;
			$post[$row['gid'].'_image_amount']=80;
			$post[$row['gid'].'_image_size']=2;
			$post[$row['gid'].'_media_interval']=1440;
			$post[$row['gid'].'_media_amount']=8;
			$post[$row['gid'].'_media_size']=2;
		}else{
			$post[$row['gid'].'_image_interval']=1440;
			$post[$row['gid'].'_image_amount']=0;
			$post[$row['gid'].'_image_size']=0;
			$post[$row['gid'].'_media_interval']=1440;
			$post[$row['gid'].'_media_amount']=0;
			$post[$row['gid'].'_media_size']=0;
		}
	}
	$post['image_use']="gif,jpg,png,bmp,ico,webp";
	$post['rape']="_chop:{url:'view/img/water-small.png',width:400,height:200,x:0.5,y:-80},\n_png:{width:2048,height:2048,fill:null,format:\"image/png\",quality:0.9},\n_jpg:{width:2048,height:2048,fill:\"#FFF\",format:\"image/jpeg\",quality:0.9},\n_webp:{width:2048,height:2048,fill:null,format:\"image/webp\",quality:0.9},\npng:{normal:\"_webp\",nowebp:\"_png\",animate:false},\njpg:{normal:\"_webp\",nowebp:\"_jpg\"},\nbmp:{normal:\"_webp\",nowebp:\"_jpg\"},\nico:null,\ngif:{normal:\"_webp\",nowebp:\"_jpg\",animate:false},\nwebp:{normal:\"_webp\",nowebp:\"_png\",animate:false},";
	$post['video_use']="mp4,webm";
	$post['audio_use']="m4a,aac,weba,wav,mp3,flac";
	$post['media_src']="//music.163.com/\n//player.bilibili.com/\nhttps://v.qq.com/\nhttps://tv.sohu.com/\nhttps://player.youku.com/";
	$post['auto_clean']=0;
	kv_set('c_tinymce',$post);
}

?>

