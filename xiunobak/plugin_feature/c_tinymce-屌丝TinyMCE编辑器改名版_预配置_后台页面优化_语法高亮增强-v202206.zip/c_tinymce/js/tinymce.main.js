function c_tinymce_mediahtml(data){
var noaudio=(data.source.lastIndexOf('.')<0||Object.keys(c_tinymce_audio_use).indexOf(data.source.substring(data.source.lastIndexOf('.')+1))<0)?true:false;
return '<'+(noaudio?'video':'audio')+' controls="controls" '+(noaudio?((data.poster?'poster="'+data.poster+'" ':'')+(data.width?'width="'+data.width+'" ':'')+(data.height?'height="'+data.height+'" ':'')):'')+'><source src="'+data.source+'" /></'+(noaudio?'video':'audio')+'>';
};
function c_tinymce_clip(blob,call){
for(var obj of tinymce.activeEditor.dom.select('img[src="'+blob.blobUri()+'"]')){obj.style.opacity='0.5';};
c_tinymce_pool.push({act:"image",now:"wait",src:blob.blobUri()});
document.querySelector('#c_tinymce_list').insertAdjacentHTML('afterbegin','<div style="max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><a id="c_tinymce_file_'+(c_tinymce_pool.length-1)+'" href="javascript:;" onclick="c_tinymce_stop('+(c_tinymce_pool.length-1)+');">[等待]</a> [图片] 粘贴</div>');
c_tinymce_info('rest',1);
c_tinymce_deal(null,call);
};
function c_tinymce_file(call,what,meta){
switch(meta.filetype){
case 'image':var show='图片',accept='image/*,'+c_tinymce_image_arr.join(',');break;
case 'media':var show='媒体',accept=c_tinymce_media_arr.join(',');break;
default:console.log('SHIT');return;break;
};
c_tinymce_pick.setAttribute('accept',accept);
c_tinymce_pick.setAttribute('type','file');
c_tinymce_pick.setAttribute('multiple','multiple');
c_tinymce_pick.onchange=function(){
for(var obj of c_tinymce_pick.files){
c_tinymce_pool.push({act:meta.filetype,now:"wait",src:obj});
document.querySelector('#c_tinymce_list').insertAdjacentHTML('afterbegin','<div style="max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><a id="c_tinymce_file_'+(c_tinymce_pool.length-1)+'" href="javascript:;" onclick="c_tinymce_stop('+(c_tinymce_pool.length-1)+');">[等待]</a> ['+show+'] '+obj.name+'</div>');
};
if(c_tinymce_pick.files.length==1){c_tinymce_deal(c_tinymce_pool.length-1,call);}
else{tinymce.activeEditor.windowManager.close();c_tinymce_deal(null);};
c_tinymce_info('rest',c_tinymce_pick.files.length);
c_tinymce_pick.value=null;
};
if(!document.querySelector('#c_tinymce_solo')){document.querySelector('.tox-dialog__title').insertAdjacentHTML('beforeend',' <a id="c_tinymce_solo" href="javascript:;" style="cursor:pointer;"></a>');};
c_tinymce_pick.click();
};
function c_tinymce_deal(ikey,call){
var solo=false;
if(ikey===null){
for(var key in c_tinymce_pool){
if(!c_tinymce_pool[key]){continue;};
if(c_tinymce_pool[key].now=='proc'){return;};
if(c_tinymce_pool[key].now=='wait'){ikey=key;c_tinymce_pool[ikey].now='proc';break;};
};
}
else{c_tinymce_pool[ikey].now='solo';solo=true;};
if(ikey===null){console.log(c_tinymce_pool);return;};
if(c_tinymce_rape&&c_tinymce_pool[ikey].act=='image'){
new Rape(c_tinymce_pool[ikey].src,c_tinymce_rape).conv().then((res)=>{if(c_tinymce_image_arr.indexOf('.'+res.format)<0){c_tinymce_fail({"shit":"type"},ikey,solo,call);return;};c_tinymce_auth(res.canvas,ikey,call);}).catch((err)=>{c_tinymce_fail({"shit":"rape"},ikey,solo,call);console.log('RAPE:'+err);});
}
else if(typeof(c_tinymce_pool[ikey].src)=='string'&&c_tinymce_pool[ikey].src.match(/^blob:/)){
var suck=new XMLHttpRequest;
suck.responseType='blob';
suck.onerror=function(e){c_tinymce_fail({"shit":"suck"},ikey,solo,call);};
suck.onload=function(e){c_tinymce_auth(suck.response,ikey,call);};
suck.open('GET',c_tinymce_pool[ikey].src);
suck.send(null);
}
else{
c_tinymce_auth(c_tinymce_pool[ikey].src,ikey,call);
};
};
function c_tinymce_auth(file,ikey,call){
var solo=(c_tinymce_pool[ikey].now=='solo');
switch(c_tinymce_pool[ikey].act){
case 'image':var type=c_tinymce_image_arr,size=c_tinymce_image_size,test=c_tinymce_image_test;break;
case 'media':var type=c_tinymce_media_arr,size=c_tinymce_media_size,test=c_tinymce_media_test;break;
default:console.log('SHIT');return;break;
};
if(!size){c_tinymce_fail({"shit":"auth"},ikey,solo,call);return;};
if(file.size<12){c_tinymce_fail({"shit":"file"},ikey,solo,call);return;};
if(file.size>size){c_tinymce_fail({"shit":"size"},ikey,solo,call);return;};
if(test){
var suck=new XMLHttpRequest();
suck.open('POST','./?c_tinymce_auth&act='+c_tinymce_pool[ikey].act,true);
suck.onerror=function(e){c_tinymce_fail({"shit":"suck"},ikey,solo,call);};
suck.onreadystatechange=function(e){
if(this.readyState===4&&this.status===200){
var cunt=JSON.parse(this.responseText);
if(cunt['shit']=='done'){c_tinymce_save(file,ikey,call);}
else{c_tinymce_fail(cunt,ikey,solo,call);};
};
};
suck.send(null);
}
else{c_tinymce_save(file,ikey,call);};
};
function c_tinymce_save(file,ikey,call){
var solo=(c_tinymce_pool[ikey].now=='solo');
var suck=new XMLHttpRequest();
c_tinymce_pool[ikey].xhr=suck;
suck.open('POST','./?c_tinymce_save&act='+c_tinymce_pool[ikey].act,true);
suck.onerror=function(e){c_tinymce_fail({"shit":"suck"},ikey,solo,call);};
suck.upload.onprogress=function(e){
if(!e.lengthComputable){return;};
var prog=parseInt(99*e.loaded/e.total)+'%';
if(solo&&document.querySelector('#c_tinymce_solo')){
document.querySelector('#c_tinymce_solo').innerHTML='<span style="color:darkorange;">['+prog+']</span>';
document.querySelector('#c_tinymce_solo').setAttribute('onclick','c_tinymce_stop('+ikey+');');
};
document.querySelector('#c_tinymce_file_'+ikey).innerHTML='<span style="color:darkorange;">['+prog+']</span>';
c_tinymce_proc(false);
};
suck.onreadystatechange=function(e){
if(this.readyState===4&&this.status===200){
delete c_tinymce_pool[ikey].xhr;
var cunt=JSON.parse(this.responseText);
if(cunt['shit']=='done'){c_tinymce_done(cunt,ikey,solo,call);}
else{c_tinymce_fail(cunt,ikey,solo,call);};
};
};
var dick=new FormData();
dick.append('file',file);
suck.send(dick);
};
function c_tinymce_done(cunt,ikey,solo,call){
c_tinymce_pool[ikey].now='done';
switch(cunt['zone']){
default:
cunt['file']='upload/attach/'+cunt['date']+'/'+cunt['user']+'_'+cunt['time']+'.'+cunt['type'];
break;
};
if(typeof(c_tinymce_pool[ikey].src)=='string'&&c_tinymce_pool[ikey].src.match(/^blob:/)){
for(var obj of tinymce.activeEditor.dom.select('img[src="'+c_tinymce_pool[ikey].src+'"]')){obj.style.opacity='';};
c_tinymce_pool[ikey].src=cunt['file'];
if(call){call(c_tinymce_pool[ikey].src);};
}
else if(solo&&document.querySelector('#c_tinymce_solo')){
document.querySelector('#c_tinymce_solo').innerHTML='<span style="color:green;">[完成]</span>';
document.querySelector('#c_tinymce_solo').removeAttribute('onclick');
c_tinymce_pool[ikey].src=cunt['file'];
if(call){call(c_tinymce_pool[ikey].src);};
}
else{
c_tinymce_pool[ikey].src=cunt['file'];
c_tinymce_exec(ikey);
};
document.querySelector('#c_tinymce_file_'+ikey).innerHTML='<span style="color:green;">[完成]</span>';
document.querySelector('#c_tinymce_file_'+ikey).setAttribute('onclick','c_tinymce_exec('+ikey+');');
c_tinymce_info('done',1);
c_tinymce_proc(true);
if(!solo){c_tinymce_deal(null);};
};
function c_tinymce_fail(cunt,ikey,solo,call){
c_tinymce_pool[ikey].now=cunt['shit'];
if(typeof(c_tinymce_pool[ikey].src)=='string'&&c_tinymce_pool[ikey].src.match(/^blob:/)){
if(call){call(c_tinymce_pool[ikey].src);};
}
else if(solo&&document.querySelector('#c_tinymce_solo')){
document.querySelector('#c_tinymce_solo').innerHTML='<span style="color:red;">[错误]</span>';
document.querySelector('#c_tinymce_solo').setAttribute('onclick','c_tinymce_exec('+ikey+');');
};
delete c_tinymce_pool[ikey].src;
document.querySelector('#c_tinymce_file_'+ikey).innerHTML='<span style="color:red;">[错误]</span>';
document.querySelector('#c_tinymce_file_'+ikey).setAttribute('onclick','c_tinymce_exec('+ikey+');');
c_tinymce_info('fail',1);
c_tinymce_proc(true);
if(!solo){c_tinymce_deal(null);};
};
function c_tinymce_stop(ikey){
tinymce.activeEditor.windowManager.confirm((ikey===null)?'停止队列？':'删除任务？',function(yes){
if(!yes){return;};
if(ikey===null){
for(var key in c_tinymce_pool){
if(!c_tinymce_pool[key].xhr){continue;};
c_tinymce_pool[key].xhr.abort();
delete c_tinymce_pool[key].xhr;
c_tinymce_pool[key].now='wait';
document.querySelector('#c_tinymce_file_'+key).innerHTML='<span style="color:blue;">[等待]</span>';
};
c_tinymce_proc(true);
}
else{
var proc=false;
if(c_tinymce_pool[ikey].xhr){
if(c_tinymce_pool[ikey].now=='proc'){proc=true;};
c_tinymce_pool[ikey].xhr.abort();
};
delete c_tinymce_pool[ikey];
c_tinymce_info('rest',-1);
document.querySelector('#c_tinymce_file_'+ikey).parentNode.innerHTML='';
if(document.querySelector('#c_tinymce_solo')){
document.querySelector('#c_tinymce_solo').innerHTML='';
document.querySelector('#c_tinymce_solo').removeAttribute('onclick');
};
c_tinymce_proc(true);
if(proc){
c_tinymce_deal(null);
};
};
});
};
function c_tinymce_exec(ikey){
switch(c_tinymce_pool[ikey].now){
case 'done':
tinymce.activeEditor.selection.collapse();
switch(c_tinymce_pool[ikey].act){
case 'image':tinymce.activeEditor.insertContent('<p><img src="'+c_tinymce_pool[ikey].src+'" alt="" /></p>');break;
case 'media':tinymce.activeEditor.insertContent('<p>'+c_tinymce_mediahtml({source:c_tinymce_pool[ikey].src})+'</p>');break;
case 'file':break;
default:tinymce.activeEditor.windowManager.alert('上传成功');break;
};
break;
case 'auth':tinymce.activeEditor.windowManager.alert('无权使用插件');break;
case 'over':tinymce.activeEditor.windowManager.alert('周期配额用尽');break;
case 'file':tinymce.activeEditor.windowManager.alert('文件上传出错');break;
case 'size':tinymce.activeEditor.windowManager.alert('文件大小超限');break;
case 'type':tinymce.activeEditor.windowManager.alert('文件类型禁止');break;
case 'data':tinymce.activeEditor.windowManager.alert('数据存取失败');break;
case 'path':tinymce.activeEditor.windowManager.alert('目录创建失败');break;
case 'move':tinymce.activeEditor.windowManager.alert('文件存储失败');break;
case 'suck':tinymce.activeEditor.windowManager.alert('网络请求失败');break;
case 'rape':tinymce.activeEditor.windowManager.alert('前端处理失败');break;
default:tinymce.activeEditor.windowManager.alert('未知错误');break;
};
};
function c_tinymce_info(mode,qnty){
document.querySelector('#c_tinymce_info_'+mode).innerHTML=parseInt(document.querySelector('#c_tinymce_info_'+mode).innerHTML)+qnty;
if(mode!='rest'){c_tinymce_info('rest',-1);};
};
function c_tinymce_proc(stop){
document.querySelector('#c_tinymce_proc').innerHTML=stop?'开始':'停止';
document.querySelector('#c_tinymce_proc').setAttribute('onclick',stop?'c_tinymce_deal(null);':'c_tinymce_stop(null);');
};
function c_tinymce_list(){
document.querySelector('#c_tinymce_list').style.display=(document.querySelector('#c_tinymce_list').style.display=='none')?'':'none';
};
var c_tinymce_image_arr=[];
for(var key in c_tinymce_image_use){c_tinymce_image_arr=c_tinymce_image_arr.concat(c_tinymce_image_use[key].split(','));};
var c_tinymce_media_arr=[];
for(var key in c_tinymce_video_use){c_tinymce_media_arr=c_tinymce_media_arr.concat(c_tinymce_video_use[key].split(','));};
for(var key in c_tinymce_audio_use){c_tinymce_media_arr=c_tinymce_media_arr.concat(c_tinymce_audio_use[key].split(','));};
var c_tinymce_pick=document.createElement('input');
var c_tinymce_pool=[];
var UM={getEditor:function(func){if(func!='message'){return;};return {setContent:function(html){tinymce.activeEditor.insertContent(html);},execCommand:function(cmd,html){if(cmd!='insertHtml'){return;};tinymce.activeEditor.insertContent(html);}};}};