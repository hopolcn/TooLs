<?php
!defined('DEBUG') AND exit('Access Denied.'); //assbbs.com
if($method=='POST'){
	if(param('csrf')!=session_id()){message(0,"Session Error");}
		$post=array();
		$post['tinymce']=trim(param('tinymce'),'/ ');
		$post['tidyicon']=param('tidyicon',0);
		$post['noautowh']=param('noautowh',0);
		$post['inner_style']=trim(preg_replace('/\s(?=\s)/','\\1',param('inner_style','',false)));
		$post['outer_style']=trim(preg_replace('/\s(?=\s)/','\\1',param('outer_style','',false)));
		$post['postprocess']=trim(preg_replace('/\s(?=\s)/','\\1',param('postprocess','',false)));
		$post['plugins']=trim(param('plugins'));
		$post['toolbar']=trim(param('toolbar'));
		$post['moreset']=trim(param('moreset'));
		
		$post['prism']=trim(param('prism'),'/ ');
		$post['prism_theme_use']=param('prism_theme_use', '');
		$post['prism_plugin_use']=array();
		foreach($c_tinymce['prism_plugin'] as $key=>$row){if(param('prism_plugin_'.$key,0)){$post['prism_plugin_use'][]=$key;}}
		$post['prism_plugin_use']=implode(',',$post['prism_plugin_use']);
		
		$post['keeptext']=param('keeptext',0);
		$post['newlinep']=param('newlinep',0);
		$post['jumplast']=param('jumplast',0);
		$post['jumpedit']=param('jumpedit',0);
		foreach($grouplist as $row){
			$post[$row['gid'].'_image_interval']=intval(param($row['gid'].'_image_interval',0));
			$post[$row['gid'].'_image_amount']=intval(param($row['gid'].'_image_amount',0));
			$post[$row['gid'].'_image_size']=intval(param($row['gid'].'_image_size',0));
			$post[$row['gid'].'_media_interval']=intval(param($row['gid'].'_media_interval',0));
			$post[$row['gid'].'_media_amount']=intval(param($row['gid'].'_media_amount',0));
			$post[$row['gid'].'_media_size']=intval(param($row['gid'].'_media_size',0));
		}
		$post['image_use']=array();
		foreach($c_tinymce['image'] as $key=>$row){if(param('image_'.$key,0)){$post['image_use'][]=$key;}}
		$post['image_use']=implode(',',$post['image_use']);
		$post['rape']=trim(preg_replace('/\s(?=\s)/','\\1',param('rape','',false)));
		$post['video_use']=array();
		foreach($c_tinymce['video'] as $key=>$row){if(param('video_'.$key,0)){$post['video_use'][]=$key;}}
		$post['video_use']=implode(',',$post['video_use']);
		$post['audio_use']=array();
		foreach($c_tinymce['audio'] as $key=>$row){if(param('audio_'.$key,0)){$post['audio_use'][]=$key;}}
		$post['audio_use']=implode(',',$post['audio_use']);
		$post['media_src']=trim(preg_replace('/\s(?=\s)/','\\1',param('media_src','',false)));
		$post['auto_clean']=intval(param('auto_clean',0));
		kv_set('c_tinymce',$post);
		message(0,lang('save_successfully'));
}
elseif(isset($_GET['trash'])){
	error_reporting(0);
	echo json_encode(db_sql_find('SELECT * FROM `'.$db->tablepre.'c_tinymce_file` WHERE `used`=0 ORDER BY `time` ASC LIMIT 100;'));
}
elseif(isset($_GET['clean']) && $_GET['csrf']==session_id()){
	c_tinymce_clean(0);
}
else{
	$json=json_decode(file_get_contents(APP_PATH.'plugin/c_tinymce/conf.json'),true);
    include _include(ADMIN_PATH.'view/htm/header.inc.htm');
	echo '<div class="row"><div class="col-lg-10 offset-lg-1"><div class="card"><div class="card-body"><div class="btn-group">
<a class="btn btn-light" id="c_tinymce-index" href="javascript:;" onclick="c_tinymce(\'index\');" style="font-weight:bold;">[版本]</a>
<a class="btn btn-light" id="c_tinymce-basic" href="javascript:;" onclick="c_tinymce(\'basic\');">[编辑器]</a>
<a class="btn btn-light" id="c_tinymce-prism" href="javascript:;" onclick="c_tinymce(\'prism\');">[语法高亮]</a>
<a class="btn btn-light" id="c_tinymce-extra" href="javascript:;" onclick="c_tinymce(\'extra\');">[扩展]</a>
<a class="btn btn-light" id="c_tinymce-group" href="javascript:;" onclick="c_tinymce(\'group\');">[权限]</a>
<a class="btn btn-light" id="c_tinymce-image" href="javascript:;" onclick="c_tinymce(\'image\');">[图片]</a>
<a class="btn btn-light" id="c_tinymce-media" href="javascript:;" onclick="c_tinymce(\'media\');">[媒体]</a>
<a class="btn btn-light" id="c_tinymce-clean" href="javascript:;" onclick="c_tinymce(\'clean\');">[清理]</a>
</div><hr />
<form action="'.url("plugin-setting-c_tinymce").'" method="post" id="form">

<span id="c_tinymce_index">
<div><b>当前版本</b>：'.$json['version'].'</div>
<div><b>温馨提示</b>：如需开启上传请先设置 [权限] [图片] [媒体]</div>
<div>屌丝论坛：<a href="https://assbbs.com" target="_blank">https://assbbs.com</a></div>
<div>云库论坛：<a href="https://cloudatabases.com" target="_blank">https://cloudatabases.com</a></div>
</span>

<span id="c_tinymce_basic" style="display:none;">
<div><b>TinyMCE</b>（编辑器调用，<a href="https://github.com/tinymce/tinymce/tags" target="_blank">最新版本号</a>）</div>
<div>'.form_text('tinymce',empty($c_tinymce['tinymce'])?'':$c_tinymce['tinymce']).'</div>
<div class="text-gray">https://cdn.jsdelivr.net/npm/tinymce</div>
<div class="text-gray">https://cdn.staticfile.org/tinymce/5.10.5</div>
<div class="text-gray">https://cdn.bootcss.com/tinymce/5.10.5</div>
<div class="text-gray">https://unpkg.com/tinymce</div>
<hr />
<div><b>缩进工具栏</b>（编辑器样式更协调）</div>
<div>'.form_radio_yes_no('tidyicon',empty($c_tinymce['tidyicon'])?0:1).'</div>
<hr />
<div><b>禁止自动宽高</b>（防止图片尺寸缩小）</div>
<div>'.form_radio_yes_no('noautowh',empty($c_tinymce['noautowh'])?0:1).'</div>
<hr />
<div><b>内部样式</b>（编辑器内CSS）</div>
<div>'.form_textarea('inner_style',empty($c_tinymce['inner_style'])?'':$c_tinymce['inner_style']).'</div>
<div class="text-gray">*{max-width:100% !important;}/*元素不超出编辑器宽度*/</div>
<div class="text-gray">body{color:#333 !important;font-size:15px !important;}/*字色字号*/</div>
<div class="text-gray">img{height:auto !important;}/*图片高度跟随比例*/</div>
<hr />
<div><b>外部样式</b>（论坛全局CSS）</div>
<div>'.form_textarea('outer_style',empty($c_tinymce['outer_style'])?'':$c_tinymce['outer_style']).'</div>
<div class="text-gray">.message *{max-width:100% !important;}/*元素不超出内容页宽度*/</div>
<div class="text-gray">.message a{text-decoration:underline !important;}/*链接下划线*/</div>
<div class="text-gray">.message img{height:auto !important;max-width:100% !important;}/*图片高宽度跟随比例*/</div>
<div class="text-gray">@media(min-width:1000px){.message img{max-width:720px !important;}}/*图片在大屏幕中最宽720px*/</div>
<div class="text-gray">.message img,.message audio,.message video{margin-top:8px !important;}/*媒体顶部间距*/</div>
<div class="text-gray">.message table,.message th,.message td{border:1px solid #999 !important;}/*表格简易样式*/</div>
<div class="text-gray">.message pre[class^=language-]{padding:8px 12px !important;background:#DDD !important;}/*代码示例简易样式*/</div>
<div class="text-gray">.message iframe[src^="//music.163.com/"]{height:86px !important;}.message iframe[src^="https://h5.xiami.com/"]{height:110px !important;}/*音频嵌入高度修正*/</div>
<div class="text-gray">@media(min-width:1000px){.message iframe[src^="//player.bilibili.com/"],.message iframe[src^="https://v.qq.com/"],.message iframe[src^="https://tv.sohu.com/"],.message iframe[src^="https://player.youku.com/"]{width:600px !important;height:400px !important;}}@media(max-width:1000px){.message iframe[src^="//player.bilibili.com/"],.message iframe[src^="https://v.qq.com/"],.message iframe[src^="https://tv.sohu.com/"],.message iframe[src^="https://player.youku.com/"]{width:100% !important;height:50vw !important;}}/*视频嵌入宽高统一*/</div>
<hr />
<div><b>粘贴回调</b>（内容处理JS）</div>
<div>'.form_textarea('postprocess',empty($c_tinymce['postprocess'])?'':$c_tinymce['postprocess']).'</div>
<div class="text-gray">for(let row of args.node.getElementsByTagName("a")){row.target="_blank";};/*统一链接指向新窗口*/</div>
<hr />
<div><b>自定义插件</b>（不懂留空别乱改）</div>
<div>'.form_textarea('plugins',empty($c_tinymce['plugins'])?'':$c_tinymce['plugins']).'</div>
<div class="text-gray">code codesample hr image link media paste table wordcount</div>
<hr />
<div><b>自定义工具</b>（不懂留空别乱改）</div>
<div>'.form_textarea('toolbar',empty($c_tinymce['toolbar'])?'':$c_tinymce['toolbar']).'</div>
<div class="text-gray">undo redo code removeformat align bold italic underline strikethrough forecolor backcolor fontsizeselect image media link unlink hr codesample table</div>
<hr />
<div><b>自定义配置</b>（不懂留空别乱改）</div>
<div>'.form_textarea('moreset',empty($c_tinymce['moreset'])?'':$c_tinymce['moreset']).'</div>
<div class="text-gray">menubar:true,height:400</div>
</span>

<span id="c_tinymce_prism" style="display:none;">
<div><b>Prism语法高亮</b>（留空不启用，<a href="https://github.com/PrismJS/prism/releases" target="_blank">最新版本号</a>）</div>
<div>'.form_text('prism',empty($c_tinymce['prism'])?'':$c_tinymce['prism']).'</div>
<div class="text-gray">https://cdn.jsdelivr.net/npm/prismjs</div>
<div class="text-gray">https://cdn.staticfile.org/prism/1.28.0</div>
<div class="text-gray">https://cdn.bootcss.com/prism/1.28.0</div>
<div class="text-gray">https://unpkg.com/prismjs</div>
<hr />
<div><b>主题</b></div>
';
foreach($c_tinymce['prism_theme'] as $key=>$row){
	$checked = 1;
	$c_tinymce['prism_theme_use'] == $key AND $checked = 0;
	$add = $key == $checked ? ' checked="checked"' : '';
	echo "<label class=\"custom-input custom-radio\"><input type=\"radio\" name=\"prism_theme_use\" value=\"$key\"$add /> $row</label> &nbsp; \r\n";
	};
echo '
<hr />
<div><b>插件</b></div>
';
foreach($c_tinymce['prism_plugin'] as $key=>$row){echo form_checkbox('prism_plugin_'.$key,empty($c_tinymce['prism_plugin_use'][$key])?0:1,$row);}
echo '<div class="text-info">“Show Language”、“Copy to Clipboard Button”、“Download Button”依赖“Toolbar”</div>
</span>

<span id="c_tinymce_extra" style="display:none;">
<div><b>高级回复继承</b>（切换编辑器保留内容）</div>
<div>'.form_radio_yes_no('keeptext',empty($c_tinymce['keeptext'])?0:1).'</div>
<hr />
<div><b>统一文本换行</b>（快捷回复使用P换行符）</div>
<div>'.form_radio_yes_no('newlinep',empty($c_tinymce['newlinep'])?0:1).'</div>
<hr />
<div><b>回复后跳转最后一页</b>（需禁用回复排序类插件）</div>
<div>'.form_radio_yes_no('jumplast',empty($c_tinymce['jumplast'])?0:1).'</div>
<hr />
<div><b>编辑后跳转至来源页</b>（不开启跳转帖子第一页）</div>
<div>'.form_radio_yes_no('jumpedit',empty($c_tinymce['jumpedit'])?0:1).'</div>
</span>

<span id="c_tinymce_group" style="display:none;">
<table>
<tbody>
<tr>
<th></th>
<th><a href="javascript:;" onclick="alert(\'填写“0”为永久\r\n强烈不建议设置为永久\r\n推荐值：1440\');">配额周期（分）</a></th>
<th><a href="javascript:;" onclick="alert(\'填写“0”不限制\r\n数值越大主机压力越大\r\n推荐值：100\');">最多上传（张）</a></th>
<th><a href="javascript:;" onclick="alert(\'填写“0”关闭该组上传\r\n建议不要太大以免中断\r\n推荐值：5\');">最大尺寸（MB）</a></th>
</tr>
';
foreach($grouplist as $row){
echo '
<tr>
<td><b>'.$row['gid'].':'.$row['name'].'</b></td>
</tr>
<tr>
<td>图片</td>
<td>'.form_text($row['gid'].'_image_interval',empty($c_tinymce[$row['gid'].'_image_interval'])?0:$c_tinymce[$row['gid'].'_image_interval']).'</td>
<td>'.form_text($row['gid'].'_image_amount',empty($c_tinymce[$row['gid'].'_image_amount'])?0:$c_tinymce[$row['gid'].'_image_amount']).'</td>
<td>'.form_text($row['gid'].'_image_size',empty($c_tinymce[$row['gid'].'_image_size'])?0:$c_tinymce[$row['gid'].'_image_size']).'</td>
</tr>
<tr>
<td>媒体</td>
<td>'.form_text($row['gid'].'_media_interval',empty($c_tinymce[$row['gid'].'_media_interval'])?0:$c_tinymce[$row['gid'].'_media_interval']).'</td>
<td>'.form_text($row['gid'].'_media_amount',empty($c_tinymce[$row['gid'].'_media_amount'])?0:$c_tinymce[$row['gid'].'_media_amount']).'</td>
<td>'.form_text($row['gid'].'_media_size',empty($c_tinymce[$row['gid'].'_media_size'])?0:$c_tinymce[$row['gid'].'_media_size']).'</td>
</tr>
';
}
echo '
</tbody>
</table>
<hr />
<div><b>以下设置必须高于最大尺寸</b>（需要修改服务器参数）</div>
<div>[php.ini] post_max_size (当前:'.ini_get('post_max_size').')</div>
<div>[php.ini] upload_max_filesize (当前:'.ini_get('upload_max_filesize').')</div>
<div>[nginx.conf] client_max_body_size (<a href="https://blog.csdn.net/webnoties/article/details/17266651" target="_blank">了解详情</a>)</div>
</span>

<span id="c_tinymce_image" style="display:none;">
<div><b>可上传格式</b>（WEBP格式不兼容：PHP&lt;7.1）</div>
<div>
';
foreach($c_tinymce['image'] as $key=>$row){echo form_checkbox('image_'.$key,empty($c_tinymce['image_use'][$key])?0:1,$key);}
echo '
</div>
<hr />
<div><b>Rape前端处理</b>（留空不启用，<a href="https://github.com/netcrashed/rape.js" target="_blank">配置说明书</a>）</div>
<div>'.form_textarea('rape',empty($c_tinymce['rape'])?'':$c_tinymce['rape']).'</div>
<div class="text-gray">_png:{width:2048,height:2048,fill:null,format:"image/png",quality:0.9},</div>
<div class="text-gray">_jpg:{width:2048,height:2048,fill:"#FFF",format:"image/jpeg",quality:0.9},</div>
<div class="text-gray">_webp:{width:2048,height:2048,fill:null,format:"image/webp",quality:0.9},</div>
<div class="text-gray">png:{normal:"_webp",nowebp:"_png",animate:false},</div>
<div class="text-gray">jpg:{normal:"_webp",nowebp:"_jpg"},</div>
<div class="text-gray">bmp:{normal:"_webp",nowebp:"_jpg"},</div>
<div class="text-gray">ico:null,</div>
<div class="text-gray">gif:{normal:"_webp",nowebp:"_jpg",animate:false},</div>
<div class="text-gray">webp:{normal:"_webp",nowebp:"_png",animate:false},</div>
</span>

<span id="c_tinymce_media" style="display:none;">
<div><b>可上传格式</b>（<a href="https://developer.mozilla.org/zh-TW/docs/Web/Media/Formats/Containers" target="_blank">跨平台兼容</a>：MP4/MOV[AVC]，M4A[AAC]，WEBM，WEBA，WAV，MP3，FLAC）</div>
<div>
';
foreach($c_tinymce['video'] as $key=>$row){echo form_checkbox('video_'.$key,empty($c_tinymce['video_use'][$key])?0:1,$key);}
echo '</div><div>';
foreach($c_tinymce['audio'] as $key=>$row){echo form_checkbox('audio_'.$key,empty($c_tinymce['audio_use'][$key])?0:1,$key);}
echo '
</div>
'.(extension_loaded('fileinfo')?'':'<div>建议安装<a href="https://www.php.net/manual/zh/book.fileinfo.php" target="_blank">PHP-Fileinfo</a>扩展实现<a href="https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Basics_of_HTTP/MIME_types" target="_blank">MIME</a>精准检测。</div>').'
<hr />
<div><b>可嵌入地址</b>（iframe可以调用的网站，头部匹配，每行一个）</div>
<div>'.form_textarea('media_src',empty($c_tinymce['media_src'])?'':$c_tinymce['media_src']).'</div>
<div class="text-gray">//music.163.com/</div>
<div class="text-gray">//player.bilibili.com/</div>
<div class="text-gray">https://v.qq.com/</div>
<div class="text-gray">https://tv.sohu.com/</div>
<div class="text-gray">https://player.youku.com/</div>
</span>

<span id="c_tinymce_clean" style="display:none;">
<div><b>自动清理</b>（上传N天后未使用则删除，填写“0”不启用）</div>
<div>'.form_text('auto_clean',empty($c_tinymce['auto_clean'])?0:$c_tinymce['auto_clean']).'</div>
<hr />
<div><b>手动清理</b>（列举100条未使用文件，不要误删编辑中内容）</div>
<div><a href="javascript:;" onclick="c_tinymce_clean();">&#9760;&nbsp;一键删除本页文件&nbsp;&#9760;</a></div>
<span id="c_tinymce_trash"></span>
</span>
<hr />
<input name="csrf" value="'.session_id().'" style="display:none;" />
<div class="form-group row">
	<label class="col-sm-2 form-control-label"></label>
	<div class="col-sm-12">
		<button type="submit" class="btn btn-primary btn-block" id="submit" data-loading-text="'.lang('submiting').'...">'.lang('confirm').'</button>
		<a role="button" class="btn btn-secondary btn-block mt-1" href="javascript:history.back();">'.lang('back').'</a>
	</div>
</div>
</form>
</div></div></div></div>
';
include _include(ADMIN_PATH.'view/htm/footer.inc.htm');
echo '
<script>
var jform = $("#form");
var jsubmit = $("#submit");
var referer = \''.url("plugin-setting-c_tinymce").'\';
jform.on(\'submit\', function(){
	jform.reset();
	jsubmit.button(\'loading\');
	var postdata = jform.serialize();
	$.xpost(jform.attr(\'action\'), postdata, function(code, message) {
		if(code == 0) {
			$.alert(message);
			jsubmit.text(message).delay(2000).button(\'reset\').location(referer);
			return;
		} else {
			$.alert(message);
			jsubmit.button(\'reset\');
		}
	});
	return false;
});
function c_tinymce(page){
document.querySelector(\'#c_tinymce-index\').style.fontWeight=(page==\'index\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-basic\').style.fontWeight=(page==\'basic\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-prism\').style.fontWeight=(page==\'prism\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-extra\').style.fontWeight=(page==\'extra\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-group\').style.fontWeight=(page==\'group\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-image\').style.fontWeight=(page==\'image\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-media\').style.fontWeight=(page==\'media\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce-clean\').style.fontWeight=(page==\'clean\')?\'bold\':\'\';
document.querySelector(\'#c_tinymce_index\').style.display=(page==\'index\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_basic\').style.display=(page==\'basic\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_prism\').style.display=(page==\'prism\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_extra\').style.display=(page==\'extra\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_group\').style.display=(page==\'group\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_image\').style.display=(page==\'image\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_media\').style.display=(page==\'media\')?\'\':\'none\';
document.querySelector(\'#c_tinymce_clean\').style.display=(page==\'clean\')?\'\':\'none\';
};
function c_tinymce_filter(text){
var map={\'&\':\'&amp;\',\'<\':\'&lt;\',\'>\':\'&gt;\',\'"\':\'&quot;\',"\'":\'&#039;\'};
return text.replace(/[&<>"\']/g,function(m){return map[m];});
};
function c_tinymce_trash(){
document.querySelector(\'#c_tinymce_trash\').innerHTML=\'\';
var xhr=new XMLHttpRequest;
xhr.open(\'GET\',\''.url('plugin-setting-c_tinymce').'?&trash\');
xhr.onreadystatechange=function(){
if(this.readyState===4 && this.status===200){
var json=JSON.parse(this.responseText);
for(var i=0;i<json.length;i++){
var tobj=new Date(parseInt(json[i].time));
document.querySelector(\'#c_tinymce_trash\').innerHTML+=\'<div><a href="../?user-\'+json[i].user+\'.htm" target="_blank">[\'+tobj.getFullYear()+\'-\'+(tobj.getMonth()+1)+\'-\'+tobj.getDate()+\']</a> <a href="../upload/attach/\'+json[i].date+\'/\'+json[i].user+\'_\'+json[i].time+\'.\'+json[i].type+\'" target="_blank">\'+(json[i].size/1048576).toFixed(2)+\' MB (\'+json[i].type+\')</a></div>\';
}
};
};
xhr.send(null);
};
function c_tinymce_clean(){
if(!confirm(\'确认清理？\')){return;};
var xhr=new XMLHttpRequest;
xhr.open(\'GET\',\''.url('plugin-setting-c_tinymce').'?&clean&csrf=\'+document.querySelector(\'input[name="csrf"]\').value);
xhr.onreadystatechange=function(){
if(this.readyState===4 && this.status===200){
c_tinymce_trash();
};
};
xhr.send(null);
};
c_tinymce_trash();
</script>';
}
?>
