<?php
!defined('DEBUG') AND exit('Forbidden');
kv_del('c_tinymce');
?>