elseif($action == 'sy'){
	
	$_uid = param(2, 0);
	
	$method != 'POST' AND message(-1, 'Method error');
	
	empty($group['allowdeleteuser']) AND message(-1, lang('insufficient_delete_user_privilege'));
	
	$u = user_read($_uid);
	empty($u) AND message(-1, lang('user_not_exists_or_deleted'));
	

	$r = db_update('user', array('uid'=>$_uid), array('lh_v'=>1));
	$r === FALSE AND message(-1, lang('delete_failed'));
	
	message(0, lang('delete_successfully'));
}elseif($action == 'de'){
	
	$_uid = param(2, 0);
	
	$method != 'POST' AND message(-1, 'Method error');
	
	empty($group['allowdeleteuser']) AND message(-1, lang('insufficient_delete_user_privilege'));
	
	$u = user_read($_uid);
	empty($u) AND message(-1, lang('user_not_exists_or_deleted'));
	

	$r = db_update('user', array('uid'=>$_uid), array('lh_v'=>0));
	$r === FALSE AND message(-1, lang('delete_failed'));
	
	message(0, lang('delete_successfully'));
}
