
		case 'go': include _include(APP_PATH.'plugin/ccreed_uri_redirect/route/uri_redirect.php'); break;