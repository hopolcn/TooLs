<?php
!defined('DEBUG') AND exit('Access Denied.');
if ($method == 'GET') {
    $cf_360seo = setting_get('cf_360seo');
    $code = $cf_360seo['code'];
    include _include(APP_PATH . 'plugin/cf_360seo/setting.htm');
} else {
    $code = param('code', '');
    $cf_360seo = array();
    $cf_360seo['code'] = $code;
    setting_set('cf_360seo', $cf_360seo);
    message(0, lang('save_successfully'));
}
?>