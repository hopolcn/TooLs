<?php
exit;
'upload_pic_by_attach_tips' => '不允许通过附件上传图片。请在编辑框内直接粘贴图片，或使用编辑器的 插入/编辑图片 功能。',
