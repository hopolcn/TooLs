<?php
exit;
'dog_licking_diary'=>'舔狗日记', 
'dog_refresh'=>'再来一篇', 