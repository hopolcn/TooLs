<?php
!defined('DEBUG') AND exit('Forbidden');

$kv=kv_get('cf_dog');
if(!$kv){
$kv = array();
$kv['dog_api'] = "https://cloud.qqshabi.cn/api/tiangou/api.php";

kv_set('cf_dog', $kv);
}
?>