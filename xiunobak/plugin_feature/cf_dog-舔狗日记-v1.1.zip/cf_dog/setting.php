<?php
/*
	Xiuno BBS 4.0 舔狗插件
	插件由云库论坛制作：https://cloudatabases.com
*/
!defined('DEBUG') AND exit('Access Denied.');
if($method == 'GET') {
	$kv = kv_get('cf_dog');
	$dog_api = $kv['dog_api'];
	
	include _include(APP_PATH.'plugin/cf_dog/setting.htm');
} else {
	$kv = array();
	$kv['dog_api'] = param('dog_api','',false);
	
	kv_set('cf_dog', $kv);
	message(0, lang('save_successfully'));
}
?>