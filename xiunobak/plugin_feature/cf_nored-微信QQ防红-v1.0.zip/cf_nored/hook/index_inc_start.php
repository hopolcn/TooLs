<?php
exit;
include _include(APP_PATH."plugin/cf_nored/model/rewrite.php");