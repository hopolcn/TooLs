<?php
exit;
'please_use_your_browser_to_open_it'=>'请使用浏览器打开',
