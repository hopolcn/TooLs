<?php exit;
case 'follows': include _include(APP_PATH . 'plugin/cgmix_follow/route/follows.php');break;

?>