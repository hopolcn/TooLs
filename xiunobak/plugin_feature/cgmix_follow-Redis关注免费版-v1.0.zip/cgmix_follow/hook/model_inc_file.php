<?php exit;
	APP_PATH.'plugin/cgmix_follow/model/redis.func.php',

?>