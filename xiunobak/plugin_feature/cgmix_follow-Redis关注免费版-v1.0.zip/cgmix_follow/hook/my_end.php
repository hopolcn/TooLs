elseif($action == 'follow') {

$user = user_read($uid);
user_login_check();
    if($method == 'GET'){
		user_update_group($uid);
	$page = param(2, 1);
	$pagesize = 20;
    $myguanzhu = $redis->smembers("user:$uid:following");
	$total =  count($myguanzhu);

$data = $redis->smembers("user:".$uid.":following");
$urlslist = array();
$i = 0;
foreach($data as $v){
if ($i % 2 == 1) {
		$urls[$i]['color'] = "table-secondary";
	} else {
		$urls[$i]['color'] = "table-light";
	}
    
    $follow_user = user_read($v);

   //   $row= $redis->hgetall("user:".$v);
      $followeds[$i]['avatar']=$follow_user['avatar_url'];
      $followeds[$i]['username']=$follow_user['username'];
      $followeds[$i]['id']=$follow_user['uid'];
      $followeds[$i]['create_date']=$follow_user['create_date'];
      $followeds[$i]['login_date']=$follow_user['login_date'];
      $followeds[$i]['threads']=$follow_user['threads'];
      $i++;
}


$pagination = pagination(url("my-url-{page}"), $total, $page, $pagesize);
        include _include(APP_PATH.'plugin/cgmix_follow/view/htm/my_follow.htm');
}elseif($method == 'POST') {
		
		// hook my_password_post_start.php
		
	
		$userid = param('userid');
		$urlid = param('urlid');
		$jifen = param('jifen');
		$addate = date('Y-m-d H:i:s');
		$siteurl = param('siteurl');
		$arr = db_find_one('user', array('uid'=>$userid),array(),array('golds'));
		if($arr['golds']<$jifen){
			message(1, lang('golds_no_enough'));
		}

		$r = tuijian_create(array('uid'=>$userid,'urlid'=>$urlid,'number'=>$jifen,'siteurl'=>$siteurl,'date'=>$addate),$urlid,$userid,$jifen);
		$r === FALSE AND message(-1, lang('method_error'));
		
		// hook my_password_post_end.php
		message(0, lang('golds_successfully'));
		
	}
}elseif($action == 'followed') {
    if($method == 'GET')
		user_update_group($uid);
	$page = param(2, 1);
	$pagesize = 20;
    $guanzhu = $redis->smembers("user:$uid:followers");
	$total = count($guanzhu);
$totaljifen= db_sql_find_one("SELECT SUM(number) as total
FROM bbs_links_ad
WHERE uid=$uid");

$data = $redis->smembers("user:".$uid.":followers");
$urlslist = array();
$i = 0;
foreach($data as $v){
if ($i % 2 == 1) {
		$urls[$i]['color'] = "table-secondary";
	} else {
		$urls[$i]['color'] = "table-light";
	}
    
    $follow_user = user_read($v);

   //   $row= $redis->hgetall("user:".$v);
      $followeds[$i]['avatar']=$follow_user['avatar_url'];
      $followeds[$i]['username']=$follow_user['username'];
      $followeds[$i]['id']=$follow_user['uid'];
      $followeds[$i]['create_date']=$follow_user['create_date'];
      $followeds[$i]['login_date']=$follow_user['login_date'];
      $followeds[$i]['threads']=$follow_user['threads'];
      $i++;
}

$pagination = pagination(url("my-history-{page}"), $total, $page, $pagesize);
        include _include(APP_PATH.'plugin/cgmix_follow/view/htm/my_followed.htm');

}