if($method == 'POST') {


		
		$follow_uid = param('follow_uid');			
        $my_uid = param('my_uid');	
        $follow_action = param('follow_action');
		empty($follow_uid) AND message('follow_uid', lang('please_select_follower'));
		empty($my_uid) AND message('my_uid', lang('please_login_option'));
		if($follow_uid==$my_uid){
        	message(-1,lang('follow_me_erro'));
 	   }elseif($follow_action == "1"){
       		$redis->del("user:".$my_uid.":following",$follow_uid);
  			$redis->del("user:".$follow_uid.":followers",$my_uid);
            
            //取消关注
 // $r->srem("following:".$user['userid'],$uid);
 // $r->srem("followed:".$uid,$user['userid']);
  		//	$redis->lrem("uid",$uid);       
       		message(-1,lang('follow_del'));
       }elseif($follow_action == "0"){
       
       
    
 	   //添加redis
 	   $redis->sadd("user:".$my_uid.":following",$follow_uid);            //关注了列表
	    $redis->sadd("user:".$follow_uid.":followers",$my_uid);            //被关注了列表
	//    echo "关注成功";
		message(0,lang('follow_successfully'));
//		message(0, lang('user_login_successfully'));
	}
}