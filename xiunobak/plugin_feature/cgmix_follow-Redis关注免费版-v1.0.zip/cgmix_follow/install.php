<?php
/*
 * Copyright (C) 燃烧的冰 81340116@qq.com
 */

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;



# cms主题附表
$sql = "CREATE TABLE {$tablepre}well_thread (
  `tid` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0', # 作者ID 非UID
  `source_id` int(11) NOT NULL DEFAULT '0', # 来源ID
  `tag` char(180) NOT NULL DEFAULT '',      # 标签 json
  `flag` char(20) NOT NULL DEFAULT '' COMMENT '属性',
  `mainpic_aid` int(11) NOT NULL DEFAULT '0', # 主图附件aid
  `mainpic` char(120) NOT NULL DEFAULT '' COMMENT '主图',
  `brief` char(120) NOT NULL DEFAULT '' COMMENT '摘要',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8";
$r = db_exec($sql);





// 初始化
$r === false AND message(-1, '创建数据表结构失败');

?>