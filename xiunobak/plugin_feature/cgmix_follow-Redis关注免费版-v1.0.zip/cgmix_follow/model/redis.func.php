<?php

require APP_PATH.'plugin/cgmix_follow/predis/autoload.php';
    //连接redis
    $redis = new Predis\Client(array(
        'host'=>'127.0.0.1',
        'port'=>6379
    ));
	/*
  //实例化
  $redis = new Redis();
  //连接服务器

  $a=$redis->connect("localhost",6379);
  //var_dump($a);
  //授权
  $redis->auth("107lab");
  */
  ?>