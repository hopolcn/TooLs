<?php
!defined('DEBUG') AND exit('Access Denied.');
$page = param(1, 1);
$orderby = param('orderby');
$pagesize = $conf['pagesize'];
// 从默认的地方读取主题列表
$thread_list_from_default = 1;
$active = 'default';
// hook forum_thread_list_before.php
!in_array($orderby, array('tid', 'lastpid')) AND $orderby = 'lastpid';
$extra['orderby'] = $orderby;
if($thread_list_from_default) {
	$order = 'lastpid';
//	$follows = array();
	$follows = $redis->smembers("user:".$uid.":following");
//	echo json_encode(count($follows));
	$cond = array('uid'=>$follows);
//	echo json_encode($cond);
	$i = 0;
	$followsthreads=0;

foreach($follows as $v){
    
    $follow_user = user_read($v);

   //   $row= $redis->hgetall("user:".$v);
      
      $followeds[$i]['threads']=$follow_user['threads'];
   $followsthreads+=$followeds[$i]['threads'];
      $i++;
}

/*
for($i = 0; $i <  count($follows); $i ++) {
	$follow_user[$i] = user_read($v);
	echo json_encode($follow_user[$i]);
	$followsthreads+=$follow_user[$i]['threads'];
}
*/
//	echo json_encode($cond);
	$orderby = array($order=>-1);
//	$threadss = thread_find($cond, $orderby, $page, 1);
	$threadlist = thread_find($cond, $orderby, $page, $pagesize);
	$pagination = pagination(url("follows-{page}", $extra), $followsthreads, $page, $pagesize);
//	echo json_encode($threadlist);
//echo json_encode($followsthreads);
}
//include _include(APP_PATH.'view/htm/forum.htm');
include _include(APP_PATH.'./plugin/cgmix_follow/view/htm/follows.htm');
?>