<?php

/*
	插件卸载文件
*/

!defined('DEBUG') AND exit('Forbidden');



?>