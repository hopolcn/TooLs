if (!empty($thread['user'])) {
 

// 移除敏感信息
unset($thread['user']['password']);
unset($thread['user']['salt']);
}