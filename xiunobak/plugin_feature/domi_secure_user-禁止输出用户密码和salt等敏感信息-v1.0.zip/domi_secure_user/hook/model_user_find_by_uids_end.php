if (!empty($r)) {
 

    foreach($r as &$user) {
        unset($user['password']);
        unset($user['salt']);
    }
 }