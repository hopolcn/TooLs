if (!empty($userlist['user'])) {
 

 // 移除敏感信息
 unset($userlist['user']['password']);
 unset($userlist['user']['salt']);
 }