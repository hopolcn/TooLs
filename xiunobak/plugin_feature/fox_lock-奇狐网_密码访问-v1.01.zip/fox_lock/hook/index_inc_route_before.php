<?php exit;
if($gid != 1){
    $lock_password = param('lock_password');
    if(!empty($lock_password) && $lock_password == $fox_lock_kv['lock_password']){
       $_SESSION['ok'] = 1;
       header('location:'.http_referer());
    }
    if(empty($_SESSION['ok'])){
        include _include(APP_PATH.'plugin/fox_lock/oddfox/core/fox_lock_theme.php');
        exit;
    }
}?>