<?php
/*
 * 奇狐网插件 安装文件
 * QQ:77798085
*/

!defined('DEBUG') AND exit('Forbidden');

$fox_lock_kv = kv_get('fox_lock');
if(empty($fox_lock_kv)) {
    $fox_lock_kv = array(
        'lock_password' => 'oddfox',
    );
    kv_cache_set('fox_lock', $fox_lock_kv);
}?>