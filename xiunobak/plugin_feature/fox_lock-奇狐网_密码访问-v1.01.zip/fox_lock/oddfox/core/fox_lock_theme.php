<?php include _include(APP_PATH.'view/htm/header.inc.htm');?>

<div class="row">
    <div class="col-lg-6 mx-auto">
        <div class="card">
            <div class="card-header">访问密码</div>
            <div class="card-body ajax_modal_body">
                <form method="post" id="form">                    
                    <div class="form-group input-group">
                        <div class="input-group-prepend"><span class="input-group-text"><i class="icon icon-lock icon-fw"></i></span></div>
                        <input type="password" class="form-control" placeholder="请输入访问密码" name="lock_password">
                        <div class="invalid-feedback"></div>
                    </div>                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block" id="submit">提交</button>
                    </div>
                </form>
            </div>
        </div>        
    </div>
</div>

<?php include _include(APP_PATH.'view/htm/footer.inc.htm');?>