<?php
/*
 * 奇狐网插件 安装文件
 * QQ:77798085
 */

!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET'){
    $fox_lock_password = form_text('lock_password', $fox_lock_kv['lock_password']);
    include _include(APP_PATH.'plugin/fox_lock/oddfox/core/fox_admin_setting.php');
}elseif($method == 'POST'){
    $fox_lock_kv = array();
    $fox_lock_kv['lock_password'] = param('lock_password');
    kv_cache_set('fox_lock', $fox_lock_kv);
    message(0, '设置成功');
}else{
    message(-1, 'Access Denied.');
}
?>