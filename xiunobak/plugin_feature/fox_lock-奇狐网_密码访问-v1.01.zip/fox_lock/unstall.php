<?php
/*
 * 奇狐网插件 卸载文件
 * QQ:77798085
*/

!defined('DEBUG') AND exit('Forbidden');

kv_cache_delete('fox_lock');
?>