<?php
/*
 * 奇狐网 安装文件
 * QQ:77798085
*/
!defined('DEBUG') AND exit('Forbidden');

?>