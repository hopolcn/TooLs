<?php exit;
case 'foxqr': include _include(APP_PATH.'plugin/fox_qrcode/fox/fox_qr_code.php'); break;
?>