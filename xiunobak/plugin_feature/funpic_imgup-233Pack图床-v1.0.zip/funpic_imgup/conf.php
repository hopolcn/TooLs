<?php
/* 【开始】配置 */

$data = array (
    'panels' => array (
        'funpic' => array(
            'title' => '233Pack图片托管',
            'sections' => array(
                'config' => array(
                    'title' => '设置',
                    'description' => '<p>由 <strong>233Pack</strong> 提供的中小站点图片托管服务。您可以前往<a href="https://image.233213.xyz/" target="_blank">官网</a>去<a href="https://image.233213.xyz/register" target="_blank">注册</a>。
        使用即代表您已经同意我们的<a href="https://image.233213.xyz/static/tos.html" target="_blank">用户协议</a>。</p>',
                    'options' => array(
                        'email' => array(
                            'label' => '邮箱',
                            'type' => 'text',
                            'default' => '',
                        ),
                        'password' => array(
                            'label' => '密码',
                            'type' => 'password',
                            'default' => '',
                        ),
                        'token' => array(
                            'label' => 'Token',
                            'type' => 'text',
                            'default' => '',
                            'description' => '登录后自动生成。',
                        ),
                        'tinymce_version' => [
                            'label' => 'TinyMCE编辑器版本',
                            'description' => '若您未使用TinyMCE，请忽略',
                            'type' => 'radio',
                            'default' => 6,
                            'choices' => [
                                        5=>5,
                                        6=>6
                             ]
                          ]
                    ),
                ),
            ),
        ),
    ),
    'kumquat_config' => array(
        'allow_delete_plugin_settings' => true,
        'allow_reset_settings' => false,
    ),
    'kumquat_flag' => array(
        'delete_plugin_settings' => false,
        'reset_settings' => false,
    ),
    'THIS_LOCATION_FRONTEND' => './'.PLUGIN_DIR,
    'THIS_LOCATION' => PLUGIN_DIR,
);

/* 【结束】配置 */
?>