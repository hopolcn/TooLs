case 'imageupload':
    include _include(APP_PATH.'plugin/funpic_imgup/route/imageupload.php');
    break;