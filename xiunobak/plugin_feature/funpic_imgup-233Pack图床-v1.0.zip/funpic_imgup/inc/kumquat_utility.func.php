<?php 
/* 【开始】金桔框架——实用函数 */

/** 
 * 颜色转换为 RGB
 * 
 * @param string $color 颜色的十六进制代码（例如 #abcdef）
 * @return string RGB 值数组
 */
function hexrgb($color){
    if (isset($color[0])&&$color[0] == '#')
        $color = substr($color, 1);

    if (strlen($color) == 6)
        list($r, $g, $b) = array($color[0].$color[1],
                                 $color[2].$color[3],
                                 $color[4].$color[5]);
    elseif (strlen($color) == 3)
        list($r, $g, $b) = array($color[0].$color[0], $color[1].$color[1], $color[2].$color[2]);
    else
        return false;

    $r = hexdec($r); $g = hexdec($g); $b = hexdec($b);

    return $r.', '.$g.', '.$b;
}

/**
 * 颜色转换为HSL
 * @param string $color 颜色的十六进制代码（例如 #abcdef）
 * @return string RGB 值数组
 */

 function hexToHsl($hex)
{
    $red = hexdec(substr($hex, 0, 2)) / 255;
    $green = hexdec(substr($hex, 2, 2)) / 255;
    $blue = hexdec(substr($hex, 4, 2)) / 255;

    $cmin = min($red, $green, $blue);
    $cmax = max($red, $green, $blue);
    $delta = $cmax - $cmin;

    if ($delta === 0) {
        $hue = 0;
    } elseif ($cmax === $red) {
        $hue = (($green - $blue) / $delta) % 6;
    } elseif ($cmax === $green) {
        $hue = ($blue - $red) / $delta + 2;
    } else {
        $hue = ($red - $green) / $delta + 4;
    }

    $hue = round($hue * 60);
    if ($hue < 0) {
        $hue += 360;
    }

    $lightness = (($cmax + $cmin) / 2) * 100;
    $saturation = $delta === 0 ? 0 : ($delta / (1 - abs(2 * $lightness - 1))) * 100;
    if ($saturation < 0) {
        $saturation += 100;
    }

    $lightness = round($lightness);
    $saturation = round($saturation);

    return "${hue}, ${saturation}%, ${lightness}%";
}

/**
 * 截取字符串（指定开始和结束的字符串）
 *
 * @param string $str 要截取的字符串
 * @param string $start 从哪个字符串开始截取
 * @param string $end 截取到哪个字符串结束
 * @param int $start_offset 字符串开始处偏移量（可根据自己需要修改）
 * @param int $end_offset 字符串结束处偏移量（可根据自己需要修改）
 * @return string 截取的字符串
 */
function str_get_between($str,$start,$end,$start_offset = 0,$end_offset = 0) {
  $haystack = $str;
  $haystack = '!!!'.$haystack.'!!!';
  $start_pos = strripos($haystack,$start);
  $end_pos = strripos($haystack,$end);
  if ( ($start_pos == false || $end_pos == false) || $start_pos >= $end_pos ) {
    return false;
  }
  $haystack = substr( $haystack, ($start_pos+$start_offset), ($end_pos-$start_pos-$end_offset) );
  return $haystack;
}

/**
* 金桔框架——校验——日期
* @param string $input 要校验的日期
* @return string 格式正确的日期（年-月-日）
*/
function kumquat_sanitize_date( $input ) {
$date = new DateTime( $input );
return $date->format('Y-m-d');
}

/**
 * 金桔框架——获取设置项的值
 * 如果未定义就获取默认值
 * @param $option_name 设置项的名字
 * @param $settings 在这里寻找
 * @param $default 默认值
 */
function kumquat_get_option_value ($option_name, $settings, $default = NULL) {
    if (isset($settings) && isset($settings[$option_name])) {
        return $settings[$option_name];
    } else if (!is_null($default)) {
        return $default;
    } else {
        return 'undefined';
    }
}

/**
 * 金桔框架——保存设置按钮
 * @param bool $full_width 是否为全宽度
 * @param string $color 按钮的颜色
 */
function kumquat_save_button($full_width = false, $color = 'primary') {
    $full_width_add = '';
    $full_width == true ? $full_width_add = ' btn-block' : '';
    $result = '<button type="submit" class="btn btn-'.$color.$full_width_add.'" id="submit" data-loading-text="'.lang('submiting').'...">'.lang('save').lang('setting').'</button>';
    return $result;
}
/**
 * 金桔框架——唤起重置设置弹窗按钮
 * @param string $color 按钮的颜色
 */
function kumquat_reset_modal_button($color = 'outline-secondary') {
    $result = '<button type="button" class="btn btn-kumquatResetModal btn-'.$color.'" data-toggle="modal" data-target="#kumquatResetModal">'.lang('Reset').lang('setting').'</button>';
    return $result;
}

/**
 * 金桔框架——重置设置按钮
 * @param string $color 按钮的颜色
 */
function kumquat_reset_button($color = 'danger') {
    $result = '<input type="hidden" name="kumquat_flag/reset_settings" value="1">'.'<button type="button" class="btn btn-'.$color.'" id="kumquat_reset_confirm">'.lang('Reset').lang('setting').'</button>';
    return $result;
}

/**
 * 金桔框架——组装CSS样式——字体
 * @param array $setting_value 设置项
 * @return string 符合CSS标准的font值
 */
function kumquat_css_font_assemble($setting_value) {
    if ( !isset($setting_value['font-size_unit']) ) {
        $setting_value['font-size_unit'] = 'px';
    }
    return $setting_value['font-style']
    .' '
    .$setting_value['font-weight']
    .' '
    .$setting_value['font-size']
    .$setting_value['font-size_unit']
    .'/'
    .$setting_value['line-height']
    .' '
    .$setting_value['font-family'];
}

/**
 * 金桔框架——组装CSS样式——背景图片
 * @param array 符合CSS标准的background值
 */
function kumquat_css_background_image_assemble($setting_value) {
    $result = 'url('
    .$setting_value['background-url']
    .') '
    .$setting_value['background-repeat']
    .' ';
    if ( 'initial' != $setting_value['background-attachment'] ) {
        $result .= $setting_value['background-attachment'] . ' ';
    }
    $result .= $setting_value['background-position']
    .' / '
    .$setting_value['background-size'];
    
    return $result ;
}

/* 【结束】金桔框架——实用函数 */