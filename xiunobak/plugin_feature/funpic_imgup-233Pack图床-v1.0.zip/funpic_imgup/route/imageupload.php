<?php

if (!function_exists('funpic_get_setting')) {
    function funpic_get_setting($plugin_id, $setting_id) {
        if (empty($plugin_id) || empty($setting_id)) {
            return NULL;
        } else {
            $plugin_settings = setting_get($plugin_id . '_setting'); 
            if (isset($plugin_settings) && isset($plugin_settings[$setting_id])) {
                return $plugin_settings[$setting_id];
            } else {
                return NULL;
            }
        }
    }
}

!defined('DEBUG') and exit('Access Denied.');
set_time_limit(3600);
ini_set('memory_limit', '128M');

$token = funpic_get_setting('funpic_imgup', 'funpic/config/token');

if ($method == 'POST') {
    $file = $_FILES['file'];
    if (!$file) {
        message(1, 'No file uploaded.');
    }

    $headers = array(
        'Authorization: Bearer ' . $token
    );

    $pvars = array(
        'file' => new CURLFile($file['tmp_name'], $file['type'], $file['name'])
      
    );

    $inquire = curl_init();
    curl_setopt_array($inquire, array(
        CURLOPT_URL => 'https://image.233213.xyz/api/v1/upload',
        CURLOPT_TIMEOUT => 60,
        CURLOPT_POST => 1,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => $pvars,
        CURLOPT_SSL_VERIFYHOST => FALSE,
        CURLOPT_SSL_VERIFYPEER => FALSE,
    ));

    $response = curl_exec($inquire);
    $err = curl_error($inquire);
    curl_close($inquire);

    if ($err) {
        message(1, $err);
    } else {
        $response = json_decode($response, true);
        if ($response['status'] != true) {
            message(1, $response['message']);
        } else {
            $html = $response['data']['links']['html'];
            message(0, $html);
        }
    }
} else {
    message(1, 'Bad Request');
}
?>