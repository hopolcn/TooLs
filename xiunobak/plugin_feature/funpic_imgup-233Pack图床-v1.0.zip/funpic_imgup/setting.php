<?php
!defined('DEBUG') and exit('Access Denied.');
/* 【开始】金桔框架——常量定义 */
//如果网站在子目录下，这个很有必要
$BASE_URL = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$BASE_URL = empty($BASE_URL) ? '/' : '/' . trim($BASE_URL, '/') . '/';
//网站的URL
define('WEBSITE_DIR', $_SERVER["HTTP_HOST"] . $BASE_URL);
//这个插件的文件夹URL
define('PLUGIN_DIR', 'plugin/' . param(2) . '/');
//这个插件的view文件夹URL
define('PLUGIN_VIEW_DIR', WEBSITE_DIR . PLUGIN_DIR . "view/");
//插件ID
define('PLUGIN_NAME', param(2));
//插件的conf.json文件
$plugin_profile_file = file_get_contents(APP_PATH . PLUGIN_DIR . 'conf.json');
//插件的conf
$PLUGIN_PROFILE = json_decode($plugin_profile_file, true);
//插件设置
$PLUGIN_SETTING = setting_get(PLUGIN_NAME . '_setting');
//金桔框架的位置
$kumquat_location = APP_PATH . PLUGIN_DIR . '/inc/';
//导入框架所需文件
include_once($kumquat_location . 'kumquat_utility.func.php');
include_once($kumquat_location . 'kumquat_core.func.php');
include_once($kumquat_location . 'kumquat_form.func.php');
include_once(APP_PATH . PLUGIN_DIR . 'conf.php');
/* 【结束】金桔框架——常量定义 */

if ($method == 'GET') {
    // 检查 token 并请求 profile 数据
    $profile_data = null;
    $token = $PLUGIN_SETTING['funpic/config/token'];
    if ($token) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://image.233213.xyz/api/v1/profile');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_TIMEOUT, 10); // 设置超时时间为10秒
        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
        }
        curl_close($ch);
        if (isset($error_msg)) {
            $profile_data = array('error' => '无法加载储存信息: ' . $error_msg);
        } else {
            $response = json_decode($response, true);
            if ($response['status']) {
                $profile_data = $response['data'];
            } else {
                $profile_data = array('error' => '无法加载储存信息: ' . $response['message']);
            }
        }
    }
    // 显示设置页面
    include _include(APP_PATH . PLUGIN_DIR . 'setting.htm');
} else {
    // 保存设置
    $PLUGIN_SETTING = kumquat_save_setting($data);

    // 从 $PLUGIN_SETTING 中获取 email 和 password
    $email = $PLUGIN_SETTING['funpic/config/email'];
    $password = $PLUGIN_SETTING['funpic/config/password'];

    if ($email && $password) {
        // 请求获取 token
        $postdata = json_encode(array('email' => $email, 'password' => $password));
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://image.233213.xyz/api/v1/tokens');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $response = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($response, true);
        if ($response['status']) {
            $token = $response['data']['token'];
            $PLUGIN_SETTING['funpic/config/token'] = $token;
            // 保存更新后的设置
            setting_set(PLUGIN_NAME . '_setting', $PLUGIN_SETTING);
            message(0, '信息保存成功，请自行刷新本页面');
        } else {
            message(1, '获取 Token 失败: ' . $response['message']);
        }
    } else {
        message(1, '邮箱和密码是必填项。');
    }
}