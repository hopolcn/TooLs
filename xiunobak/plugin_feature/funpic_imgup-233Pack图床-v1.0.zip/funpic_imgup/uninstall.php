<?php

!defined('DEBUG') AND exit('Forbidden');

define('PLUGIN_DIR', 'plugin/'.param(2).'/');
define('PLUGIN_NAME', param(2));

$PLUGIN_SETTING = setting_get(PLUGIN_NAME.'_setting');

if ($PLUGIN_SETTING['kumquat_flag/delete_plugin_settings']) {
    setting_delete(PLUGIN_NAME.'_setting');
}

?>