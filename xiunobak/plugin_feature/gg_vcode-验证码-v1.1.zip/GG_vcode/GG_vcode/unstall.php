<?php

!defined('DEBUG') AND exit('Forbidden');

 kv_delete('GG_vcode');

?>