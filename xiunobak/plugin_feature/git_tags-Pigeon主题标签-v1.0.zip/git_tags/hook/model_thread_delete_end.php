<?php exit;
// 删除主题时删除标签
tag_del($tid, 'all');
