<?php exit;
case 'tag': include APP_PATH.'plugin/git_tags/route/tag.php'; break;