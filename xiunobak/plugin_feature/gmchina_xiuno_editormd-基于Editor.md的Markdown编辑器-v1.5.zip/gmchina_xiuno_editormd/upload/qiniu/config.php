<?php
        return array(
            'bucket' => 'bucket',
            'accessKey' => 'accessKey',
            'secretKey' => 'secretKey',
            'class_type' => 'class_type',
            'cdnurl' => 'cdnurl',
            'mimetype' => 'jpg,png,bmp,jpeg,gif',
        );