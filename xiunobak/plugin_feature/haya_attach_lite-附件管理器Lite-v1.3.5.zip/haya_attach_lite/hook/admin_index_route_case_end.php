<?php 
exit;

case 'attachlite':	
	include _include(APP_PATH.'plugin/haya_attach_lite/route/attach.php'); 
	break;
	
?>