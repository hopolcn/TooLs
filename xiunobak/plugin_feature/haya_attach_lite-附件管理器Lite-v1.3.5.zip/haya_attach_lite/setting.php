<?php

defined('DEBUG') OR exit('Forbidden');

http_location(url('attachlite'));
