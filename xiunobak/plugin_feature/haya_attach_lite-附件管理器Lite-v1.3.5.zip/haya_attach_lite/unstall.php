<?php

defined('DEBUG') OR exit('Forbidden');

// 删除插件配置
setting_delete('haya_attach_lite'); 

?>
