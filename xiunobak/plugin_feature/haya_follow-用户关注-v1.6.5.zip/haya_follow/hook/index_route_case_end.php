<?php
exit;

case 'follow': 
	include _include(APP_PATH.'plugin/haya_follow/route/follow.php'); 
	break;
	
?>