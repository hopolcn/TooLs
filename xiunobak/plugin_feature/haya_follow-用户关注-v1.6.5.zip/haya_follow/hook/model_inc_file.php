<?php
exit;

APP_PATH.'plugin/haya_follow/model/haya_follow.func.php',


?>