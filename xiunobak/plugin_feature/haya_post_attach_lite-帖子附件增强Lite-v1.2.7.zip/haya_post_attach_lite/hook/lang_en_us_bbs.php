<?php
exit;

'haya_post_attach_lite_filesize' => 'filesize',
'haya_post_attach_lite_downloads' => 'downloads',
'haya_post_attach_lite_open' => 'see the picture',

?>