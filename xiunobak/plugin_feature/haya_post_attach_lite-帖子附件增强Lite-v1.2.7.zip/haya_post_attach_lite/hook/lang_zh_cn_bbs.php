<?php
exit;

'haya_post_attach_lite_filesize' => '大小',
'haya_post_attach_lite_downloads' => '下载次数',
'haya_post_attach_lite_open' => '查看详情',

?>