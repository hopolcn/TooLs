<?php
exit;

'haya_post_attach_lite_filesize' => '大小',
'haya_post_attach_lite_downloads' => '下載次數',
'haya_post_attach_lite_open' => '查看詳情',

?>