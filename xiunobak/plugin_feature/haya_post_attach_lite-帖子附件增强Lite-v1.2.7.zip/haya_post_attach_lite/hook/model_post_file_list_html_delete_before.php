<?php
exit;

$s .= "<span class='text-grey ml-1'>(".lang("haya_post_attach_lite_filesize")."：".humansize($attach['filesize'])."，".lang("haya_post_attach_lite_downloads")."：".intval($attach['downloads']).")</span>";

?>
