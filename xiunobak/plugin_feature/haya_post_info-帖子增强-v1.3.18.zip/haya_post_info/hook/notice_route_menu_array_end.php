<?php
exit;

156 => array(
	'url' => url('my-notice-156'), 
	'name' => '@我',
	'class' => 'info',
	'icon' => ''
),

?>