<?php exit;
    $thread['reply_to_view'] = $arr['reply_to_view'];
?>