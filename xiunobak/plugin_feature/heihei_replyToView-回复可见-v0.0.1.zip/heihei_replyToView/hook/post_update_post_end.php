<?php exit;

// 增加一条编辑历史 $pid, $uid, $time, $message
$reply_to_view = param('replyToView');

if($reply_to_view == 1)
	$reply_to_view = 1;
	else $reply_to_view = 0;

thread__update($tid, array('reply_to_view'=>$reply_to_view));

?>