<?php exit;
$thread['reply_to_view'] = 0;
?>