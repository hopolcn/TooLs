<?php exit;

$reply_to_view = param('replyToView');

if($reply_to_view == 1)
	$reply_to_view = 1;
    else $reply_to_view = 0;

    $thread['reply_to_view'] = $reply_to_view;
?>