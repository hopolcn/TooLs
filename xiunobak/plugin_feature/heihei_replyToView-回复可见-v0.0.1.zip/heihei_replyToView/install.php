<?php

/*
	Xiuno BBS 4.0 插件：回复可见
*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

$sql = "ALTER TABLE {$tablepre}thread ADD COLUMN reply_to_view tinyint(1) NOT NULL default '0'";
$r = db_exec($sql);

// $r === FALSE AND message(-1, '创建表结构失败'); // 中断，安装失败。

?>