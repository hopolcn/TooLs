<?php

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

$sql = "ALTER TABLE {$tablepre}thread DROP COLUMN reply_to_view";
$r = db_exec($sql);


?>