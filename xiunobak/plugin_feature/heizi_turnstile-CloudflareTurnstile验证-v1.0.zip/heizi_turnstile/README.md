# XiunoBBS Turnstile插件
让您的论坛支持Cloudflare Turnstile

## 教程?
官方文档:  https://developers.cloudflare.com/turnstile/
