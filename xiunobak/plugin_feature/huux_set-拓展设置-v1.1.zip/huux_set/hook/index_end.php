<?php exit;

$header['keywords'] = empty($conf['site_keywords']) ? '': $conf['site_keywords'];

?>