		$input['seo_keywords'] = form_text('seo_keywords', $_forum['seo_keywords']);
