		$seo_keywords = param('seo_keywords');
		
		$arr = array (
			'name' => $name,
			'rank' => 1,
			'seo_keywords' => $seo_keywords,
			'brief' => $brief,
			'announcement' => $announcement,
			'moduids' => $moduids,
			'accesson' => $accesson,
		);