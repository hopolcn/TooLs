	$header['keywords'] = $header['title'];
	!empty($conf['keywords']) AND $header['keywords'] = $conf['keywords']."，".$header['keywords'];