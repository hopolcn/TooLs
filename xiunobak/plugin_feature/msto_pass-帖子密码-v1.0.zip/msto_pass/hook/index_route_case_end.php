case 'pass': include _include(APP_PATH.'plugin/msto_pass/route/pass.php'); break;



