<?php

if($c == 'ckpass'){
	$ps = isset($_POST['ps'])?$_POST['ps']:'';     
	$rs =  $db->getdata("select content,pass from `Log` where id=:id",array('id'=>$id));
	$_ps = $rs[0]['pass'];
	//print_r($rs);
	if($_ps==$ps){
	logmsg(1,$rs[0]['content']);
	}else{
	logmsg(0,'密码错误！');
	}
	
}


if($c=='savelog'){
	chkadm();  
	$arr['content'] = $_POST['logs'];	
	$arr['sum'] = strip_tags($_POST['sum']);	
	$arr['title'] = $_POST['tit'];
	$arr['pass'] = $_POST['pass'];
	$arr['pic'] = $_POST['pic'];
	$c = $_POST['c'];	
	 
	  if(empty($arr['sum'])){
		  if(empty($arr['pass'])){
		      $arr['sum'] = mb_substr(strip_tags($arr['content']),0,100,'utf-8');
		   }else{
		      $arr['sum'] = '这是一篇密码日志！';
		  }
	    
	  }


	if($c=='add'){
    $arr['fm'] = '网页';
	$b =  $db->runsql("insert into `Log`(title,sum,content,pic,fm,pass)values(:title,:sum,:content,:pic,:fm,:pass)",$arr);
	}else{
		$arr['id'] = $id;
		$arr['atime'] = $_POST['atime'];
		//print_r($arr);
	    $b =  $db->runsql("update `Log` set title=:title,sum=:sum,content=:content,pic=:pic,pass=:pass,atime=:atime where id=:id",$arr);
	}
	logmsg($b);
}
