         $kv = kv_cache_get('mw_limit');
         $reply = $kv['reply'];
		$createDate = db_find_one('post', array('uid' => $uid,'isfirst' => 0), array('create_date'=>-1), array('create_date'));  
		$createDate = $createDate['create_date'];
        // 加上30秒
        $createDateAfter30Seconds = $createDate + $reply;
        // 获取当前时间戳
        $currentTimestamp = time();
        // 判断是否大于当前时间戳
        if ($reply !=0 && $createDateAfter30Seconds > $currentTimestamp) {
			message(-1, '回帖时间间隔不得少于'.$reply.'秒');
		}