
        $kv = kv_cache_get('mw_limit');
        $update = $kv['update']; 
		$createDate = $post['create_date'];
        // 加上秒
        $createDateAfter30Seconds = $createDate + $update * 60;
        // 获取当前时间戳
        $currentTimestamp = time();
        // 判断
        if ($update !=0 && $createDateAfter30Seconds < $currentTimestamp) {
			message(-1, '该帖子发布<span style="color:red;">已超过'.$update.'分钟</span>，不可编辑！');
		}	