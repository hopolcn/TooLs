        $kv = kv_cache_get('mw_limit');
        $threadlimit = $kv['thread'];
		$createDate = db_find_one('post', array('uid' => $uid,'isfirst' => 1), array('create_date'=>-1), array('create_date'));  
		$createDate = $createDate['create_date'];
        // 加上30秒
        $createDateAfter30Seconds = $createDate + $threadlimit * 60;
        // 获取当前时间戳
        $currentTimestamp = time();
        // 判断是否大于当前时间戳
        if ($threadlimit !=0 && $createDateAfter30Seconds > $currentTimestamp) {
			message(-1, '发帖时间间隔不得少于'.$threadlimit.'分钟');
		}	