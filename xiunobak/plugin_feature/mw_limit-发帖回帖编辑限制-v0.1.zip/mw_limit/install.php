<?php
!defined('DEBUG') AND exit('Forbidden');

$kv=kv_cache_get('mw_limit');
if(!$kv){ 
	$kv = array();
	$kv['thread'] = 15;
	$kv['reply'] = 30;
	$kv['update'] = 20;

	kv_cache_set('mw_limit', $kv);
}
?>