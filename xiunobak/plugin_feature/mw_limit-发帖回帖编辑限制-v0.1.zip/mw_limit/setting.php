<?php
/*
	Xiuno BBS 4.0 Plugin: mw_limit
	Powered by https://moyu.lu
*/
!defined('DEBUG') AND exit('Access Denied.');
if($method == 'GET') {
	$kv = kv_get('mw_limit');
	$thread = $kv['thread'];
	$reply = $kv['reply'];
	$update = $kv['update'];
	
	include _include(APP_PATH.'plugin/mw_limit/setting.htm');
} else {
	$kv = array();
	$kv['thread'] = param('thread', 0);
	$kv['reply'] = param('reply', 0);
	$kv['update'] = param('update', 0);
	
	kv_set('mw_limit', $kv);
	message(0, lang('save_successfully'));
}
?>