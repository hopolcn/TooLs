<?php
!defined('DEBUG') AND exit('Forbidden');  
kv_delete('mw_limit');
?>