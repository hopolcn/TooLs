if(!empty($readperm) && in_array($readperm, $allowedGids)) {
$perm = db_find_one('mw_readperm', array('tid'=>$tid));	 
if($perm){
db_update('mw_readperm',array('tid'=>$tid),array('readperm'=>$readperm));
}else{
$arr =  array(
'uid'=>$uid,
'tid'=>$tid,
'readperm'=>$readperm,
'create_date'=>$time,
);
db_insert('mw_readperm', $arr);	
}
}