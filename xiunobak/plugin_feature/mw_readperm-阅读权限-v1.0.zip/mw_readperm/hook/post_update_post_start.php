$readperm=param('readperm');
$allowedGids = array(101, 102, 103, 104, 105, 5);
if(!empty($readperm)  && !in_array($readperm, $allowedGids)) {
	message(-1, '不要瞎搞。。');
}