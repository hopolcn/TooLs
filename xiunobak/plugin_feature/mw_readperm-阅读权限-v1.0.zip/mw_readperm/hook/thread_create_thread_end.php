if(!empty($readperm)){
$arr =  array(
'uid'=>$uid,
'tid'=>$tid,
'readperm'=>$readperm,
'create_date'=>$time,
);
db_insert('mw_readperm', $arr);
}