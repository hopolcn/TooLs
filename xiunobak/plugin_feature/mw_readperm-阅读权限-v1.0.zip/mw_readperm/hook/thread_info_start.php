$readperm = db_find_one('mw_readperm', array('tid'=>$tid));
 if(!empty($readperm)){
$perm = $readperm['readperm'];   //数据库中存储的权限
$permuid = $readperm['uid'];   //数据库中存储的权限 

if ($uid == $permuid || ($perm <= $gid && $perm > 100) || $gid < 6) {
} else {
	if($perm == 5){
    message(-1, '本帖阅读权限为私有。');
	}else{message(-1, '本帖阅读权限为'.$perm.'，您的权限不够。');}
}
}