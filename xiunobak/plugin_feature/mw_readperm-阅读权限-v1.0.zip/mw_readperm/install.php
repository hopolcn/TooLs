<?php !defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}mw_readperm (
    permid bigint(11) unsigned NOT NULL AUTO_INCREMENT,
	tid int(11) unsigned NOT NULL COMMENT '帖子id',
    uid int(11) unsigned NOT NULL COMMENT '用户ID',
    readperm int(3) unsigned NOT NULL DEFAULT '0',
	create_date int(11)  DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (permid)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8";
db_exec($sql); 
?>