<?php exit;
elseif($action == 'ob_email') {
    //设置网页标题
	$header['title'] = lang('ob_email');
    $header['mobile_title'] = lang('ob_email');
    $fidarray = param('fid',array());
	if($method == 'GET') {
		$ob_email_t = kv_get('ob_email_t');
		if(!$ob_email_t) {
			$ob_email_t = array(
				'sendname'=>$conf['sitename'],
				'crus_subject'=>"用户注册",
				'crus_message'=>"您的验证码为：{code}，该验证码5分钟内有效，请及时输入。<br><br>为保证账号安全，请勿泄漏此验证码。<br>(这是一封自动发送的邮件，请不要直接回复)",
				'repw_subject'=>"密码重置",
				'repw_message'=>"您的验证码为：{code}，该验证码5分钟内有效，请及时输入。<br><br>为保证账号安全，请勿泄漏此验证码。<br>(这是一封自动发送的邮件，请不要直接回复)",
				);	
		}
		$input = array();
		$input['sendname'] = form_text('sendname', $ob_email_t['sendname']);
		$input['crus_subject'] = form_text('crus_subject', $ob_email_t['crus_subject']);
		$input['crus_message'] = form_textarea('crus_message', $ob_email_t['crus_message'], '100%', 60);
		$input['repw_subject'] = form_text('repw_subject', $ob_email_t['repw_subject']);
		$input['repw_message'] = form_textarea('repw_message', $ob_email_t['repw_message'], '100%', 60);
		include _include(APP_PATH.'plugin/ob_email/view/setting.htm'); // 这里包含一个插件配置界面文件	
	} else {

		$array = array();
		$array['sendname'] = param('sendname', '', FALSE);
		$array['crus_subject'] = param('crus_subject', '', FALSE);
		$array['crus_message'] = param('crus_message', '', FALSE);
		$array['repw_subject'] = param('repw_subject', '', FALSE);
		$array['repw_message'] = param('repw_message', '', FALSE);
		kv_set('ob_email_t',$array);
		// file_replace_var(APP_PATH.'conf/conf.php', $replace);
	    message(0, lang('save_successfully'));
	
	}

}
?>