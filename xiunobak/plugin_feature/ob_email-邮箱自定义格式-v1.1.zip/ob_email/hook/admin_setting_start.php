<?php exit;
$menu['setting']['tab'] += array(
'ob_email'=>array('url'=>url('setting-ob_email'),
'text'=>lang('ob_email_setting')),
);
?>