<?php
exit;
'ob_email' => '邮箱设置',
'ob_email_setting'=>'邮箱设置',

'sendname'=>'发件人',

'crus_subject' => '注册发件标题',
'crus_message' => '注册发件内容',
'crus_message_tip' => '输入注册邮件内容，用{code}表示验证码，支持HTML',

'repw_subject' => '密码重置标题',
'repw_message' => '密码重置内容',
'repw_message_tip' => '输入密码重置邮件内容，用{code}表示验证码，支持HTML',
