<?php exit;
$ob_email_t = kv_get('ob_email_t');
if ($action2 == 'user_create') {
    $conf['sitename'] = $ob_email_t['sendname'];
    $subject = $ob_email_t['crus_subject'];
    $message = $ob_email_t['crus_message'];
} elseif ($action2 == 'user_resetpw') {
    $conf['sitename'] = $ob_email_t['sendname'];
    $subject = $ob_email_t['repw_subject'];
    $message = $ob_email_t['repw_message'];
}
$message_out = preg_match('/{code}/', $message, $message_arr);
if ($message_out) {
    $message = str_replace($message_arr, $code, $message);
}
