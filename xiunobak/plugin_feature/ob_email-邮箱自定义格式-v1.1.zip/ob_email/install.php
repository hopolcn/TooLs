<?php
/*
	Xiuno BBS 4.0 黑色主题
*/
!defined('DEBUG') AND exit('Forbidden');
?>