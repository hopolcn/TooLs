<?php exit;
    global $route, $tid, $uid, $thread, $gid;
    if($route == 'thread'){
        //查询当前登录会员是否已经回复当前主题
        $q = db_find_one('post', array('tid'=>$tid, 'isfirst'=>0, 'uid'=>$uid));
        
        //判断用户是否已登录
        if($uid != $thread['uid'] && empty($q) && $gid !=1){            
            $str  = '<fieldset class="fieldset m-0">';
            $str .= '<legend>本帖中包含附件</legend>';
            $str .= '<i class="icon-bell"></i> 如需下载请先<span class="text-danger">回复并刷新</span>本帖！';
            $str .= '</fieldset>';
            return $str;
        }
    }
?>