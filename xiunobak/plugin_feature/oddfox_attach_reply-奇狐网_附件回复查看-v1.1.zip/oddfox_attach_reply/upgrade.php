<?php
/*
 * 奇狐插件 升级文件
 * QQ:77798085
 */

!defined('DEBUG') AND exit('Forbidden');

//删除旧版废弃的文件
$path = APP_PATH.'plugin/oddfox_attach_reply/hook/thread_filelist_after.htm';
xn_unlink($path);

$path = APP_PATH.'plugin/oddfox_attach_reply/hook/thread_message_after.htm';
xn_unlink($path);

$path = APP_PATH.'plugin/oddfox_attach_reply/install.php';
xn_unlink($path);

$path = APP_PATH.'plugin/oddfox_attach_reply/unstall.php';
xn_unlink($path);
?>