<?php
/*
 * 奇狐插件 升级文件
 * QQ:77798085
 */

!defined('DEBUG') AND exit('Forbidden');

//删除旧版废弃的文件
xn_unlink(APP_PATH.'plugin/oddfox_shang/hook/header_bootstrap_bbs_after.htm');
xn_unlink(APP_PATH.'plugin/oddfox_shang/openpay/img/cy-reward-title-bg - 副本.jpg');
?>