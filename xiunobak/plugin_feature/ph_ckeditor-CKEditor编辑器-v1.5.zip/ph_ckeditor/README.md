# xiuno_ckeditor
本插件为 [xiuno](http://bbs.xiuno.com) 的编辑器插件

本插件基于 [ckeditor5](https://ckeditor.com) 制作

# 写在前面
我貌似没有 xiuno 插件中心的账号了，所以 xiuno 的版本无法更新了，之后就只维护 git 版本了……

因为历史遗留原因，导致插件无法改名，所以，如果拉 github 版本后，目录名为 `xiuno_ckeditor` 的话，请手动修改为 `ph_ckeditor`