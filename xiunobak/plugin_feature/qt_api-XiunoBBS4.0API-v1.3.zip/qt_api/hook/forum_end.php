	if($ajax) {
		foreach($threadlist as &$thread) {
			$thread = thread_safe_info($thread);
		}
		message(0, 'ok', array(
			'page'=>$page,
			'totalpage'=>ceil($forum['threads'] / $conf['pagesize']),
			'threadlist'=>array_values($threadlist),
		));
	}
