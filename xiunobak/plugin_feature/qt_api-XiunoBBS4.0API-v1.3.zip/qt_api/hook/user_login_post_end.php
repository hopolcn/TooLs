		if($ajax) {
			message(0, lang('user_login_successfully'), array(
				'bbs_token'=> user_token_gen($uid),
				'user'=>user_safe_info($user),
			));
		}
