<?php
!defined('DEBUG') AND exit('Access Denied.');
	if($ajax) {
foreach($forumlist_show as &$f) {
$f['accesslist'] = array_values($f['accesslist']);
}
		message(0, 'ok', array('forumlist'=>array_values($forumlist_show)));
	}
