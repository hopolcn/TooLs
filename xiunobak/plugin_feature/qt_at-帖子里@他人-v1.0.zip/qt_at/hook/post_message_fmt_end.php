	preg_match_all('#@([a-zA-Z0-9_]+|\W+|[^x00-xff]+)#i', $arr['message_fmt'], $uns);
	$cnt = count($uns[1]);
	if($cnt > 0) {
		for($i = 0; $i < $cnt; $i++) {
			$u = user_read_by_username($uns[1][$i]);
			if(!$u || empty($u['uid'])) {
				continue;
			}
			$arr['message_fmt'] = str_replace($uns[1][$i], '<a href="' . url('user-' . $u['uid']) . '" target="_blank"><em>' . $u['username'] . '</em></a>', $arr['message_fmt']);
			//暂时没有短消息功能，所以无法通知
		}
	}
