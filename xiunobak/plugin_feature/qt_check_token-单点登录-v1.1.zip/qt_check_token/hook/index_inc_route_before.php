<?php exit;
	$token = param('bbs_token', '');
if(isset($user['token']) && $user['token'] != $token) {
	$uid = 0;
empty($uid) AND $uid = user_token_get() AND $_SESSION['uid'] = $uid;
$user = user_read_cache($uid);

$gid = empty($user) ? 0 : intval($user['gid']);
$group = isset($grouplist[$gid]) ? $grouplist[$gid] : $grouplist[0];

// 版块 / Forum
$fid = 0;
$forumlist = $runtime['forumlist'];
$forumlist_show = forum_list_access_filter($forumlist, $gid);	// 有权限查看的板块 / filter no permission forum
$forumarr = arrlist_key_values($forumlist_show, 'fid', 'name');
}
