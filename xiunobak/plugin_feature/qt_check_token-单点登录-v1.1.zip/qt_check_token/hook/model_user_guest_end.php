<?php exit;
	$guest['token'] = '';
