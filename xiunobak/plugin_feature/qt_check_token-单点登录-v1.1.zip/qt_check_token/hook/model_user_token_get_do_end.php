<?php exit;
	$t_user = user_read_cache($_uid);
	if($t_user['token'] != $token) return false;
