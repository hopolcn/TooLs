<?php exit;
	user__update($uid, array('token'=>$token));
