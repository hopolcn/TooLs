<?php

/*
	Xiuno BBS 4.0 插件：单点登录卸载
	admin/plugin-unstall-qt_check_token.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>