		case 'jirou':	include _include(APP_PATH.'plugin/qt_chinese_medicine/route/cm.php'); 	break;
		case 'fangji':	include _include(APP_PATH.'plugin/qt_chinese_medicine/route/cm.php'); 	break;
		case 'zhongyao':	include _include(APP_PATH.'plugin/qt_chinese_medicine/route/cm.php'); 	break;
		case 'shuxue':	include _include(APP_PATH.'plugin/qt_chinese_medicine/route/cm.php'); 	break;
		case 'shhzbl':	include _include(APP_PATH.'plugin/qt_chinese_medicine/route/cm.php'); 	break;
