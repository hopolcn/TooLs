<?php
!defined('DEBUG') AND exit('Access Denied.');
$cm = array(
'zhongyao' => '中药',
'fangji' => '方剂',
'jirou' => '肌肉',
'shuxue' => '腧穴',
'shhzbl' => '伤寒杂病论',
);
!array_key_exists($route, $cm) and exit('[]');
$tablepre = $db->tablepre;
$table = $tablepre . $route;
$action = param(1, 'search');

if($action == 'search') {
	$search_type = param(2);

	$pagesize = 1000;
	$keyword  = trim(param('keyword', xn_urldecode(param(3))));
	$page     = param('page', param(4, 1));
$columnInfos = db_sql_find("SHOW FULL COLUMNS FROM {$table};");
if(empty($columnInfos)) $columnInfos = array();
$columns = array();
foreach($columnInfos as &$v) {
$columns[] = $v['Field'];
}

$itemlist = array();
	if($keyword) {
		$header['title'] = $keyword . ' - ' . $cm[$route] . '查询';
	$header['mobile_title'] = $header['title'];

		!in_array($search_type, $columns) AND $search_type = 'all';
$sql = "SELECT * FROM {$table} WHERE ";
if($search_type == 'all') {
foreach($columns as $column) {
$sql .= $column . " LIKE '%$keyword%' OR ";
}
$sql = substr($sql, 0, -4);
} else {
$sql .= $search_type . " LIKE '%$keyword%';";
}
$sql .= " LIMIT " . $pagesize . ";";
} else {
		$header['title'] = '所有' . $cm[$route] . ' - ' . $cm[$route] . '查询';
	$header['mobile_title'] = $header['title'];
$sql = "SELECT * FROM {$table} LIMIT {$pagesize};";
}
$itemlist = db_sql_find($sql);
foreach($itemlist as &$item) {
//zy_format($zy);
}

	if($ajax || param('format') == 'json') {
echo xn_json_encode($itemlist);
exit;
}
include _include(APP_PATH."plugin/qt_chinese_medicine/view/htm/index.htm");
}
