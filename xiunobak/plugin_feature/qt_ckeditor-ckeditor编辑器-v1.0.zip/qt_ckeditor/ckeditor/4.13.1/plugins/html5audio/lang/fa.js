CKEDITOR.plugins.setLang( 'html5audio', 'fa', {
    button: 'اضافه کردن فایل صوتی',
    title: 'اضافه کردن فایل صوتی به شکل HTML5',
    infoLabel: 'اطلاعات فایل صوتی',
    urlMissing: 'آدرس منبع فایل صوتی یافت نشد.',
    audioProperties: 'ویژگی‌های فایل صوتی',
    upload: 'بارگذاری',
    btnUpload: 'ارسال به سرور',
    advanced: 'تنظیمات پیشرفته',
    autoplay: 'پخش خودکار؟',
    allowdownload: 'دانلود؟',
    advisorytitle: 'Advisory title',
    yes: 'بله',
    no: 'خیر'
} );