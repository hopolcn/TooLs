CKEDITOR.plugins.setLang( 'html5audio', 'uk', {
    button: 'Вставити HTML5 аудіо',
    title: 'HTML5 аудіо',
    infoLabel: 'Інформація',
    urlMissing: 'Не обрано джерела аудіо',
    audioProperties: 'Властивості аудіо',
    upload: 'Відвантажити',
    btnUpload: 'Відвантажити на сервер',
    advanced: 'Додатково',
    autoplay: 'Автовідтворення?',
    allowdownload: 'Дозволити завантаження?',
    advisorytitle: 'Заголовок',
    yes: 'Так',
    no: 'Ні'
} );
