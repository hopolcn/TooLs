CKEDITOR.plugins.setLang( 'html5audio', 'uz', {
    button: 'HTML5 audio qo‘shing',
    title: 'HTML5 audio',
    infoLabel: 'Audio ma\'lumot',
    urlMissing: 'Audio\'ning URL manbasi topilmadi.',
    audioProperties: 'Audio xususiyatlari',
    upload: 'Yuklash',
    btnUpload: 'Serverga jo‘natish',
    advanced: 'Kengaytrilgan',
    autoplay: 'Avtoijro?',
    allowdownload: 'Yuklab olish uchun ruxsat berilsinmi?',
    advisorytitle: 'Advisory title',
    yes: 'Ha',
    no: 'Yo‘q'
} );
