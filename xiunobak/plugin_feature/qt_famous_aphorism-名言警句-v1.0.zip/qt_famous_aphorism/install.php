<?php

/*
	Xiuno BBS 4.0 插件：名言警句插件安装
	admin/plugin-install-qt_famous_aphorism.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>