<?php

/*
	Xiuno BBS 4.0 插件：名言警句插件卸载
	admin/plugin-unstall-qt_famous_aphorism.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>