<?php exit;
$post['message_fmt'] = process_hide($post['message']);
$post['message'] = process_hide($post['message']);
