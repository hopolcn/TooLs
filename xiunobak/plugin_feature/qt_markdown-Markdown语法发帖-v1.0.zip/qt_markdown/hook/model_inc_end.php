include 	APP_PATH.'plugin/qt_markdown/model/markdown.func.php';
