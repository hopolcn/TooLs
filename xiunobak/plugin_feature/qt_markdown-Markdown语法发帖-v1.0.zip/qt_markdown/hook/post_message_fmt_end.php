	$arr['doctype'] == 2 && $arr['message_fmt'] = markdown2html($arr['message']);
