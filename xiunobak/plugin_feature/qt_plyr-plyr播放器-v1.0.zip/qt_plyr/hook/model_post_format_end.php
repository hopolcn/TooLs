<?php exit;
	if(!empty($post['message_fmt'])) {
		$post['message_fmt'] = preg_replace('#\[audio\](.*?)\[\/audio\]#is', '<audio src="\1"></audio>', $post['message_fmt']);
	}
