<?php exit;
	// 超长内容截取
	$arr['message'] = xn_substr($arr['message'], 0, 2028000);
	return true;
