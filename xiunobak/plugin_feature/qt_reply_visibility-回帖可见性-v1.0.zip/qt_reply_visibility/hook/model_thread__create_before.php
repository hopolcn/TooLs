<?php exit;
	$thread['visibility'] = $arr['visibility'];
