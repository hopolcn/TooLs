<?php exit;
		if($isfirst) {
			$visibility = param('visibility', 0);
			thread__update($tid, array('visibility'=>$visibility));
		}
