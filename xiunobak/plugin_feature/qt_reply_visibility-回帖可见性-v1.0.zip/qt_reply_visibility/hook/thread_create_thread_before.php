<?php exit;
		$visibility = param('visibility', 0);
		$thread['visibility'] = $visibility;
