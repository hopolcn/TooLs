<?php exit;
	$visibility = $thread['visibility'];
	if($visibility == 1 && ($gid < 1 || $gid > 5) && $uid != $thread['uid']) {
		foreach($postlist as $k=>&$post) {
			if($post['uid'] == $uid) {
				continue;
			}
			unset($postlist[$k]);
		}
	} else if($visibility == 2 && $uid != $thread['uid']) {
		foreach($postlist as $k=>&$post) {
			if($post['uid'] == $uid) {
				continue;
			}
			unset($postlist[$k]);
		}
	}
