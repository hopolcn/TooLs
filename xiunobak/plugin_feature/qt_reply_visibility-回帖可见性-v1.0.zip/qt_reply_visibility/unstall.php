<?php

/*
	Xiuno BBS 4.0 插件：回帖可见性卸载
	admin/plugin-unstall-qt_reply_visibility.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>