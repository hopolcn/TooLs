	if(param('rss', 0)) {
		include _include(APP_PATH.'plugin/qt_rss/view/htm/rss.htm');
		exit;
	}
