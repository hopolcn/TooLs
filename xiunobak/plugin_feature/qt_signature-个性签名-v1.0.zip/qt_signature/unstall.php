<?php

/*
	Xiuno BBS 4.0 插件实例：友情链接插件卸载
	admin/plugin-unstall-xn_signature.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>