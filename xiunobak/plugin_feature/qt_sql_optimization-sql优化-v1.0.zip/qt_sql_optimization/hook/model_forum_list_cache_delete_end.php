<?php exit;
	global $runtime;
	$runtime['forumlist'] = forum_list_cache();
	cache_set('runtime', $runtime);
