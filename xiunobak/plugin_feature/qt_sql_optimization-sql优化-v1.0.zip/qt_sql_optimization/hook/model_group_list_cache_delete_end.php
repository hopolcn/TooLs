<?php exit;
	global $runtime;
	$runtime['grouplist'] = group_list_cache();
	cache_set('runtime', $runtime);
