<?php exit;
	$mythreadlist = mythread_find(array('uid'=>$uid), array('tid'=>-1), $page, $pagesize);
	if(empty($mythreadlist)) return array();
	$tids = $threadlist = array();
	foreach ($mythreadlist as &$mythread) {
		$tids[] = $mythread['tid'];
		//$threadlist[$mythread['tid']] = thread_read($mythread['tid']);
	}
	$threadlist = thread_find(array('tid'=>$tids), array('tid'=>-1));
	return $threadlist;
