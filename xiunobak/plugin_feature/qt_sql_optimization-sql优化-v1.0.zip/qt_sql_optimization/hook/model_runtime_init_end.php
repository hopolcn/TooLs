	if(!isset($runtime['forumlist']) || !isset($runtime['grouplist'])) {
		$runtime['forumlist'] = forum_list_cache();
		$runtime['grouplist'] = group_list_cache();
		cache_set('runtime', $runtime);
	}
