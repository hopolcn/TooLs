<?php exit;
$qt_lang = param('lang', param('bbs_lang', 'zh-cn'));
if(file_exists(APP_PATH.'lang/'.$qt_lang.'/bbs.php')) {
	$conf['lang'] = $qt_lang;
	setcookie('bbs_lang', $qt_lang, $time + 8640000, $conf['cookie_path']);
	unset($qt_lang);
}
