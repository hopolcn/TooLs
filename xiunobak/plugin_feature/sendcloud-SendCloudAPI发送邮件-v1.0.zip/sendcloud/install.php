<?php

!defined('DEBUG') AND exit('Forbidden');

$sendcloud_arr = setting_get('sendcloud');
if(empty($sendcloud_arr)) {
    $sendcloud_arr = array(
        'user' => '',
        'domain' => '',
        'pass' => '',
    );
    setting_set('sendcloud', $sendcloud_arr);
}?>
