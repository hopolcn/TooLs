<?php
function xn_send_mail($smtp, $username, $email, $subject, $message, $charset = 'UTF-8'){
	global $conf;
	$sendcloud_arr = setting_get('sendcloud');
	$url = 'http://api.sendcloud.net/apiv2/mail/send';
	$API_USER = $sendcloud_arr['user'];
	$API_KEY  = $sendcloud_arr['pass'];
	$API_FROMEMAIN = $API_USER.'@'.$sendcloud_arr['domain'];
	$param = array(
		'apiUser' => $API_USER,
		'apiKey' => $API_KEY,
		'from' => $API_FROMEMAIN,
		'fromName' => $conf['sitename'],
		'to' => $email,
		'subject' => $subject,
		'html' => $message,
		'respEmailId' => 'true'
	);
	$strings = http_build_query($param);	
	$options = array(
		'http' => array(
			'method'  => 'POST',
			'header'  => 'Content-Type: application/x-www-form-urlencoded',
			'content' => $strings
		)
	);
	$json = curl_email($url, $param, $options);	
	$data = json_decode($json, true);
	if(empty($data['message']))return xn_error(-1, '发送失败');
	empty($data['result']) AND $data['result'] = 0;

	if( $data['result'] == 1 && $data['statusCode'] == 200 ){
		return TRUE;
	}else{
		return xn_error(-1, $data['message']);
	}	
}

function curl_email($url, $param, $options){
	if (empty($param)) return false;
	if (empty($options)) return false;
    if (function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        $data = curl_exec($ch);
        if (curl_errno($ch)){
            return false;
        }
        curl_close($ch);
    } else {
        $context = stream_context_create($options);
        $data = file_get_contents($url, false, $context);
    }
	return $data;
}
?>
