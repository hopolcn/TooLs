<?php

!defined('DEBUG') AND exit('Access Denied.');
$sendcloud_error1 = '请先<a href="'.url("plugin-install-sendcloud").'" class="text-danger">安装'.$plugins['sendcloud']['name'].'</a>，您已将该插件卸载。';
$sendcloud_error2 = '请先<a href="'.url("plugin-enable-sendcloud").'" class="text-danger">开启'.$plugins['sendcloud']['name'].'</a>，您已将该插件禁用。';
empty($plugins['sendcloud']['installed']) AND message(-1, $sendcloud_error1);
empty($plugins['sendcloud']['enable']) AND message(-1, $sendcloud_error2);

$action = param(1, '');

if($action == 'setting'){
    if($method == 'GET'){
        $input = array();
		$sendcloud_arr = setting_get('sendcloud');
        $input['user'] = form_text('user', !empty($sendcloud_arr['user']) ? $sendcloud_arr['user'] : '', '100%');
		$input['domain'] = form_text('domain', !empty($sendcloud_arr['domain']) ? $sendcloud_arr['domain'] : '', '100%');
        $input['pass'] = form_text('pass', !empty($sendcloud_arr['pass']) ? $sendcloud_arr['pass'] : '', '100%');
        include _include(APP_PATH."plugin/sendcloud/admin_setting.php");

    }elseif($method == 'POST'){
        $input = array();
        $input['user'] = param('user', '');
		$input['domain'] = param('domain', '');
        $input['pass'] = param('pass', '');
        setting_set('sendcloud', $input);
        message(0, lang('modify_successfully'));
    }

}else{
    message(-1, 'Access Denied.');
}?>
