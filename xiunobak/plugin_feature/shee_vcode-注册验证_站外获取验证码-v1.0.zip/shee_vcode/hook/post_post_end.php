
unset($_SESSION['vcode']);