
unset($_SESSION['vcode']);

