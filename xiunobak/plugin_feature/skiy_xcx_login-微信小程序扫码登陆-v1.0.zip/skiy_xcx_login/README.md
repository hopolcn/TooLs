微信小程序扫码登录
------
Xiuno BBS 4.x 插件 - 微信小程序扫码登录

------
### 项目地址
**插件项目地址：**   
- https://gitee.com/xiulab/skiy_xcx_login   
 
**配套小程序项目地址：**   
- https://gitee.com/xiulab/skiy_xcx_login_wx   

