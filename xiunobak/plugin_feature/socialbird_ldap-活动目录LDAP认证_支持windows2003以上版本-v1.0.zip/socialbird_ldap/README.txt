# xiunobbs 4.0+ LDAP 认证扩展

## 安装：
解压缩文件到 项目到plugin 文件夹。