<?php


/**
 * Created by PhpStorm.
 * User: bill <benma9@qq.com>
 * Date: 2019/1/20
 * Time: 2:43 AM
 */


!defined('DEBUG') AND exit('Forbidden');


$kv = kv_get('ldap_settings');
if(!$kv) {
	
	$kv = array();
	$kv['ldap_server'] = 'ldaps://127.0.0.1:636';   // ldap://127.0.0.1:389  ldaps://127.0.0.1:636 尽量用ldaps
    $kv['ldap_protocol_version'] = 3;
    $kv['ldap_follow_referrals'] = 0;  //1 ON, 0 OFF
	$kv['ldap_bind_dn'] = 'auth@socialbird.cn';  // ldap bind账户，可以是普通用户
	$kv['ldap_bind_passwd'] = 'AuthPassword';   // bind密码
	$kv['ldap_root_dn'] = 'ou=staff,dc=socialbird,dc=cn';
	$kv['ldap_uid_field'] = 'sAMAccountName'; // Use 'sAMAccountName' for Active Directory   这里可以用 mail,cn
    $kv['ldap_organization'] = '(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2))';
	
	kv_set('ldap_settings', $kv);
}

//删除缓存！
cache_truncate();
rmdir_recusive($conf['tmp_path'], 1);

?>