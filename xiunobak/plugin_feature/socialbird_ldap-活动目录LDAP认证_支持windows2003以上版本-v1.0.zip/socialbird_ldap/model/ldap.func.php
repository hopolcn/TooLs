<?php

/**
 * Created by PhpStorm.
 * User: bill <benma9@qq.com>
 * Date: 2019/1/20
 * Time: 2:43 AM
 */


/**
 *  返回配置参数
 * @param string $key
 * @return
 */


function config_get($key)
{
    global $ldap_config;
    $ldap_config=kv_get('ldap_settings');
    if($ldap_config) {
        return isset($ldap_config[$key])?$ldap_config[$key] : $value;
    }else {
        return '';
    }
}

/**
 * Return true if the parameter is an empty string or a string
 * containing only whitespace, false otherwise
 * @param string $p_var string to test
 * @return bool
 * @access public
 */
function is_blank( $p_var ) {
    $p_var = trim( $p_var );
    $str_len = strlen( $p_var );
    if( 0 == $str_len ) {
        return true;
    }
    return false;
}

/**
 * Connect and bind to the LDAP directory
 * @param string $p_binddn
 * @param string $p_password
 * @return resource or false
 */
function ldap_connect_bind( $p_binddn = '', $p_password = '' ) {
    if( !extension_loaded( 'ldap' ) ) {
        message(1,'请确认已经安装php-ldap？');
    }

    $t_ldap_server = config_get( 'ldap_server' );

    # Connect to LDAP server
    $t_ds = @ldap_connect( $t_ldap_server );

    if ( $t_ds !== false && $t_ds > 0 ) {
        $t_protocol_version = config_get( 'ldap_protocol_version' );

        if( $t_protocol_version > 0 ) {
            $t_result = @ldap_set_option( $t_ds, LDAP_OPT_PROTOCOL_VERSION, $t_protocol_version );
            if( !$t_result ) {
                echo ( $t_ds );
            }
        }

        # Set referrals flag.
        $t_follow_referrals = 0 == config_get( 'ldap_follow_referrals' );
        $t_result = @ldap_set_option( $t_ds, LDAP_OPT_REFERRALS, $t_follow_referrals );
        if( !$t_result ) {
            echo( $t_ds );
        }

        # If no Bind DN and Password is set, attempt to login as the configured
        #  Bind DN.
        if( is_blank( $p_binddn ) && is_blank( $p_password ) ) {
            $p_binddn = config_get( 'ldap_bind_dn', '' );
            $p_password = config_get( 'ldap_bind_passwd', '' );
        }



        if( !is_blank( $p_binddn ) && !is_blank( $p_password ) ) {
            $t_br = @ldap_bind( $t_ds, $p_binddn, $p_password );
        } else {
            # Either the Bind DN or the Password are empty, so attempt an anonymous bind.
            $t_br = @ldap_bind( $t_ds );
        }


    }

    return $t_ds;
}

/**
 * Escapes the LDAP string to disallow injection.
 *
 * @param string $p_string The string to escape.
 * @return string The escaped string.
 */
function ldap_escape_string( $p_string ) {
    $t_find = array( '\\', '*', '(', ')', '/', "\x00" );
    $t_replace = array( '\5c', '\2a', '\28', '\29', '\2f', '\00' );

    $t_string = str_replace( $t_find, $t_replace, $p_string );

    return $t_string;
}

/**
 * Gets the value of a specific field from LDAP given the user name
 * and LDAP field name.
 *
 * @todo Implement caching by retrieving all needed information in one query.
 * @todo Implement logging to LDAP queries same way like DB queries.
 *
 * @param string $p_username The user name.
 * @param string $p_field The LDAP field name.
 * @return string The field value or null if not found.
 */
function ldap_get_field_from_username( $p_username, $p_field ) {

    $t_ldap_organization    = config_get( 'ldap_organization' );
    $t_ldap_root_dn         = config_get( 'ldap_root_dn' );
    $t_ldap_uid_field		= config_get( 'ldap_uid_field' );

    $c_username = ldap_escape_string( $p_username );


    # Bind
    $t_ds = @ldap_connect_bind();
    if ( $t_ds === false ) {
        return null;
    }

    # Search
    $t_search_filter        = "(&$t_ldap_organization($t_ldap_uid_field=$c_username))";
    $t_search_attrs         = array( $t_ldap_uid_field, $p_field, 'dn' );

    $t_sr = @ldap_search( $t_ds, $t_ldap_root_dn, $t_search_filter, $t_search_attrs );
    if ( $t_sr === false ) {
        ldap_unbind( $t_ds );
        return null;
    }

    # Get results
    $t_info = ldap_get_entries( $t_ds, $t_sr );
    if ( $t_info === false ) {
        return null;
    }

    # Free results / unbind
    ldap_free_result( $t_sr );
    ldap_unbind( $t_ds );

    # If no matches, return null.
    if ( count( $t_info ) == 0 ) {
        return null;
    }

    # Make sure the requested field exists
    if( is_array($t_info[0]) && array_key_exists( $p_field, $t_info[0] ) ) {
        $t_value = $t_info[0][$p_field][0];
    } else {
        return null;
    }

    return $t_value;
}


/**
 * Authenticates an user via LDAP given the username and password.
 *
 * @param string $p_username The user name.
 * @param string $p_password The password.
 * @return true: authenticated, false: failed to authenticate.
 */
function ldap_authenticate_by_username( $p_username, $p_password ) {

        $c_username = ldap_escape_string( $p_username );

        $t_ldap_organization = config_get( 'ldap_organization' );
        $t_ldap_root_dn = config_get( 'ldap_root_dn' );

        $t_ldap_uid_field = config_get( 'ldap_uid_field', 'uid' );
        $t_search_filter = "(&$t_ldap_organization($t_ldap_uid_field=$c_username))";
        $t_search_attrs = array(
            $t_ldap_uid_field,
            'dn',
        );

        # Bind
        try {
            $t_ds = ldap_connect_bind();
        } catch  (Exception $e) {
            message(1,'活动目录设置参数可能不对，请检查？');
        }


        # Search for the user id
        $t_sr = ldap_search( $t_ds, $t_ldap_root_dn, $t_search_filter, $t_search_attrs );
        if ( $t_sr === false ) {
            ldap_unbind( $t_ds );
        }

        $t_info = @ldap_get_entries( $t_ds, $t_sr );
        if ( $t_info === false ) {
            ldap_free_result( $t_sr );
            ldap_unbind( $t_ds );
        }

        $t_authenticated = false;

        if ( $t_info['count'] > 0 ) {
            # Try to authenticate to each until we get a match
            for ( $i = 0; $i < $t_info['count']; $i++ ) {
                $t_dn = $t_info[$i]['dn'];
                # Attempt to bind with the DN and password
                if ( @ldap_bind( $t_ds, $t_dn, $p_password ) ) {

                    $t_authenticated = true;
                    break;
                }
            }
        }

        ldap_free_result( $t_sr );
        ldap_unbind( $t_ds );


    return $t_authenticated;
}



