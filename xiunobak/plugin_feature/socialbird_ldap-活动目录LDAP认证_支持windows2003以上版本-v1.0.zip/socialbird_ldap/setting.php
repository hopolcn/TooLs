<?php


/**
 * Created by PhpStorm.
 * User: bill <benma9@qq.com>
 * Date: 2019/1/20
 * Time: 2:43 AM
 */


!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	
	$kv = kv_get('ldap_settings');
	
	$input = array();
	$input['ldap_server'] = form_text('ldap_server', $kv['ldap_server']);
	$input['ldap_bind_dn'] = form_text('ldap_bind_dn', $kv['ldap_bind_dn']);
	$input['ldap_bind_passwd'] = form_password('ldap_bind_passwd', $kv['ldap_bind_passwd']);
	$input['ldap_root_dn'] = form_text('ldap_root_dn', $kv['ldap_root_dn']);
	$input['ldap_uid_field'] =form_text('ldap_uid_field', $kv['ldap_uid_field']);

	include _include(APP_PATH.'plugin/socialbird_ldap/setting.htm');
	
} else {

	$ldap_server = param('ldap_server');
	$ldap_bind_dn = param('ldap_bind_dn');
	$ldap_bind_passwd = param('ldap_bind_passwd');
	$ldap_root_dn = param('ldap_root_dn');
	$ldap_uid_field = param('ldap_uid_field');
	
	$kv = array();
    $kv['ldap_server'] = $ldap_server;
    $kv['ldap_protocol_version'] = 3;
    $kv['ldap_follow_referrals'] = 0;
    $kv['ldap_bind_dn'] = $ldap_bind_dn;
    $kv['ldap_bind_passwd'] = $ldap_bind_passwd;
    $kv['ldap_root_dn'] = $ldap_root_dn;
    $kv['ldap_uid_field'] = $ldap_uid_field;
    $kv['ldap_organization'] = '(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2))';

    kv_set('ldap_settings', $kv);

    //删除缓存！
    cache_truncate();
    rmdir_recusive($conf['tmp_path'], 1);
	message(0, '修改成功,<a href="'.param('url').'"> 返回插件</a>');
}
	
?>