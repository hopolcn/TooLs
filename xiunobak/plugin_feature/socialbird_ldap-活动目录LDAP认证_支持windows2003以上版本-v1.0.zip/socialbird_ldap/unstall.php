<?php

!defined('DEBUG') AND exit('Forbidden');

kv_delete('ldap_settings');

//删除缓存！
cache_truncate();
rmdir_recusive($conf['tmp_path'], 1);

?>