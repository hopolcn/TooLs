<?php
!defined('DEBUG') AND exit('Forbidden');
//初始化一些数据
$tianapi_apikey = '2ece2aa927a6fa5375cc404f663f14c7';   //插件默认的apikey，请在天行数据官网获得
kv_set('apikey', $tianapi_apikey);

?>