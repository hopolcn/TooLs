<?php
!defined('DEBUG') and exit('Forbidden');

/*=============================================
=                   定义变量                   =
=============================================*/

$settings = setting_get('till_base16_setting');

$BASE16_ALL_COLOR_SCHEMES = [
    // hook base16_extra_colors.php
];

$BASE16_ALL_COLOR_SCHEMES += include_once(APP_PATH . 'plugin/till_base16_colorscheme/view/css/base16/_get_all.php');

/*============  End of 定义变量  =============*/

/*=============================================
=                   实用函数                   =
=============================================*/

/**
 * Base16 颜色选择器
 * @param string $id 输入框的name
 * @param int|string $current 当前选择项
 * @return string
 */
function form_b16_color_selector($id = '', $current = '0') {
    $r = '<div class="b16-color-selector">';
    $current = str_replace('base0','',$current);
    $current_int = intval(base_convert(strval($current), 16, 10));
    for ($i = 0; $i <= 15; $i++) {
        $this_base = 'base0' . strtoupper(base_convert(strval($i), 10, 16));
        $this_checked = $current_int === $i ? ' checked ' : '';
        $r .= '<input type="radio" name="' . $id . '" value="' . $this_base . '" class="b16-color-selector-input" id="' . $id . '-' . $this_base . '" ' . $this_checked . '><label for="' . $id . '-' . $this_base . '" class="b16-color-selector-button fg-' . $this_base . '">' . strtoupper(base_convert(strval($i), 10, 16)) . '</label>';
    }
    $r .= '</div>';
    return $r;
}

/**
 * Base16 配色方案选择器
 * @param string $id 输入框的name
 * @param int|string $current 当前选择项
 * @return string
 */
function form_b16_color_scheme_selector($id = '', $current = 'default-dark') {
    global $BASE16_ALL_COLOR_SCHEMES;
    $r = '<div class="b16-color-scheme-selector">';
    foreach ($BASE16_ALL_COLOR_SCHEMES as $key => $value) {


        $new_key = str_replace(['base16-', '.css'], ['', ''], $key);
        $this_checked = $current === $new_key ? ' checked ' : '';
        $this_label_add = '';

        $r .= '<input type="radio" name="' . $id . '" value="' . $new_key . '" class="b16-color-scheme-input" id="' . $id . '--' . $new_key . '" ' . $this_checked . '>
        <label for="' . $id . '--' . $new_key . '" class="b16-color-scheme-button">
        <img src="../' . $value['image'] . '" alt="' . $value['label'] . '">
        ' . $this_label_add . ' ' . $value['label'] . '
        </label>';
    }
    $r .= '</div>';

    return $r;
}

/*============  End of 实用函数  =============*/

/*=============================================
=                   业务代码                   =
=============================================*/

if ($method === "GET") {
    include_once(APP_PATH . 'plugin/till_base16_colorscheme/setting.htm');
} else {
    $settings['b16_color_mode'] = param('b16_color_mode', '');
    $settings['b16_show_color_mode_switch'] = param('b16_show_color_mode_switch', false);
    $settings['b16_switch_to_dark_time'] = param('b16_switch_to_dark_time', '');
    $settings['b16_switch_to_light_time'] = param('b16_switch_to_light_time', '');
    $settings['b16_affect_acp'] = param('b16_affect_acp', false);
    $settings['b16_inject_location'] = param('b16_inject_location', '');
    $settings['b16_custom_css'] = param('b16_custom_css', '', false);
    foreach ($_POST['light_mode'] as $key => $value) {
        $settings['light_mode'][$key] = $value;
    }
    foreach ($_POST['dark_mode'] as $key => $value) {
        $settings['dark_mode'][$key] = $value;
    }
    $settings['light_mode']['b16_color_scheme_href'] = $BASE16_ALL_COLOR_SCHEMES['base16-' . $settings['light_mode']['b16_color_scheme'] . '.css']['href'];
    $settings['dark_mode']['b16_color_scheme_href'] = $BASE16_ALL_COLOR_SCHEMES['base16-' . $settings['dark_mode']['b16_color_scheme'] . '.css']['href'];

    setting_set('till_base16_setting', $settings);
    message(0, '保存成功');

}
/*============  End of 业务代码  =============*/
