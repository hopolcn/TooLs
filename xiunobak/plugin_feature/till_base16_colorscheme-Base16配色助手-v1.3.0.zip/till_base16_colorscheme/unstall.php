<?php

!defined('DEBUG') AND exit('Forbidden');

setting_delete('till_base16_setting');