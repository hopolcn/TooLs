<?php
function hex2rgb($hexColor) {
    $color = str_replace('#', '', $hexColor);
    if (strlen($color) > 3) {
        $rgb = array('r' => hexdec(substr($color, 0, 2)), 'g' => hexdec(substr($color, 2, 2)), 'b' => hexdec(substr($color, 4, 2)));
    } else {
        $r = substr($color, 0, 1);
        $g = substr($color, 1, 1);
        $b = substr($color, 2, 1);
        $rgb = array('r' => hexdec($r), 'g' => hexdec($g), 'b' => hexdec($b));
    }
    return $rgb;
}

function hex2rgb_gd($hexColor, $image) {
    /*
    $rgb = hex2rgb($hexColor);
    return imagecolorallocate($image, $rgb['r'], $rgb['g'], $rgb['b']);
    */
    return $hexColor;
}

function isHexColorLight($hexColor) {
    $rgb = hex2rgb($hexColor);
    return isColorLight($rgb['r'], $rgb['g'], $rgb['b']);
}

function isColorLight($r, $g, $b) {

    $brightness = ((int)($r * 299) + (int)($g * 587) + (int)($b * 114)) / 1000;

    return $brightness > 155;
}

$files_ignore = ['.', '..', '_font.ttf', '_font_italic.ttf', '_generate_images.php', '_get_all.php', 'demo.html', '_preview', basename(__FILE__)];

$files = scandir(__DIR__);

// 定义字体
$font = realpath('_font.ttf');
$font_italic = realpath('_font_italic.ttf');

$color_black = '#333333';
$color_white = '#f0f0f0';

$final = array();

if (isset($_POST['confirm_generate_images']) && $_POST['confirm_generate_images'] === 'yes') {
    $r = '';
    $r .= '<meta name="viewport"content="width=device-width, initial-scale=1.0">';
    $r .= '<link href="https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/pure/2.0.6/pure.min.css" type="text/css" rel="stylesheet" />';
    $r .= '<link href="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/pure/2.0.6/grids-responsive.min.css" type="text/css" rel="stylesheet" />';
    $r .= '<style>
body {background:#000;color:#888}
main{max-width: 1440px; padding: 1em .5em;margin:0 auto}
::selection {background-color: #000088;color: #fff; }
.pure-u-1 {margin-bottom:1rem;}
.lang-demo {font-size:0.8em;font-style:italic}
pre.prettyprinted,pre {background-color: var(--base00);padding: .5em;border-radius: .5em;white-space: pre-wrap;word-break: break-all;margin:0;font-family: "Iosevka", "等距更纱黑体 SC", sans-serif, monospace, system-ui;}
pre ::selection {background-color: var(--base02);color: var(--base06);}
pre.prettyprinted,pre,pre .pln{color:var(--base05)}
pre .str{color:var(--base0B)}
pre .kwd{color:var(--base0E)}
pre .com{font-style:italic;color:var(--base03)}
pre .typ{color:var(--base0A)}
pre .dec{color:var(--base0C)}
pre .lit,pre a{color:var(--base09)}
pre .pun{color:var(--base04)}
pre .opn,pre .clo{color:var(--base0F)}
pre .var{color:var(--base08)}
pre .tag{color:var(--base08)}
pre .atn{color:var(--base0D)}
pre .atv{color:var(--base09)}
pre i,pre em{color:var(--base0E)}
pre b,pre strong{color:var(--base0A)}
pre q,pre blockquote{color:var(--base0C)}
pre ins{color:var(--base0B)}
pre del{color:var(--base08)}
pre mark{background-color:var(--base0E);color:var(--base00)}
</style>';
    $r .= '<main class="container"><div class="pure-g">';


    foreach ($files as $file) {

        $image = null;

        if (in_array($file, $files_ignore, true)) {
            continue;
        }

        $css = file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . $file);

        $css_array = array();
        preg_match_all('/(--[a-zA-Z0-9]+):\s?([#a-zA-Z0-9]+);/', $css, $matches);

        for ($i = 0; $i < count($matches[1]); $i++) {
            $css_array[] = $matches[2][$i];
        }


        // 定义颜色
        foreach ($css_array as $key => $value) {
            $color_name = "color_base" . str_pad(strtoupper(base_convert($key, 10, 16)), 2, "0", STR_PAD_LEFT);
            $$color_name = hex2rgb_gd($value, $image);
        }

        $r .= '<div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-3 pure-u-xl-1-4" style="' .
            "--base00:" . $color_base00 . ";" .
            "--base01:" . $color_base01 . ";" .
            "--base02:" . $color_base02 . ";" .
            "--base03:" . $color_base03 . ";" .
            "--base04:" . $color_base04 . ";" .
            "--base05:" . $color_base05 . ";" .
            "--base06:" . $color_base06 . ";" .
            "--base07:" . $color_base07 . ";" .
            "--base08:" . $color_base08 . ";" .
            "--base09:" . $color_base09 . ";" .
            "--base0A:" . $color_base0A . ";" .
            "--base0B:" . $color_base0B . ";" .
            "--base0C:" . $color_base0C . ";" .
            "--base0D:" . $color_base0D . ";" .
            "--base0E:" . $color_base0E . ";" .
            "--base0F:" . $color_base0F . ";" .
            '">
<pre class="lang-demo"><span class="kwd"></span> ' . ltrim(ucwords(str_replace(['base16-', '.css', '-'], ' ', $file))) . '
<span class="pln">Pln</span> <span class="str">Str</span> <span class="kwd">Kwd</span> <span class="com">Com</span> <span class="typ">Typ</span> <span class="dec">Dec</span> <span class="lit">Lit</span> 
<span class="pun">Pun</span> <span class="opn">Opn</span> <span class="clo">Clo</span> <span class="var">Var</span> <span class="tag">Tag</span> <span class="atn">Atn</span> <span class="atv">Atv</span>
</pre>
<pre class="prettyprint lang-php">
&lt;?php class DemoClass {
  /* Demo Class */
  private $Integer = 123;
  private $Boolean = true;
  private $String = "Hello world";
  public $Array = [1, 2, 3];
  public function __construct(array $vars) {
    echo($this->String);
    $this->$Array = $vars;
  }
  public function quickSort($array) {
    $k = $array[0]; 
    $x = $y = array();
    for ($i = 1; $i &lt; $length; $i++) {
      if ($array[$i] &lt;= $k) {
        $x[] = $array[$i];
      } else {
        $y[] = $array[$i];
      }
    } return array_merge(quickSort($x), [$k], quickSort($y));
  }
} // Demo Usage
var_dump($_GET);
$demoClass = new DemoClass($_GET);
print_r($demoClass-&gt;quickSort($demoClass->Array)); ?&gt;
</pre></div>';
    }
    $r .= '</div></main>';
    $r .= '<script src="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-M/prettify/188.0.0/prettify.min.js" type="application/javascript"></script>';
    $r .= <<<EOT
<script>PR['registerLangHandler'](
        PR['createSimpleLexer'](
            [// shortcutStylePatterns
                // Whitespace
                [PR['PR_PLAIN'], /^[ \\t\\n\\r]+/, null, ' \\t\\n\\r'],
                // A double or single quoted, possibly multi-line, string.
                [PR['PR_STRING'], /^(?:\"(?:[^\"\\\\\\n\\r]|\\\.)*(?:\"|$)|\'(?:[^\'\\\\\\n\\r]|\\\.)*(?:\'|$))/, null, '"\''],
                // A heredoc string.
                [PR['PR_STRING'], /^(?:<<<\w+)(?:[\w\d_]+\\r?\\n|[\w\d_]+\\r\\n)((?:.|\\r?\\n)*?)(?:\\r?\\n\\1)/, null, '"""'],
                // A comment is either a line comment that starts with two dashes, or two dashes or a hash symbol preceding a long bracketed block.
                [PR['PR_COMMENT'], /^(?:\/\/.*|\/\*[\s\S]*?\*\/|\#.*$)/, null, '/*#'],
                // A long bracketed block not preceded by -- is a string.
                [PR['PR_STRING'], /^\[(=*)\[[\s\S]*?(?:\]\\1\]|$)/],
                // A number is a hex integer literal, a decimal real literal, or in scientific notation.
    
                [PR['PR_LITERAL'], /^[+-]?(?:0x[\da-f]+|(?:(?:\.\d+|\d+(?:\.\d*)?)(?:e[+\-]?\d+)?))/i, null, '0123456789'],
    
            ],
            [// fallthroughStylePatterns
    
                // HTML doctype
                [PR['PR_DECLARATION'], /^<!\w[^>]*(?:>|$)/, null],
                // HTML Comment
                [PR['PR_COMMENT'], /^<\!--[\s\S]*?(?:-\->|$)/, null],
                // HTML Tag
                ['lang-in.tag', /^(<\/?[a-z][^<>]*>)/i],
                // JavaScript
                ['lang-js', /^<script\b[^>]*>([\s\S]*?)(<\/script\b[^>]*>)/i],
                // CSS
                ['lang-css', /^<style\b[^>]*>([\s\S]*?)(<\/style\b[^>]*>)/i],
                // PHP-specific Beginning
                ['opn', /^\<\?php/, null],
                // PHP-specific Beginning
                ['opn', /^\<\?=/, null],
                // PHP-specific End
                ['clo', /^\?>/, null],

                [PR['PR_DECLARATION'], /\\$(this|GLOBALS|_SERVER|_GET|_POST|_FILES|_COOKIE|_SESSION|_REQUEST|_ENV)/i, null],
                ['var', /^(?:\\$[A-Za-z0-9_]\w*)/i, null],
    
                // PHP Keywords
                [PR['PR_KEYWORD'], /^(?:and|break|case|catch|class|clone|const|continue|declare|default|do|else|elseif|enddeclare|endfor|endforeach|endif|endswitch|endwhile|extends|final|for|foreach|function|global|goto|if|implements|interface|instanceof|namespace|new|or|private|protected|public|static|switch|throw|try|use|var|while|xor|__halt_compiler|abstract|as|echo|empty|exit|include|include_once|isset|list|parent|print|require|require_once|return|self|unset)\b/, null],
    
                // PHP Types
                [PR['PR_TYPE'], /^(?:array|bool|boolean|callable|cfunction|const|double|float|int|integer|null|object|resource|string|boolval|doubleval|floatval|intval|strval)\b/, null],

                // Some Most Commonly Used PHP Functions
                [PR['PR_ATTRIB_NAME'], /^(?:echo|print|printf|sprintf|var_dump|print_r|isset|empty|count|in_array|array_key_exists|array_search|array_merge|array_intersect|array_diff|array_slice|array_splice|array_push|array_pop|array_shift|array_unshift|sort|rsort|asort|arsort|ksort|krsort|shuffle|rand|srand|mt_rand|mt_srand|time|date|mktime|strftime|gmdate|gmmktime|gmstrftime|fopen|fclose|fread|fwrite|fgets|fputs|fputcsv|fgetcsv|file_get_contents|file_put_contents|copy|rename|unlink|mkdir|rmdir|chdir|getcwd|exec|system|passthru|shell_exec|escapeshellcmd|escapeshellarg|md5|sha1|crypt|base64_encode|base64_decode|gzcompress|gzuncompress|serialize|unserialize|json_encode|json_decode|session_start|session_destroy|setcookie|getcookie|header|mail|mysqli_connect|mysqli_query|mysqli_fetch_array|mysqli_fetch_object|mysqli_close|preg_match|preg_replace|str_replace|substr|strlen|strpos|strrpos|strtolower|strtoupper|trim|ltrim|rtrim|implode|explode|is_​array|is_​bool|is_​callable|is_​countable|is_​double|is_​float|is_​int|is_​integer|is_​iterable|is_​long|is_​null|is_​numeric|is_​object|is_​real|is_​resource|is_​scalar|is_​string)\b/, null],

                // PHP-specific constants
                [PR['PR_LITERAL'], /^(?:true|false|null)\b/, null],
    
                // PHP-specific built-in constants
                [PR['PR_BUILTIN'], /^(?:__CLASS__|__FILE__|__FUNCTION__|__LINE__|__METHOD__|__NAMESPACE__|__DIR__|__TRAIT__|PHP_VERSION|PHP_MAJOR_VERSION|PHP_MINOR_VERSION|PHP_RELEASE_VERSION|PHP_VERSION_ID|PHP_EXTRA_VERSION|ZEND_THREAD_SAFE|ZEND_DEBUG_BUILD|PHP_ZTS|PHP_DEBUG|PHP_MAXPATHLEN|PHP_OS|PHP_OS_FAMILY|PHP_SAPI|PHP_EOL|PHP_INT_MAX|PHP_INT_MIN|PHP_INT_SIZE|PHP_FLOAT_DIG|PHP_FLOAT_EPSILON|PHP_FLOAT_MIN|PHP_FLOAT_MAX|DEFAULT_INCLUDE_PATH|PEAR_INSTALL_DIR|PEAR_EXTENSION_DIR|PHP_EXTENSION_DIR|PHP_PREFIX|PHP_BINDIR|PHP_BINARY|PHP_MANDIR|PHP_LIBDIR|PHP_DATADIR|PHP_SYSCONFDIR|PHP_LOCALSTATEDIR|PHP_CONFIG_FILE_PATH|PHP_CONFIG_FILE_SCAN_DIR|PHP_SHLIB_SUFFIX|PHP_FD_SETSIZE|E_ERROR|E_WARNING|E_PARSE|E_NOTICE|E_CORE_ERROR|E_CORE_WARNING|E_COMPILE_ERROR|E_COMPILE_WARNING|E_USER_ERROR|E_USER_WARNING|E_USER_NOTICE|E_RECOVERABLE_ERROR|E_DEPRECATED|E_USER_DEPRECATED|E_ALL|E_STRICT|__COMPILER_HALT_OFFSET__)\b/, null],
    
                // PHP-specific built-in magic function
                [PR['PR_DECLARATION'], /(?:__construct|__destruct|__set|__get|__isset|__unset|__clone|__tostring|__call|__autoload|__sleep|__wakeup)\b/, null],
    
                // An identifier
                [PR['PR_PLAIN'], /^[a-z_$][a-z_$@0-9]*/i, null],
                // A run of punctuation
                [PR['PR_PUNCTUATION'],  /^.[^\s\w.$@'"`/\\\\]*(?!s*\/)/, null],

            ]
        ),
        ['php']
    );</script>
EOT;
    
    
    $r .= '<script>prettyPrint();</script>';
    
    file_put_contents('demo.html', $r);
    unset($r);
    gc_collect_cycles();
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') : ?>
    <form action="_generate_demohtml.php" method="post">
        <label for="confirm_generate_images">确认重新生成预览图?</label>
        <input type="text" name="confirm_generate_images" id="confirm_generate_images" placeholder="输入yes">
        <button type="submit">好</button>
    </form>
<?php endif; ?>