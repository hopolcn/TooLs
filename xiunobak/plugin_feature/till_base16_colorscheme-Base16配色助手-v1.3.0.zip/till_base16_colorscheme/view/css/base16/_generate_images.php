<?php
function hex2rgb($hexColor) {
    $color = str_replace('#', '', $hexColor);
    if (strlen($color) > 3) {
        $rgb = array('r' => hexdec(substr($color, 0, 2)), 'g' => hexdec(substr($color, 2, 2)), 'b' => hexdec(substr($color, 4, 2)));
    } else {
        $r = substr($color, 0, 1);
        $g = substr($color, 1, 1);
        $b = substr($color, 2, 1);
        $rgb = array('r' => hexdec($r), 'g' => hexdec($g), 'b' => hexdec($b));
    }
    return $rgb;
}

function hex2rgb_gd($hexColor, $image) {
    $rgb = hex2rgb($hexColor);
    return imagecolorallocate($image, $rgb['r'], $rgb['g'], $rgb['b']);
}

function isHexColorLight($hexColor) {
    $rgb = hex2rgb($hexColor);
    return isColorLight($rgb['r'], $rgb['g'], $rgb['b']);
}

function isColorLight($r, $g, $b) {

    $brightness = ((int)($r * 299) + (int)($g * 587) + (int)($b * 114)) / 1000;

    return $brightness > 155;
}

$files_ignore = ['.', '..', '_font.ttf', '_font_italic.ttf', '_get_all.php', '_preview', '_generate_demohtml.php', 'demo.html', basename(__FILE__)];

$files = scandir(__DIR__);

// 定义字体
$font = realpath('_font.ttf');
$font_italic = realpath('_font_italic.ttf');

$color_black = '#333333';
$color_white = '#f0f0f0';

$final = array();

if (isset($_POST['confirm_generate_images']) && $_POST['confirm_generate_images'] === 'yes') {
   
    foreach ($files as $file) {

        if (in_array($file, $files_ignore, true)) {
            continue;
        }

        $css = file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . $file);

        $css_array = array();
        preg_match_all('/(--[a-zA-Z0-9]+):\s?([#a-zA-Z0-9]+);/', $css, $matches);

        for ($i = 0; $i < count($matches[1]); $i++) {
            $css_array[] = $matches[2][$i];
        }

        // 创建画布  
        $image = imagecreatetruecolor(320, 240);

        // 定义颜色
        foreach ($css_array as $key => $value) {
            $color_name = "color_base" . str_pad(strtoupper(base_convert($key, 10, 16)), 2, "0", STR_PAD_LEFT);
            $$color_name = hex2rgb_gd($value, $image);
        }
        /**
         * $color_base00 = hex2rgb_gd($css_array[0], $image);   //默认背景色
         * $color_base01 = hex2rgb_gd($css_array[1], $image);   //较亮的背景色（用于状态栏、行号和折叠标记）
         * $color_base02 = hex2rgb_gd($css_array[2], $image);   //选区背景色
         * $color_base03 = hex2rgb_gd($css_array[3], $image);   //注释、不可见字符、行高亮
         * $color_base04 = hex2rgb_gd($css_array[4], $image);   //暗前景色（用于状态栏）
         * $color_base05 = hex2rgb_gd($css_array[5], $image);   //默认前景色、光标、分隔符、操作符
         * $color_base06 = hex2rgb_gd($css_array[6], $image);   //亮前景色（不常用）
         * $color_base07 = hex2rgb_gd($css_array[7], $image);   //亮背景色（不常用）
         * $color_base08 = hex2rgb_gd($css_array[8], $image);   //变量、XML标签、标记链接文本、标记列表、已删除的差异
         * $color_base09 = hex2rgb_gd($css_array[9], $image);   //整数、布尔值、常量、XML属性、标记链接URL
         * $color_base0A = hex2rgb_gd($css_array[10], $image);  //类、标记粗体、搜索文本背景
         * $color_base0B = hex2rgb_gd($css_array[11], $image);  //字符串、继承的类、标记代码、已插入的差异
         * $color_base0C = hex2rgb_gd($css_array[12], $image);  //支持、正则表达式、转义字符、标记引号
         * $color_base0D = hex2rgb_gd($css_array[13], $image);  //函数、方法、属性ID、标题
         * $color_base0E = hex2rgb_gd($css_array[14], $image);  //关键字、存储、选择器、标记斜体、已更改的差异
         * $color_base0F = hex2rgb_gd($css_array[15], $image);  //已弃用、打开/关闭嵌入式语言标签，例如php
        */
        /**
         * 常见组合：
         * 背景：base00，前景：base05 //标准
         * 背景：base00，前景：base04 //透明状态栏
         * 背景：base01，前景：base04 //弱化字状态栏
         * 背景：base01，前景：base05 //标准字状态栏
         * 背景：base01，前景：base06 //着重字状态栏
         * 背景：base02，前景：base05 //选择文字
         * 背景：base07，前景：base05 //反色状态栏
         */

        $text_fontsize = 15;
        $heading_fontsize = 24;

        // 绘制矩形和文字  
        $backgroundColor = $color_base00;

        // 第一个矩形，背景
        imagefill($image, 0, 0, $backgroundColor);

        // 第二个矩形  
        imagefilledrectangle($image, 0, 0, 319, 47, $color_base01);



        // Navbar文字  
        $text = 'Base16 Demo';
        imagettftext($image, $text_fontsize, 0, 32, 16 + $text_fontsize, $color_base05, $font, $text);

        // Heading文字  
        $text = 'Hello,';
        imagettftext($image, $heading_fontsize, 0, 32, 64 + $heading_fontsize, $color_base06, $font_italic, $text);

        $text = 'World!';
        imagettftext($image, $heading_fontsize, 0, 130, 64 + $heading_fontsize, $color_base04, $font_italic, $text);

        // Paragraph文字  
        $text = ltrim(ucwords(str_replace(['base16-', '.css', '-'], ' ', $file)));
        imagettftext($image, $text_fontsize, 0, 32, 100 + $text_fontsize, $color_base05, $font, $text);

        // Selected背景文字  
        $text = '████████';
        imagettftext($image, 12, 0, 32, 180 + 12, $color_base02, $font, $text);

        // Marked背景文字  
        $text = '█████';
        imagettftext($image, 12, 0, 96, 180 + 12, $color_base0A, $font, $text);


        // Selected文字  
        $text = ' Select';
        imagettftext($image, 12, 0, 32, 180 + 12, $color_base05, $font, $text);

        // Marked文字  
        $text = '  Mark';
        imagettftext($image, 12, 0, 96, 180 + 12, $color_base00, $font, $text);



        // 下面的矩形和文字部分可以根据您的需要进行调整，这里仅作示例。  
        // 矩形部分  

        $x_start = 32;
        $width = 40;
        $padding = 4;
        $x_end = $x_start + $width;
        foreach ([
            $color_base0D,
            $color_base04,
            $color_base0C,
            $color_base0B,
            $color_base0A,
            $color_base08
        ] as $this_color) {

            imagefilledrectangle($image, $x_start, 125, $x_end, 165, $this_color);

            $x_start = $x_end + $padding;
            $x_end = $x_start + $width;
        }

        unset(
            $x_start,
            $width,
            $padding,
            $x_end
        );

        //文字部分  

        $text_fontsize = 10;

        $x_start = 38;
        $width = 36;
        $padding = 8;
        $x_end = $x_start + $width;
        foreach ([
            '13' => 'Prim',
            '4' => 'Seco',
            '12' => 'Info',
            '11' => 'Succ',
            '10' => 'Warn',
            '8' => 'Dger'
        ] as $color_key => $text) {
            $isThisColorLight = isHexColorLight($css_array[intval($color_key)]);
            if ($isThisColorLight) {
                //$textColor = $color_base03;
                $textColor = hex2rgb_gd($color_black, $image);
            } else {
                //$textColor = $color_base05;
                $textColor = hex2rgb_gd($color_white, $image);
            }

            imagettftext($image, $text_fontsize, 0, $x_start, 140 + $text_fontsize, $textColor, $font, $text);
            $x_start = $x_end + $padding;
            $x_end = $x_start + $width;
        }
        unset(
            $x_start,
            $width,
            $padding,
            $x_end
        );

        $i = 1;
        foreach ($css_array as $key => $color) {
            imagettftext($image, 10, 0, 20 * max(0, $i - 1) + 7, 216, $color_base03, $font, strtoupper(base_convert(strval($key), 10, 16)));

            $this_color = hex2rgb_gd($color, $image);
            imagefilledrectangle($image, 20 * max(0, $i - 1), 220, 20 * $i, 240, $this_color);
            $i++;
        }
        unset($i);

        imagepng($image, ('./_preview/' . str_replace(['.css'], '', $file) . '.png'));
        imagedestroy($image);

        $final[$file] = array(
            'label' => trim(ucwords(str_replace(['base16-', '.css', '-'], ' ', $file))),
            //'colors' => $css_array,
        );
    }

    //var_export($final);echo ',';
}
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') : ?>
 <form action="_generate_images.php" method="post">
    <label for="confirm_generate_images">确认重新生成预览图?</label>
    <input type="text" name="confirm_generate_images" id="confirm_generate_images" placeholder="输入yes">
    <button type="submit">好</button>
</form>
<?php endif; ?>