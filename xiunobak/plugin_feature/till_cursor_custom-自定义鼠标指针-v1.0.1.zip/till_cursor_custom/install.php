<?php

!defined('DEBUG') and exit('Forbidden');

$setting = setting_get('till_cursor_custom_setting');
if (empty($setting)) {
	$setting = array('cursor_set' => 1);
	setting_set('till_cursor_custom_setting', $setting);
}
