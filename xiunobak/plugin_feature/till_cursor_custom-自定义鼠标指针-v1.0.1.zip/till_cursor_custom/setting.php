<?php

!defined('DEBUG') and exit('Access Denied.');

$setting = setting_get('till_cursor_custom_setting');
/**
 * @var array $till_cursor_sets 鼠标指针集合
 * 
 * 键为ID，值为显示名。如果键为1，则会匹配这些文件：
 * - 1_arrow.cur
 * - 1_hand.cur
 * - 1_ibeam.cur
 * - 1_sizeall.cur
 * 以此类推。
 */

$till_cursor_sets = [
	/* 原始 */
	1 => "深蓝谍影",
	2 => "幽兰",
	3 => "叮当小仙女",
	4 => "粉红",
	5 => "边缘锐化",
	6 => "盖亚10",
	7 => "简单精致",
	8 => "暗色玻璃",
	9 => "航空",
	10 => "魅力宝石",
	11 => "金色器具",
	12 => "黑色锐利",
	13 => "粉色相机",
	14 => "透明鼠标",
	15 => "永恒之塔",
	16 => "叶鼠标",
	17 => "黑色水晶光晕",
	18 => "牛奶",
	19 => "雷龙",
	20 => "月光",
	21 => "熔岩污垢",
	22 => "青花瓷浅蓝版",
	23 => "青花瓷深蓝版",
	24 => "黑色",
	25 => "淡紫色透明",
	26 => "脉冲玻璃",
	27 => "金橙",
	28 => "亮紫",
	29 => "恋之光橙色",
	30 => "yiona",
	31 => "联想官方主题",
	/* ↓感谢Mr.C提供 */
	32 => "a0x",
	33 => "macOS ElCapitan",
	34 => "Intra",
	35 => "Modern Mac",
	36 => "MoonShine_v3",
	37 => "Simplify Cross Filled",
	38 => "Simplify Cross Stroke",
	39 => "White HD",
	/* ↑感谢Mr.C提供 */
];
if ($method == 'GET') {
	include _include(APP_PATH . 'plugin/till_cursor_custom/setting.htm');
} else {

	$setting['cursor_set'] = param('cursor_set', 1);

	setting_set('till_cursor_custom_setting', $setting);

	message(0, '修改成功');
}
