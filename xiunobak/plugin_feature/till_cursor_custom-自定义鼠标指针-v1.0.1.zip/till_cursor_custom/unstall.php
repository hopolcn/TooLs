<?php

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('till_cursor_custom_setting');

?>