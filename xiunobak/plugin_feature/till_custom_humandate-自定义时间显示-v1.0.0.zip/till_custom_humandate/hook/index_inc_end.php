function custom_humandate($timestamp, $lan) {
	if(function_exists('setting_get')) {
		$setting = setting_get('till_custom_humandate_setting');
		return date($setting['the_format'],$timestamp);
	} else {
		// 获取失败则模拟原装函数效果，更加高效也说不定呢
$seconds = time() - $timestamp;
$lan = empty($lang) ? $lang : $lan;
$lan = empty($lan) ? [
    'month_ago' => '月前',
    'day_ago' => '天前',
    'hour_ago' => '小时前',
    'minute_ago' => '分钟前',
    'second_ago' => '秒前',
] : $lan;

if ($seconds > 31536000) {
    return date('Y-n-j', $timestamp);
}

$interval = [
    2592000 => $lan['month_ago'],
    86400 => $lan['day_ago'],
    3600 => $lan['hour_ago'],
    60 => $lan['minute_ago'],
];

foreach ($interval as $value => $unit) {
    if ($seconds > $value) {
        return floor($seconds / $value) . $unit;
    }
}

return $seconds . $lan['second_ago'];

	}
}