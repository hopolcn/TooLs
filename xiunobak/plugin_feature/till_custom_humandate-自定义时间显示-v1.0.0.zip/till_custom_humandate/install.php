<?php


!defined('DEBUG') AND exit('Forbidden');

$setting = setting_get('till_custom_humandate_setting');
if(empty($setting)) {
	$setting = array('the_format'=>'Y-m-d H:i:s');
	setting_set('till_custom_humandate_setting', $setting);
}

?>