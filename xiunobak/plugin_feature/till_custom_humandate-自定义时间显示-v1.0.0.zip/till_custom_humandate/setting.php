<?php


!defined('DEBUG') and exit('Access Denied.');

$setting = setting_get('till_custom_humandate_setting');

if ($method == 'GET') {

	$input = array();
	$input['the_format'] = form_text('the_format', $setting['the_format']);

	include _include(APP_PATH . 'plugin/till_custom_humandate/setting.htm');
} else {

	$setting['the_format'] = param('the_format', '');

	setting_set('till_custom_humandate_setting', $setting);

	message(0, '修改成功');
}
