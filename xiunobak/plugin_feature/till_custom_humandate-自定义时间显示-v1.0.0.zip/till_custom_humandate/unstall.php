<?php

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('till_custom_humandate_setting');

?>