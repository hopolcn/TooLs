<?php

!defined('DEBUG') AND exit('Forbidden');

$setting = setting_get('till_digitalclock_setting');
if(empty($setting)) {
	$setting = array(
		'clock_type' => 0,
		'clock_round_size' => 150,
		'clock_global_font_color' => '#daf6ff',
		'clock_square_secondary_font_size' => '1.5',
		'clock_square_primary_font_size' => '5',
		'clock_square_background_color_1' => '#000000',
		'clock_square_background_color_2' => '#0a2e38',
		'clock_square_hide_weeks' => false,
		'clock_global_fixed_position' => false,
	);
	setting_set('till_digitalclock_setting', $setting);
}

?>
