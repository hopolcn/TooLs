<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件设置
	admin/plugin-setting-till_digitalclock.htm
*/

!defined('DEBUG') AND exit('Access Denied.');

$setting = setting_get('till_digitalclock_setting');

if($method == 'GET') {
	
	include _include(APP_PATH.'plugin/till_digitalclock/setting.htm');
	
} else {

	$setting['clock_type'] = param('clock_type',0);
	$setting['clock_round_size']  = param('clock_round_size',100);
	$setting['clock_global_font_color']  = param('clock_global_font_color','#ffffff');
	$setting['clock_square_secondary_font_size']  = param('clock_square_secondary_font_size',1.0);
	$setting['clock_square_primary_font_size']  = param('clock_square_primary_font_size',1.0);
	$setting['clock_square_background_color_1'] = param('clock_square_background_color_1','#000000');
	$setting['clock_square_background_color_2'] = param('clock_square_background_color_2','#000000');
	$setting['clock_square_hide_weeks']  = param('clock_square_hide_weeks',false);
	$setting['clock_global_fixed_position']  = param('clock_global_fixed_position',false);
	
	setting_set('till_digitalclock_setting', $setting);
	
	message(0, '修改成功');
}
	
?>