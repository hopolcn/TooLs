<?php


!defined('DEBUG') AND exit('Forbidden');

 setting_delete('till_digitalclock_setting');

?>