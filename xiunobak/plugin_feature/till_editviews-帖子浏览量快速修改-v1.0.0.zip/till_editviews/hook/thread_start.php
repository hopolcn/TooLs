
    if ($action == 'editviews') {
        $_tid = param(2, 0);
        if ($uid && intval($gid) === 1) {
            $_thread = thread_read($_tid);
            if ($_thread) {
                if ($method === "GET") {
                    $new_views = $_thread['views'];
                    include _include(APP_PATH . 'plugin/till_editviews/view/htm/change.htm');
                    die;
                } else {
                    $new_views = param('new_views', 0);
                    $r = thread__update($_tid, ['views' => $new_views]);
                    message(0, lang('update_successfully'));
                    die;
                }
            } else {
                message(-1, lang('thread_not_exists'));
                die;
            }
        } else {
            message(-1, lang('data_malformation'));
        }
    }
