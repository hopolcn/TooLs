//<?php
    // [music type="" href=""] => 音乐播放器
    $this->bbcode_table["/\[music(\s+)type\=\"(.*?)\"(\s+)href\=\"(.*?)\"\]/is"] = function ($match) {
        global $thread;
        // hook till_shortcode_musicPlayer_type_api.php

        /**
         * @var array $args 参数：type：音乐类型；href：链接地址
         */
        $args = array(
            'type' => (!empty($match[2]) ? $match[2] : 'direct'),
            'href' => (!empty($match[4]) ? $match[4] : '')
        );
        $result = '';
        if (empty($args['href'])) {
            return '';
        } else {
            $GLOBALS['tillMusicPlayer_exist'] = true;
            $music_id = strip_tags($args['href']);
            $music_id_array = explode(',', $music_id);

            $result .= '<div id="musicPlayer_q" class="aplayer"></div>'
                . '<script src="plugin/till_shortcode_musicPlayer/view/js/APlayer.min.js"></script>'
                . '<script>'
                . 'var ap4 = new APlayer({
                    element: document.getElementById("musicPlayer_q"),
                    narrow: false,
                    autoplay: false,
                    showlrc: false,
                    mutex: true,
                    theme: "#ad7a86",
                    music: [';
            switch ($args['type']) {
                // hook till_shortcode_musicPlayer_type_case.php
                default: //direct
                    foreach ($music_id_array as $_this_music_id) {
                        $result .= "{
                        title: '" . $thread['subject'] . "',
                        author:'" . $_this_music_id . "',
                        url: '" . $_this_music_id . "',
                        pic: 'plugin/till_shortcode_musicPlayer/view/img/Default.png'
                    },";
                    }
                    break;
            }
            $result .= ']});</script>';
        }
        return $result;
    };
