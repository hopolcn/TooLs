'music' => array(
'name' => '嵌入音乐播放器',
'desc' => 'href：链接，type：类型',
'syntax' => '[music type="{text}" href="{url}"]',
'sample' => ''
),
