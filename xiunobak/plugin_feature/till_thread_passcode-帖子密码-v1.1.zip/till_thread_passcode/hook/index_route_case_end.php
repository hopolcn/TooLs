case 'pass': include _include(APP_PATH.'plugin/till_thread_passcode/route/pass.php'); break;



