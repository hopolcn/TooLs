
thread__update($tid,['passcode' => param('passcode','')]);
