"my_deprecate_nav_label" => '停用账号',
"my_deprecate_heading" => '账号一旦停用就无法恢复，请不要随意尝试！',
"my_deprecate_p1_title" => '账号停用后会发生什么',
"my_deprecate_p1" => array(
'用户名将会重置为%1$s，密码会被随机修改',
'清空全部个人信息（包括但不限于用户组、签名、积分等，但不包括发帖、回帖数量）',
'解绑关联的第三方社交账号、手机号码（若有）',
'用户状态被设置为<q>被停用</q>，禁止登录'
),
"my_deprecate_p1_alt" => array(
'用户将被完全删除，可以再次使用该用户名和邮箱地址注册',
),
"my_deprecate_p2_title" => '存在的痕迹',
"my_deprecate_p2" => array(
'彻底删除用户数据是无法实现的，因为内容发布后，数据就在用户之间就有了关联，也在互联网上留下了存在的痕迹。',
'您可以在停用账号之前删除自己发布的帖子、回帖等。'),
"my_deprecate_p3_title" => '若您确定想要停用本账号，请输入您的用户名。',
"my_deprecate_p3_input_placeholder" => '您的用户名',
"my_deprecate_p3_submit_label" => '停用本账号',
"user_is_deprecated" => '账号被停用',
"Please enter the correct username" => '请输入正确的用户名',
"This user is deactivated and the content is not visible" => '该用户已停用，内容不可见',