
$till_user_deprecated_setting = setting_get('till_user_deprecated_setting');
if(boolval($till_user_deprecated_setting['hide_threads'])) {
    foreach($threadlist as $tid=>$thread) {
        if(intval($gid) !== 1 && boolval($thread['user']['deprecated'])) {
            unset($threadlist[$tid]);
        }
    }
}