case 'log_viewer':		include _include(APP_PATH.'plugin/till_xnlog_viewer/route/log_viewer.php'); 	break;
