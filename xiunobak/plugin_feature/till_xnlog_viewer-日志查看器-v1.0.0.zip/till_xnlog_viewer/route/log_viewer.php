<?php

!defined('DEBUG') and exit('Access Denied.');

$action = param(1, '');

/**
 * 递归获取日志目录下所有文件
 * @param $dir string 日志目录
 * @param $files array 日志文件列表，内部变量，不要传值
 * @return array
 * @throws Exception 
 */
function listFilesByMonth($dir, &$files = []) {
    if (!is_dir($dir)) {
        throw new Exception('目录不存在');
        return [];
    }

    $dh = opendir($dir);
    if (!$dh) {
        throw new Exception('无法打开目录');
        return [];
    }

    while (($month = readdir($dh)) !== false) {
        if ($month !== '.' && $month !== '..' && is_dir($dir . DIRECTORY_SEPARATOR . $month)) {
            $files[$month] = [];
            $monthDir = $dir . DIRECTORY_SEPARATOR . $month;
            $dhMonth = opendir($monthDir);
            if ($dhMonth) {
                while (($file = readdir($dhMonth)) !== false) {
                    if ($file !== '.' && $file !== '..' && is_file($monthDir . DIRECTORY_SEPARATOR . $file)) {
                        $files[$month][] = str_replace('.php', '', $file);
                    }
                }
                closedir($dhMonth);
            }
        }
    }

    closedir($dh);

    return $files;
}

/**  
 * 清除日志目录下的所有文件和子文件夹  
 * @param $dir string 日志目录  
 * @throws Exception  
 */
function clearLogsDirectory($dir) {
    if (!is_dir($dir)) {
        throw new Exception('目录不存在');
    }

    $dh = opendir($dir);
    if (!$dh) {
        throw new Exception('无法打开目录');
    }

    while (($item = readdir($dh)) !== false) {
        if ($item !== '.' && $item !== '..') {
            $fullPath = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($fullPath)) {
                // 如果是子目录，递归删除  
                clearLogsDirectory($fullPath);
                // 删除空目录  
                rmdir($fullPath);
            } elseif (is_file($fullPath)) {
                // 如果是文件，直接删除  
                unlink($fullPath);
            }
        }
    }

    closedir($dh);
}

function log_filename_to_human($name) {
    $translate_table = array(
        'admin_login' => '管理员登录日志',
        'admin_login_error' => '管理员登录错误日志',
        'db_error' => '数据库错误日志',
        'db_exec' => '数据库执行日志',
        'debug_error' => '调试错误日志',
        'php_error' => 'PHP错误日志',
    );
    if (isset($translate_table[$name])) {
        return $translate_table[$name];
    } else {
        return $name;
    }
}

switch ($action) {
    case 'view':
        $where = explode('__', param(2, ''));
        $date = $where[0];
        $file = $where[1];
        $file_location = APP_PATH . 'log' . DIRECTORY_SEPARATOR . $date . DIRECTORY_SEPARATOR . $file . '.php';
        if (!file_exists($file_location)) {
            message(-1, '文件不存在');
        } else {
            $file_content_raw = file($file_location, FILE_SKIP_EMPTY_LINES);
            $length = count($file_content_raw);
            $file_content = [];
            for ($i = $length - 1; $i >= $length - 500; $i--) {
                if (isset($file_content_raw[$i])) {
                    $file_content[] = $file_content_raw[$i];
                }
            }
            include _include(APP_PATH . 'plugin/till_xnlog_viewer/view/logs_view.htm');
        }
        break;
    case 'clear':
        if ($method === 'POST') {
            try {
                $logsDir = APP_PATH . 'log';
                clearLogsDirectory($logsDir);
                message(0, "日志目录清除完成。");
            } catch (Exception $e) {
                message(-1, "清除日志目录时发生错误: " . $e->getMessage());
            }
        } else {
            include _include(APP_PATH . 'plugin/till_xnlog_viewer/view/logs_clear.htm');
        }
        break;

    case 'list':
    default:
        $logs_list = listFilesByMonth(APP_PATH . 'log');
        include _include(APP_PATH . 'plugin/till_xnlog_viewer/view/logs_list.htm');
        break;
}
