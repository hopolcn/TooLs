<?php exit; //assbbs.com
$tiny=kv_get('tiny');
if(!empty($tiny['noattach'])){die('assbbs_noattach');}
?>