<?php exit; //assbbs.com
global $tiny;
tiny_sync(null,$arr['message'],$pid);
if(!empty($tiny['cleanday'])){tiny_clean($tiny['cleanday']);}
?>