$arr['credits']=$credits;
$arr['golds']=$golds;
$arr['rmbs']=$rmbs;