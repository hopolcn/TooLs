case 'tt_deposit': include APP_PATH.'plugin/tt_deposit/setting.php'; break;
case 'deposit_payperson': include APP_PATH.'plugin/tt_deposit/admin_deposit_payperson.php'; break;