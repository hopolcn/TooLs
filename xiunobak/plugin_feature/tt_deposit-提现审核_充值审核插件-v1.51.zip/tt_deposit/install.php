<?php
!defined('DEBUG') AND exit('Forbidden');
setting_set('tt_deposit',array('min'=>'1000','mail_notify'=>0,'mail_to'=>'123456@qq.com'));
?>