 'charge'=>'充值',
 'value_'=>'金额 (单位:分)',
 'willcharge'=>'将充值',