<?php
!defined('DEBUG') AND exit('Forbidden');
setting_set('tt_payperson',array('min'=>'1000'));
?>