
	thread_stamp_delete($tid, $uid, $fid);