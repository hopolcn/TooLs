include _include(APP_PATH.'plugin/tt_vip/model/vip.func.php');
