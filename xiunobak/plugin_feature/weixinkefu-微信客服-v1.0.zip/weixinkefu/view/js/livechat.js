// JavaScript Document
jQuery( function ( $ ) {  
    var isMobile = {
    Android : function() {
      return navigator.userAgent.match(/Android/i) ? true : false;
    },
    BlackBerry : function() {
      return navigator.userAgent.match(/BlackBerry/i) ? true : false;
    },
    iOS : function() {
      return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
    },
    Windows : function() {
      return navigator.userAgent.match(/IEMobile/i) ? true : false;
    },
    any : function() {
      return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
    }
  };
  
    setInterval(function(){
        if($(".animated-circles").hasClass("animated")){
            $(".animated-circles").removeClass("animated");
        }else{
            $(".animated-circles").addClass('animated');
        }
    },3000);
    var wait = setInterval(function(){
        $(".livechat-hint").removeClass("show_hint").addClass("hide_hint");
        clearInterval(wait);
    },4500);
    $(".livechat-girl").hover(function(){
        clearInterval(wait);
        $(".livechat-hint").removeClass("hide_hint").addClass("show_hint");
    },function(){
        $(".livechat-hint").removeClass("show_hint").addClass("hide_hint");
    }).click(function(){    
        if(isMobile.any()){
             window.open("https://work.weixin.qq.com/kfid/??????????????");//�˴���ַ�����޸�
        }else{
             window.open("https://work.weixin.qq.com/kfid/??????????????");//�˴���ַ�����޸�
          }
    }); 
} );