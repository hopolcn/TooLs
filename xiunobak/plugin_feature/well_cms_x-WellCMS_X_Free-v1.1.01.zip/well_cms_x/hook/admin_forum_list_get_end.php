<?php exit;
// 后台栏目管理列表
// hook website_admin_forum_list_get_start.php
$forumarr = well_category_tree($forumlist);
// hook website_admin_forum_list_get_end.php
?>