<?php exit;
case 'content': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/content.php'); break;
case 'forum': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/forum.php'); break;
case 'flag': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/flag.php'); break;
case 'template': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/template.php'); break;
case 'reply': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/reply.php'); break;
case 'top': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/top.php'); break;
case 'system': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/system.php'); break;
case 'group': include _include(APP_PATH . 'plugin/well_cms_x/admin/route/group.php'); break;
?>