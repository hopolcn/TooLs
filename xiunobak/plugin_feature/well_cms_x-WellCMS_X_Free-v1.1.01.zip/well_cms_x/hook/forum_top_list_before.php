<?php exit;
$forum['well_type'] != 0 AND message(-1, lang('user_group_insufficient_privilege'));
?>