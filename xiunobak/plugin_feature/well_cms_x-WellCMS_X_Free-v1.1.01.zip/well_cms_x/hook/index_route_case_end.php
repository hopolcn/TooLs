<?php exit;
case 'read': include _include(APP_PATH . 'plugin/well_cms_x/route/read.php');break;
case 'list':include _include(APP_PATH . 'plugin/well_cms_x/route/list.php');break;
case 'category': include _include(APP_PATH . 'plugin/well_cms_x/route/category.php');break;
case 'tag': include _include(APP_PATH . 'plugin/well_cms_x/route/tag.php');break;
case 'flag': include _include(APP_PATH . 'plugin/well_cms_x/route/flag.php');break;
case 'mode': include _include(APP_PATH . 'plugin/well_cms_x/route/mode.php');break;
case 'reply': include _include(APP_PATH . 'plugin/well_cms_x/route/reply.php');break;
?>