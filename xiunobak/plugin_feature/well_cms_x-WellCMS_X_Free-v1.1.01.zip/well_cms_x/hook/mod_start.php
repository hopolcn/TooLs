<?php exit;
// 方便移动帖子，只显示bbs版块
    $forumlist = well_forum_list($forumlist);
    $forumlist_show = forum_list_access_filter($forumlist, $gid);
    $forumarr = arrlist_key_values($forumlist_show, 'fid', 'name');
?>