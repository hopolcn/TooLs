<?php exit;
if ($forum['well_flag']) {
    $flagarr = explode(',', $forum['well_flag']);
    $n = count($flagarr);
    $flaglist = well_website_flag_find_by_flagid_cache($flagarr, 1, $n);
    foreach ($flagarr as $key => $flagid) {
        unset($flaglist[$flagid]['fid']);
        unset($flaglist[$flagid]['count']);
        unset($flaglist[$flagid]['display']);
        unset($flaglist[$flagid]['create_date']);
        unset($flaglist[$flagid]['display_text']);
        unset($flaglist[$flagid]['column_name']);
    }
    $forum['well_flag_text'] = well_array_multisort_key($flaglist, 'rank', FALSE, 'flagid');
}
$forum['well_picture_size'] = $forum['well_picture_size'] ? json_decode($forum['well_picture_size'], true) : '';
$forum['url'] = well_nav_format($forum);
?>