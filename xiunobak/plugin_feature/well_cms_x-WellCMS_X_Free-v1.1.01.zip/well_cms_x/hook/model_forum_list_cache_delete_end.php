<?php exit;
// 删除首页所有缓存
cache_delete('website_index_list');
// 删除首页属性调用缓存
cache_delete('website_flag_index');
?>