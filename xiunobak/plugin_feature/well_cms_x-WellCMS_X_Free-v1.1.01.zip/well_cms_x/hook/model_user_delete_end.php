<?php exit;
    well_thread_delete_all_by_uid($uid);
?>