<?php exit;
$forum['well_type'] == 1 AND message(-1, lang('user_group_insufficient_privilege'));
?>