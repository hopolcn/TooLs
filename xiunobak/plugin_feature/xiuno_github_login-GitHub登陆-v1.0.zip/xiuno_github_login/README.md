
Xiuno BBS 4.x 插件 - GitHub登录
------------------

- http://plugin.xiuno.com/plugin-read-xiuno_github_login.htm
- https://bbs.xiuno.com/thread-151930.htm

### 设置 OAuth Apps
- https://github.com/settings/developers
```
在GitHub地址点击`New OAuth App`创建一个应用,设置应用名得到App的数据。
在Xiuno系统后台设置:
Application Name
Client ID
Client Secret
```

### 截图
[![screenshot-1.png](/screenshot/screenshot-1.png)](/screenshot/screenshot-1.png)

[![screenshot-2.png](/screenshot/screenshot-2.png)](/screenshot/screenshot-2.png)

[![screenshot-3.png](/screenshot/screenshot-3.png)](/screenshot/screenshot-3.png)

[![screenshot-4.png](/screenshot/screenshot-4.png)](/screenshot/screenshot-4.png)

### 注意
```
卸载插件时，会删除GitHub与用户UID绑定的表。如果有用户是直接使用微信登录（新建用户），则会导致该用户无法再正常登录。
切记！！！
```

### 作者
```
Author: midoks
Email : midoks@163.com
Link : https://www.cachecha.com
```