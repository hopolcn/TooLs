param('password') != md5(param('repeat_password')) AND message('password','两次密码不一致,请重新输入');
