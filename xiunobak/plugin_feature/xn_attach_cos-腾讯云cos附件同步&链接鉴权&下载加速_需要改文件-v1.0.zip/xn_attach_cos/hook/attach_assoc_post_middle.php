
include_once APP_PATH.'/plugin/xn_attach_cos/model/attachcos.func.php';
$cos_key=attachcos_upload($destfile,$file['orgfilename']);
$r_cos = db_update('attach', array('aid'=>$aid), array('cos_key'=>$cos_key));
