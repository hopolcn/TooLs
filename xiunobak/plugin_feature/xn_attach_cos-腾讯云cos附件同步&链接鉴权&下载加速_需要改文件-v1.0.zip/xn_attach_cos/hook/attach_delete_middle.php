
include_once APP_PATH.'/plugin/xn_attach_cos/model/attachcos.func.php';
$cos_key = $attach['cos_key'];
$cos_delete=attachcos_delete($cos_key);
