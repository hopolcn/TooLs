
attach_update($aid, array('downloads+'=>1));
include_once APP_PATH.'/plugin/xn_attach_cos/model/attachcos.func.php';
$config_url=kv_get('xn_attach_cos');
$urlmode=$config_url['url_mode'];
if ($urlmode==1){
$attachurl=attachcos_url($attach['cos_key']);
}
if ($urlmode==2){
$cdnurl=$config_url['cdnurl'];
$cdnkey=$config_url['cdnkey'];
$attachurl=attachcos_url_cdn($cdnurl,$attach['cos_key'],$cdnkey);
}