
if($attach['cos_key'] != '0'){
$type='qcloud';
}