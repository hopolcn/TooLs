<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;
$sql = "ALTER TABLE ".$tablepre."attach ADD cos_key CHAR(200) NOT NULL default '0';";
db_exec($sql);
$xn_attach_cos = kv_get('xn_attach_cos');
if(empty($xn_attach_cos)) {
    $xn_attach_cos = array(
        'secretId' => '',
        'secretKey' => '',
        'pre' => '[修罗中国]xiuno.cn',
        'region' => '',
        'bucket' => '',
        'delete_local_file' => '',
        'sign_time' => '2',
        'url_mode' => '1',
        'cdnurl' => 'http://example.com',
    );
    kv_set('xn_attach_cos', $xn_attach_cos);


}?>