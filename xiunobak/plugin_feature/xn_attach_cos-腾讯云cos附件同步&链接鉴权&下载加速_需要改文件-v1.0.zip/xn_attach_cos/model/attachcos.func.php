<?php
include_once APP_PATH.'/plugin/xn_attach_cos/sdk/vendor/autoload.php';
function attachcos_upload($destfile,$orgfilename) {
$config = kv_get('xn_attach_cos');
$res_erro=array(
    'file'=>'',
    'line'=>'',
    'message'=>'',
);
$secretId = $config['secretId'];
$secretKey = $config['secretKey'];
$region = $config['region'];
$bucket = $config['bucket'];
$pre=$config['pre'];
$delete_local_file = $config['delete_local_file'];
$cos_key = 'file/'.date('Y').'/'.date('m').'/'.$pre.'_'.rand(10000,99999).'_'.$orgfilename;
$cos_key = preg_replace('/([\x80-\xff]*)/i', '',$cos_key);
$cosClient = new Qcloud\Cos\Client(
    array(
        'region' => $region,
        'schema' => 'https', //协议头部，默认为http
        'credentials'=> array(
            'secretId'  => $secretId ,
            'secretKey' => $secretKey)));
try {
    $result = $cosClient->upload(
        $bucket = $bucket, 
        $key = $cos_key,
        $body = fopen($destfile, 'rb')
    );
} catch (\Throwable $e) {
        $res_erro['file']=$e->getFile(); // 错误文件路径
        $res_erro['line']=$e->getLine(); // 错误行
        $res_erro['message']=$e->getMessage(); // 错误信息

}


    if ($delete_local_file == 1){
            @unlink($destfile); //删除本地文件
        }
return  $cos_key;

}

function attachcos_url($cos_key){
$config = kv_get('xn_attach_cos');
$res_erro=array(
    'file'=>'',
    'line'=>'',
    'message'=>'',
);
$tmpSecretId = $config['secretId'];
$tmpSecretKey = $config['secretKey'];
$region = $config['region'];
$bucket = $config['bucket'];
$sign_time = $config['sign_time'];
$key = $cos_key;
$cosClient = new Qcloud\Cos\Client(
    array(
        'region' => $region,
        'schema' => 'https', //协议头部，默认为 http
        'signHost' => 'true', //默认签入Header Host；您也可以选择不签入Header Host，但可能导致请求失败或安全漏洞,若不签入host则填false
        'credentials'=> array(
            'secretId'  => $tmpSecretId,
            'secretKey' => $tmpSecretKey)));

### 简单下载预签名
try {
    $signedUrl = $cosClient->getPreSignedUrl('getObject', array(
        'Bucket' => $bucket, //存储桶，格式：BucketName-APPID
        'Key' => $key, //对象在存储桶中的位置，即对象键
        'Params'=> array(), //http 请求参数，传入的请求参数需与实际请求相同，能够防止用户篡改此HTTP请求的参数,默认为空
        'Headers'=> array(), //http 请求头部，传入的请求头部需包含在实际请求中，能够防止用户篡改签入此处的HTTP请求头部,默认已签入host
    ), '+'.$sign_time.' minutes'); //签名的有效时间
    // 请求成功

} catch (\Throwable $e) {
    // 请求失败
    $res_erro['file']=$e->getFile(); // 错误文件路径
    $res_erro['line']=$e->getLine(); // 错误行
    $res_erro['message']=$e->getMessage(); // 错误信息
}


    return $signedUrl;


}

function attachcos_delete($cos_key){
$config = kv_get('xn_attach_cos');
$res_erro=array(
    'file'=>'',
    'line'=>'',
    'message'=>'',
);
$secretId = $config['secretId'];
$secretKey = $config['secretKey'];
$region = $config['region'];
$bucket = $config['bucket'];
$cosClient = new Qcloud\Cos\Client(
    array(
        'region' => $region,
        'schema' => 'https', //协议头部，默认为http
        'credentials'=> array(
            'secretId'  => $secretId ,
            'secretKey' => $secretKey)));

try {
    $result = $cosClient->deleteObject(array(
        'Bucket' => $bucket, 
        'Key' => $cos_key
    )); 
} catch (\Throwable $e) {
    $res_erro['file']=$e->getFile(); // 错误文件路径
    $res_erro['line']=$e->getLine(); // 错误行
    $res_erro['message']=$e->getMessage(); // 错误信息
}

}

function attachcos_url_cdn($cdnurl,$cos_key,$cdnkey) {
    $urlpath= $cos_key;
    $costimestamp = time();
    $cosrand = uniqid('xiunocn');
    $cosmd5hash = md5('/'.$urlpath.'-'.$costimestamp.'-'.$cosrand .'-0-'.$cdnkey);
    $signedUrl = $cdnurl.'/'.$urlpath.'?sign='.$costimestamp.'-'.$cosrand.'-0-'.$cosmd5hash;
    return $signedUrl;

}