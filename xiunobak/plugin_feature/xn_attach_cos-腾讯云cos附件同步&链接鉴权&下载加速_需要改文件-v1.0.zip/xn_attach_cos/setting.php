<?php
!defined('DEBUG') AND exit('Access Denied.');
if($method == 'GET'){

        $xn_attach_cos = kv_get('xn_attach_cos');
        $input['secretId'] = $xn_attach_cos['secretId'];
        $input['pre'] = $xn_attach_cos['pre'];
        $input['secretKey'] = $xn_attach_cos['secretKey'];
        $input['region'] = $xn_attach_cos['region'];
        $input['bucket'] = $xn_attach_cos['bucket'];
        $input['delete_local_file'] = $xn_attach_cos['delete_local_file'];
        $input['sign_time'] = $xn_attach_cos['sign_time'];
        $input['url_mode'] = $xn_attach_cos['url_mode'];
        $input['cdnurl'] = $xn_attach_cos['cdnurl'];
        $input['cdnkey'] = $xn_attach_cos['cdnkey'];
       include _include(APP_PATH.'plugin/xn_attach_cos/setting.htm');
       
    } elseif($method == 'POST'){
        $input = array();
        $input['secretId'] = param('secretId', '');
        $input['pre'] = param('pre', '');
        $input['secretKey'] = param('secretKey', '');
        $input['region'] = param('region', '');
        $input['bucket'] = param('bucket', '');
        $input['delete_local_file'] = param('delete_local_file', '');
        $input['sign_time'] = param('sign_time', '');
        $input['url_mode'] = param('url_mode', '');
        $input['cdnurl'] = param('cdnurl', '');
        $input['cdnkey'] = param('cdnkey', '');
        kv_set('xn_attach_cos', $input);
        message(0, lang('modify_successfully'));
    
    }

?>