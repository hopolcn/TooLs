<?php exit;
require_once APP_PATH . '/plugin/xn_baidu_text/sdk/AipContentCensor.php';

function api_content_censor($text_content,&$err_bd_text){
$bd_config=kv_get('xn_baidu_text');
$APP_ID = $bd_config['bd_appid'];
$API_KEY = $bd_config['bd_key'];
$SECRET_KEY = $bd_config['bd_secret'];
$client = new AipContentCensor($APP_ID, $API_KEY, $SECRET_KEY);

$result = $client->textCensorUserDefined("$text_content");

if ($result['conclusion']=='合规') {

	return false;

} else {
	$err_bd_text = $result['data'][0]['msg'];
	return true;
}
}