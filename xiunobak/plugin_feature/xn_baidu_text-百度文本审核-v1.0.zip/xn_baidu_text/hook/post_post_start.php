<?php exit;
	api_content_censor($_REQUEST['message'],$bd_error) AND message('message', '含有敏感内容：' . $bd_error);
