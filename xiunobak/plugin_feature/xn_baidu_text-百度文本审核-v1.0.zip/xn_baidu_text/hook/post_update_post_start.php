<?php exit;
if ($subject!=''){
		api_content_censor($subject,$bd_error) AND message('subject', '标题含有敏感内容：' . $bd_error);
    
}
		api_content_censor($message,$bd_error) AND message('message', '帖子含有敏感内容：' . $bd_error);