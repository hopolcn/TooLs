<?php exit;
	api_content_censor($thread['subject'],$bd_error) AND message('subject', '标题内容含有敏感内容：' . $bd_error);
	api_content_censor($thread['message'],$bd_error) AND message('message', '文章内容含有敏感内容：' . $bd_error);