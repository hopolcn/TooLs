<?php

/*
	Xiuno BBS 4.0 插件：百度文本审核安装
	admin/plugin-install-xn_baidu_text.htm
*/

!defined('DEBUG') AND exit('Forbidden');

// 初始化
$kv = kv_get('xn_baidu_text');
if(!$kv) {
	$kv = array(
		'bd_appid' => '',
		'bd_key' => '',
		'bd_secret' => '',
	);
	kv_cache_set('xn_baidu_text', $kv);
}

?>