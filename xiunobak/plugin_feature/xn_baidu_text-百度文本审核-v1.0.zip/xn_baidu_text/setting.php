<?php

/*
	Xiuno BBS 4.0 插件：百度文本审核设置
	admin/plugin-setting-xn_baidu_text.htm
*/

!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
    $input = array();
	$kv = kv_get('xn_baidu_text');
	$input['bd_appid'] = form_text('bd_appid', $kv['bd_appid']);
	$input['bd_key'] = form_text('bd_key', $kv['bd_key']);
	$input['bd_secret'] = form_text('bd_secret', $kv['bd_secret']);
	include _include(APP_PATH.'plugin/xn_baidu_text/setting.htm');
} else {
    $kv = array();
	$kv['bd_appid'] = param('bd_appid');
	$kv['bd_key'] = param('bd_key');
	$kv['bd_secret'] = param('bd_secret');
	kv_set('xn_baidu_text', $kv);
	message(0, '修改成功');
}