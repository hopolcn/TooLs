<?php

/*
	Xiuno BBS 4.0 插件：百度文本审核卸载
	admin/plugin-unstall-xn_baidu_text.htm
*/

!defined('DEBUG') AND exit('Forbidden');
kv_delete('xn_baidu_text');

?>