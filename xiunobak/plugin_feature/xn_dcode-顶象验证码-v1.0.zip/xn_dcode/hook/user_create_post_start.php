include_once APP_PATH.'plugin/xn_dcode/model/dcode.fuc.php';
$dcode_mail_status = kv_get('dcode');
if ($dcode_mail_status['dcode_mail_on'] != 1){
dcodecheck('dcode_user_create_on');
}

