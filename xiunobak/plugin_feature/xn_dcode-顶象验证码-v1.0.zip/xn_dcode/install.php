<?php

	$kv = array('dcode_appid'=>'', 'dcode_appkey'=>'','dcode_url'=>'', 'dcode_user_login_on'=>'', 'dcode_user_create_on'=>'', 'dcode_mail_on'=>'', 'dcode_user_findpw_on'=>'', 'dcode_thread_create_on'=>'', 'dcode_post_create_on'=>'', 'dcode_edit_on'=>'');
	kv_set('dcode', $kv);

?>