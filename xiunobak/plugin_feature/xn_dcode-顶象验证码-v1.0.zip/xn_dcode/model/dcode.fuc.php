<?php

function check_ticket($token) {
	$config = kv_get('dcode');
include_once APP_PATH.'plugin/xn_dcode/sdk/CaptchaClient.php';
/**构造入参为appId和appSecret
 * appId和前端验证码的appId保持一致，appId可公开
 * appSecret为秘钥，请勿公开
 * token在前端完成验证后可以获取到，随业务请求发送到后台，token有效期为两分钟**/
$appId = $config['dcode_appid'];
$appSecret = $config['dcode_appkey'];
$appurl = 'https://'.$config['dcode_url'].'/api/tokenVerify';
$client = new CaptchaClient($appId, $appSecret);
$client->setTimeOut(2);      //设置超时时间，默认2秒
$client->setCaptchaUrl($appurl);   
//指定服务器地址，saas可在控制台，应用管理页面最上方获取
$response = $client->verifyToken($token);  //token指的是前端传递的值，即验证码验证成功颁发的token

//确保验证状态是SERVER_SUCCESS，SDK中有容错机制，在网络出现异常的情况会返回通过
if($response->result){
    return 1;
    /**token验证通过，继续其他流程**/
}else{
    return -1;
    /**token验证失败**/
}
}


function dcodecheck($mode) {
    $config = kv_get('dcode');
    if ($config[$mode]==0)  return;
    $token = $_POST['xn_dcodetoken'];
    empty($token) AND message('Captcha', '请点击完成人机验证后再提交！');
    $result = check_ticket($token);
   if ($result==-1){
       message('Captcha', '验证错误，请重新进行人机验证');
   }
}
