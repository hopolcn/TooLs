<?php
/**
 * Created by PhpStorm.
 * User: dingxiang-inc
 * Date: 2017/8/19
 * Time: 上午11:39
 */

class CtuRequest
{
    public $eventCode;             // 事件code
    public $flag;                  // 客户端请求标记,用来标识该次请求
    public $data;                  // 事件参数
}
