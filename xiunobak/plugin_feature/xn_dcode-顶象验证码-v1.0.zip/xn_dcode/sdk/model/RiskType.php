<?php
/**
 * Created by PhpStorm.
 * User: dingxiang-inc
 * Date: 2017/8/19
 * Time: 下午1:07
 */

class RiskType
{
    const RUBBISH_REGISTRATION = "垃圾注册";
    const ACCOUNT_STOLEN = "账号盗用";
    const MACHINE_CRAWLING = "机器爬取";
    const BATCH_LOGON = "批量登陆";
    const MALICIOUS_GRAB = "黄牛抢单";
    const UNKNOWN = "未定义";
}