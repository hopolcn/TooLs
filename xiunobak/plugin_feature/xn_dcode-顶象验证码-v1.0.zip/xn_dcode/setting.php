<?php


!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	$kv = kv_get('dcode');
	$input = array();
	$input['dcode_appid'] = form_text('dcode_appid', $kv['dcode_appid']);
	$input['dcode_url'] = form_text('dcode_url', $kv['dcode_url']);
	$input['dcode_appkey'] = form_text('dcode_appkey', $kv['dcode_appkey']);
	$input['dcode_user_login_on'] = form_radio_yes_no('dcode_user_login_on', $kv['dcode_user_login_on']);
	$input['dcode_user_create_on'] = form_radio_yes_no('dcode_user_create_on', $kv['dcode_user_create_on']);
	$input['dcode_mail_on'] = form_radio_yes_no('dcode_mail_on', $kv['dcode_mail_on']);
	$input['dcode_user_findpw_on'] = form_radio_yes_no('dcode_user_findpw_on', $kv['dcode_user_findpw_on']);
	$input['dcode_thread_create_on'] = form_radio_yes_no('dcode_thread_create_on', $kv['dcode_thread_create_on']);
	$input['dcode_post_create_on'] = form_radio_yes_no('dcode_post_create_on', $kv['dcode_post_create_on']);
	$input['dcode_edit_on'] = form_radio_yes_no('dcode_edit_on', $kv['dcode_edit_on']);
	include _include(APP_PATH.'plugin/xn_dcode/setting.htm');
} else {
	$kv = array();
	$kv['dcode_url'] = param('dcode_url');
	$kv['dcode_appkey'] = param('dcode_appkey');
	$kv['dcode_appid'] = param('dcode_appid');
	$kv['dcode_user_login_on'] = param('dcode_user_login_on');
	$kv['dcode_user_create_on'] = param('dcode_user_create_on');
	$kv['dcode_mail_on'] = param('dcode_mail_on');
	$kv['dcode_user_findpw_on'] = param('dcode_user_findpw_on');
	$kv['dcode_thread_create_on'] = param('dcode_thread_create_on');
	$kv['dcode_post_create_on'] = param('dcode_post_create_on');
	$kv['dcode_edit_on'] = param('dcode_edit_on');
	kv_set('dcode', $kv);
	message(0, '修改成功');
}
	
?>