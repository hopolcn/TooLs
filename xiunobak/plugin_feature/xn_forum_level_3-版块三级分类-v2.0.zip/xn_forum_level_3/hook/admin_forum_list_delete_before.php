<?php exit;

forum_delete_sons($k);

?>