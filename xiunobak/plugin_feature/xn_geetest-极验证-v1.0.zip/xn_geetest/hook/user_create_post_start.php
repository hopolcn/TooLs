include_once APP_PATH.'plugin/xn_geetest/model/geetest.fuc.php';
$geetest_mail_status = kv_get('geetest');
if ($geetest_mail_status['geetest_mail_on'] != 1){
geetestcheck('geetest_user_create_on');
}