	if($op == 'recount') {
		thread_recount($tid);
				
	}