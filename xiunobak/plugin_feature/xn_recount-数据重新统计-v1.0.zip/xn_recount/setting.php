<?php

/*
	重新统计
	admin/plugin-setting-xn_recount.htm
*/

!defined('DEBUG') AND exit('Access Denied.');

http_location(url('thread'));

?>