<?php
$conf = include '../../conf/conf.php';
include '../../xiunophp/xiunophp.php';

$kw = trim( _GET('keyword' ) );
$cb = _GET( 'cb' );
$re = parse_url( _SERVER( 'HTTP_REFERER' ), PHP_URL_HOST );
$hs = parse_url( _SERVER( 'HTTP_HOST' ), PHP_URL_HOST );

if( strlen( $kw ) > 0 && preg_match( '/^BaiduSuggestion\.res\.__\d+$/i', $cb ) && $re === $hs ) {
	header( 'Expires:-1' );
	header( 'Pramga: no-cache' );
	header( 'Content-type: text/javascript' );
	header( 'Cache-Control: no-cache, must-revalidate, no-store' );
	header( 'Last-Modified: '. gmdate( 'D, d M Y 01:01:01', ( time() - 86400 ) ) .' GMT' );

	$return	= '';
	$array	= array();
	$result	= db_find(
		'post',
		array(
			'message'	=> array(
				'LIKE'	=> $kw
			)
		),
		array(
			'tid'	=> -1
		),
		'1',
		'20',
		'',
		array('message')
	);

	if( $result === false ) return;

	foreach( $result as $v ) {
		preg_match_all( "#([^\s\p{P}\p{S}\p{Z}]?){0,5}({$kw})([^\s\p{P}\p{S}\p{Z}]?){0,5}#uis", $v['message'], $matches );
		$array	= array_merge( $array, $matches[0] );
		$array	= array_unique( $array );
	}

	shuffle( $array );
	for( $i = 0, $len = count( $array ); $i < ( $len > 10 ? 10 : $len ); $i++ ) {
		if( strlen( $array[$i] ) > 0 ) $return .= "'{$array[$i]}',";
	}

	$return = rtrim( $return, ',' );
	echo "if('function'===typeof window['openSug']){$cb}({s:[{$return}]});";
} else {
	header( 'Status: 404 Not Found' );
	exit;
}