<?php

/*
	Xiuno BBS 4.0 插件实例：搜索插件卸载
	admin/plugin-unstall-xn_search.htm
*/

!defined( 'DEBUG' ) AND header( 'HTTP/1.1 404 Not Found' ) & exit();

// 删除数据库kv里的配置
db_delete( 'kv', array(
	'k'	=> 'b13417090650b0085d87f29ca5223976'
) );

?>