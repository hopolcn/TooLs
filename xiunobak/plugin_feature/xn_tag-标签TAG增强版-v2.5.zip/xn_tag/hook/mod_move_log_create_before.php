thread_update($tid, array('tagids'=>'', 'tagids_time'=>0));
tag_thread_delete_by_tid($tid);