include_once APP_PATH.'plugin/xn_tcode/model/tcode.fuc.php';
$tcode_mail_status = kv_get('tcode');
if ($tcode_mail_status['tcode_mail_on'] != 1){
tcodecheck('tcode_user_create_on');
}

