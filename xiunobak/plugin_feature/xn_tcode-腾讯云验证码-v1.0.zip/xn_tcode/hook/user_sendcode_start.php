include_once APP_PATH.'plugin/xn_tcode/model/tcode.fuc.php';
tcodecheck('tcode_mail_on');