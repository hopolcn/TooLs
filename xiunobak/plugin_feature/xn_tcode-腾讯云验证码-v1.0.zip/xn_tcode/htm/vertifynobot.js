
        window.tcaptchaCallback = function(res){
            console.log('callback:', res);
            if(res.ret === 0){
                var but = document.getElementById("TencentCaptcha");
                document.getElementById("xn_ticket").value = res.ticket;
                document.getElementById("xn_randstr").value = res.randstr;
                but.style.cssText = "color:#fff;background:#4fb845;border-color:#4fb845;pointer-events:none";
                but.innerHTML = "验证成功";
            }
        }
<?php $CaptchaAppId=kv_get('tcode'); ?>
$(document).ready(function(){
	var captcha1 = new TencentCaptcha('<?php echo $CaptchaAppId['tcode_appid']; ?>', tcaptchaCallback);
	$("#TencentCaptcha").click(function(){
		captcha1.show();
	})
})
