<?php

	$kv = array('tcode_secretid'=>'','tcode_secretkey'=>'','tcode_appid'=>'', 'tcode_appkey'=>'', 'tcode_user_login_on'=>'', 'tcode_user_create_on'=>'', 'tcode_mail_on'=>'', 'tcode_user_findpw_on'=>'', 'tcode_thread_create_on'=>'', 'tcode_post_create_on'=>'', 'tcode_edit_on'=>'');
	kv_set('tcode', $kv);

?>