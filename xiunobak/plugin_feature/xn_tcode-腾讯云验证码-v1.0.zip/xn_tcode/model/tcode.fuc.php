<?php

function check_ticket($ticket, $randstr) {
//获取参数
$kv=kv_get('tcode');
$secretid = $kv['tcode_secretid'];
$secretkey = $kv['tcode_secretkey'];
$Nonce = rand(10000,99999);
$timestamp = time();
$AppSecretKey = $kv['tcode_appkey']; 
$Appid = $kv['tcode_appid']; 
$UserIP = "127.0.0.1"; 
$Action = "DescribeCaptchaResult";
//生成签名v1.0
$param=array("Action" => $Action,
	    "Timestamp" => $timestamp,
	    "Nonce" => $Nonce,
	    "Version" => '2019-07-22',
	    "SecretId" => $secretid,
		"CaptchaType" => '9',
		"Ticket" => $ticket,
		"UserIp" => $UserIP,
		"Randstr" => $randstr,
		"CaptchaAppId" => $Appid,
		"AppSecretKey" => $AppSecretKey);
ksort($param);
$signStr = "POSTcaptcha.tencentcloudapi.com/?";
foreach ( $param as $key => $value ) {
    $signStr = $signStr . $key . "=" . $value . "&";
}
$signStr = substr($signStr, 0, -1);
$signature = base64_encode(hash_hmac("sha1", $signStr, $secretkey, true));
//请求接口
	$url = "https://captcha.tencentcloudapi.com/?";
	$params = array(
	    "Action" => $Action,
	    "Timestamp" => $timestamp,
	    "Nonce" => $Nonce,
	    "Version" => '2019-07-22',
	    "SecretId" => $secretid,
		"CaptchaType" => '9',
		"Ticket" => $ticket,
		"UserIp" => $UserIP,
		"Randstr" => $randstr,
		"CaptchaAppId" => $Appid,
		"AppSecretKey" => $AppSecretKey,
		"Signature" => $signature
	);
    $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, FALSE);//不抓取头部信息。只返回数据
        curl_setopt($curl, CURLOPT_TIMEOUT,1000);//超时设置
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);//1表示不返回bool值
        curl_setopt($curl, CURLOPT_POST, TRUE);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));//v1签名使用
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
        $response = curl_exec($curl);
    curl_close( $curl );
	$result = json_decode($response,true);
//判断返回参数
	if(!empty($result['Response']['CaptchaCode'])){
		if($result['Response']['CaptchaCode'] == 1){
			return 1;
		}else{
			return -1;
		}
	}else{
		return 0;
	}	
}


function tcodecheck($mode) {
    $config = kv_get('tcode');
    if ($mode!=='sign_bbs' && $config[$mode]==0)  return;
    $tcode_ticket = $_POST['xn_ticket'];
    $tcode_randstr = $_POST['xn_randstr'];
    empty($tcode_ticket || $tcode_randstr ) AND message('TencentCaptcha', '请点击完成人机验证后再提交！');
    $result = check_ticket($tcode_ticket, $tcode_randstr);
   if ($result==-1){
       message('TencentCaptcha', '验证错误，请重新进行人机验证');
   }
   if ($result==0){
       message('TencentCaptcha', '人机验证接口失效，请联系站长！');
   }
}
