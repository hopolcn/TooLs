<?php


!defined('DEBUG') AND exit('Access Denied.');

if($method == 'GET') {
	
	$kv = kv_get('tcode');
	
	
	$input = array();
	$input['tcode_secretid'] = form_text('tcode_secretid', $kv['tcode_secretid']);
	$input['tcode_secretkey'] = form_text('tcode_secretkey', $kv['tcode_secretkey']);
	$input['tcode_appid'] = form_text('tcode_appid', $kv['tcode_appid']);
	$input['tcode_appkey'] = form_text('tcode_appkey', $kv['tcode_appkey']);
	$input['tcode_user_login_on'] = form_radio_yes_no('tcode_user_login_on', $kv['tcode_user_login_on']);
	$input['tcode_user_create_on'] = form_radio_yes_no('tcode_user_create_on', $kv['tcode_user_create_on']);
	$input['tcode_mail_on'] = form_radio_yes_no('tcode_mail_on', $kv['tcode_mail_on']);
	$input['tcode_user_findpw_on'] = form_radio_yes_no('tcode_user_findpw_on', $kv['tcode_user_findpw_on']);
	$input['tcode_thread_create_on'] = form_radio_yes_no('tcode_thread_create_on', $kv['tcode_thread_create_on']);
	$input['tcode_post_create_on'] = form_radio_yes_no('tcode_post_create_on', $kv['tcode_post_create_on']);
	$input['tcode_edit_on'] = form_radio_yes_no('tcode_edit_on', $kv['tcode_edit_on']);
	
	// hook plugin_tcode_setting_get_end.htm
	
	include _include(APP_PATH.'plugin/xn_tcode/setting.htm');
	
} else {

	$kv = array();
	$kv['tcode_secretid'] = param('tcode_secretid');
	$kv['tcode_secretkey'] = param('tcode_secretkey');
	$kv['tcode_appid'] = param('tcode_appid');
	$kv['tcode_appkey'] = param('tcode_appkey');
	$kv['tcode_user_login_on'] = param('tcode_user_login_on');
	$kv['tcode_user_create_on'] = param('tcode_user_create_on');
	$kv['tcode_mail_on'] = param('tcode_mail_on');
	$kv['tcode_user_findpw_on'] = param('tcode_user_findpw_on');
	$kv['tcode_thread_create_on'] = param('tcode_thread_create_on');
	$kv['tcode_post_create_on'] = param('tcode_post_create_on');
	$kv['tcode_edit_on'] = param('tcode_edit_on');
	
	// hook plugin_tcode_setting_kv_set_before.htm
	kv_set('tcode', $kv);
	
	// hook plugin_tcode_setting_post_end.htm
	message(0, '修改成功');
}
	
?>