<?php

!defined('DEBUG') AND exit('Forbidden');


$kv = kv_get('xn_tinymce');
if(!$kv) {
	$kv = array('qcloud_bucket'=>'', 'qcloud_secretId'=>'', 'qcloud_secretKey'=>'', 'qcloud_region'=>'', 'qcloud_cdnurl'=>'', 'qcloud_mimetype'=>'');
	kv_set('xn_tinymce', $kv);
}



?>