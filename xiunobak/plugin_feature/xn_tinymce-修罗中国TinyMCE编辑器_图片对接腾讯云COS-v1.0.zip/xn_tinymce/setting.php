<?php 
!defined('DEBUG') AND exit('Access Denied.');


if($method == 'GET') {
    $kv = kv_get('xn_tinymce');
	$input = array();
    //qcloud
    $input['qcloud_bucket'] = form_text('qcloud_bucket', $kv['qcloud_bucket']);
	$input['qcloud_secretId'] = form_text('qcloud_secretId', $kv['qcloud_secretId']);
	$input['qcloud_secretKey'] = form_text('qcloud_secretKey', $kv['qcloud_secretKey']);
	$input['qcloud_region'] = form_text('qcloud_region', $kv['qcloud_region']);
	$input['qcloud_cdnurl'] = form_text('qcloud_cdnurl', $kv['qcloud_cdnurl']);
	$input['qcloud_mimetype'] = form_text('qcloud_mimetype', $kv['qcloud_mimetype']);
    include _include(APP_PATH.'plugin/xn_tinymce/setting.htm');
} else {
    $tinymce = array();
    $tinymce['qcloud_bucket'] = param('qcloud_bucket');
    $tinymce['qcloud_secretId'] = param('qcloud_secretId');
    $tinymce['qcloud_secretKey'] = param('qcloud_secretKey');
    $tinymce['qcloud_region'] = param('qcloud_region');
    $tinymce['qcloud_cdnurl'] = param('qcloud_cdnurl');
    $tinymce['qcloud_mimetype'] = param('qcloud_mimetype');

    kv_set('xn_tinymce', $tinymce);
    
    message(0, '修改成功');
    
}

?>
