<?php

if($method == 'GET'){
    message(-1,'非法请求');
}elseif($method == 'POST'){
  if (empty($uid)){
      message(-1,'非法请求');
    }
$res=array(
    'success'=>'',
    'message'=>'',
    'url'=>'',
);
include_once(APP_PATH.'plugin/xn_tinymce/upload/vendor/autoload.php');
$config = kv_get('xn_tinymce');
$name='tinymce-image-file';
$file=$_FILES[$name];

file_put_contents(APP_PATH.'/plugin/xn_tinymce/upload/debug.txt', 'file:'.json_encode($file),FILE_APPEND);
$file['ext']=pathinfo($file['name'], PATHINFO_EXTENSION);
$ext = strtolower($file['ext']);
$mimetype=explode(",", str_replace(array("，",';','；'," "),",",$config['qcloud_mimetype']));
if(in_array($ext, $mimetype) == false) {
    $res['success']=0;
    $res['message']="文件非法，禁止上传！";
    $res['url']='https://sn.pic.cdn.lkxin.cn/2022/05/29/629327ba80a9d.webp';
    echo json_encode($res);
}else {
    $key =date('Y').date('m').'/'.md5(date('YmdHis') . rand(0, 9)) . '.' . $ext;
    $secretId = $config['qcloud_secretId'];
    $secretKey = $config['qcloud_secretKey'];
    $region = $config['qcloud_region'];
    $bucket = $config['qcloud_bucket'];
    $domain = $config['qcloud_cdnurl'];
    $picfile = $file['tmp_name'];
    $cosClient = new Qcloud\Cos\Client(
    array(
        'region' => $region,
        'schema' => 'https', //协议头部，默认为http
        'credentials'=> array(
            'secretId'  => $secretId ,
            'secretKey' => $secretKey)));
try {
    $result = $cosClient->upload(
        $bucket = $config['qcloud_bucket'], 
        $key = 'img/'.$key,
        $body = fopen($picfile, 'rb')
    );
    // 请求成功
    $res['url']=$domain.'/'.$key;
    $res['success']=1;
    $res['message']="上传成功";
        echo json_encode($res);
} catch (Qcloud\Cos\Exception\ServiceResponseException $e) {
    // 请求失败
        $statusCode = $e->getStatusCode(); // 获取错误码
         $res['success']=0;
         $res['message']=$statucode;
        echo json_encode($res);
}
   
}

}
?>