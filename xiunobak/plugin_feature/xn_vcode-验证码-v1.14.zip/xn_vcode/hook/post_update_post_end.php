
unset($_SESSION['vcode']);

