
unset($_SESSION['vcode']);
unset($_SESSION['vcode_initpw_ok']);

