<?php

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

//thread新增投票帖字段
$sql = "ALTER TABLE {$tablepre}thread ADD COLUMN is_vote tinyint(3) NOT NULL default '0'";
db_exec($sql);

// 投票信息表
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}xn_vote (
  vote_id int(11) unsigned NOT NULL AUTO_INCREMENT,
  tid int(11) unsigned NOT NULL default '0',
  uid int(11) unsigned NOT NULL default '0', 
  create_time int(11) unsigned DEFAULT NULL,
  finish_time int(11) unsigned DEFAULT NULL,
  update_time int(11) unsigned DEFAULT NULL,
  type int(11) unsigned NOT NULL default '1',
  max int(11) unsigned NOT NULL default '1',
  subject varchar(255) COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (vote_id),
  KEY (create_time)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
$r = db_exec($sql);
$r === FALSE AND message(-1, '创建表1结构失败'); // 中断，安装失败。


// 投票选项表
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}xn_vote_info (
  oid int(11) unsigned NOT NULL AUTO_INCREMENT,
  vote_id int(11) unsigned NOT NULL default '0',
  tid int(11) unsigned NOT NULL default '0', 
  content varchar(255) COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (oid),
  KEY (vote_id)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
$r = db_exec($sql);
$r === FALSE AND message(-1, '创建表2结构失败'); // 中断，安装失败。



// 投票结果表
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}xn_vote_detail (
  id int(11) unsigned NOT NULL AUTO_INCREMENT,
  vote_id int(11) unsigned NOT NULL default '0',
  oid int(11) unsigned NOT NULL default '0', 
  tid int(11) unsigned DEFAULT NULL,
  uid int(11) unsigned DEFAULT NULL,
  vote_time int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (id),
  KEY (vote_time)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
$r = db_exec($sql);
$r === FALSE AND message(-1, '创建表3结构失败'); // 中断，安装失败。

// 添加插件配置
$xn_vote = array(
  "vote_open" => 0,
);
kv_set('xn_vote', $xn_vote); 



?>