<?php

function xn_vote_create($arr){
	$r = db_insert('xn_vote',$arr);
	return $r;
	//新建投票主题
}

function xn_vote_info_create($arr){
	$r = db_insert('xn_vote_info',$arr);
	return $r;
	//新建投票选项
}

function xn_vote_action($arr){
	//用户投票
	db_insert('xn_vote_detail',$arr);
}

function vote_read($tid){
	//通过主题id从xn_vote读取相关投票信息
	$r = db_find_one('xn_vote', array('tid'=>$tid));
	return $r;
}

function vote_info_read($tid){
	//通过主题id和选项从xn_vote_info读取投票相关信息
	$r = db_find('xn_vote_info',array('tid'=>$tid), array(), 1, 100);
	return $r;
}



function xn_vote_option($tid){
	//通过主题id获取选项数
	$r=db_count('xn_vote_info',array('tid'=>$tid));
	return $r;
}


function xn_vote_option_count($tid,$oid){
	//通过主题id和选项id统计选项投票人数
	$r=db_count('xn_vote_detail',array('tid'=>$tid,'oid'=>$oid));
	return $r;
}


function xn_vote_check($uid,$tid){
	//检查是否投票
	if(empty($uid)) return array();
	$r = db_find_one('xn_vote_detail', array('uid'=>$uid,'tid'=>$tid));
	return $r;
}


function xn_vote_delete($tid){
	//删除投票
	$r=db_delete('xn_vote',array('tid'=>$tid)); //删除投票主题
	$r=db_delete('xn_vote_info',array('tid'=>$tid)); //删除投票选项
	$r=db_delete('xn_vote_detail',array('tid'=>$tid)); //删除投票结果
}

function xn_vote_time($second){
	$newtime = '';
	$d = floor($second / (3600*24));
	$h = floor(($second % (3600*24)) / 3600);
	$m = floor((($second % (3600*24)) % 3600) / 60);
	if ($d>'0') {
		if ($h == '0' && $m == '0') {
			$newtime= $d.'天';
		} else {
			$newtime= $d.'天'.$h.'小时'.$m.'分钟';
		}
	} else {
		if ($h!='0') {
			if ($m == '0') {
				$newtime= $h.'小时';
			} else {
				$newtime= $h.'小时'.$m.'分';
			}
		} else {
			$newtime= $m.'分';
		}
	}
	return $newtime;
}




