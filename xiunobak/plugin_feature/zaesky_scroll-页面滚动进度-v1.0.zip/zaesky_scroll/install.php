<?php
/*
	Xiuno BBS 4.0
*/
!defined('DEBUG') AND exit('Forbidden');

?>