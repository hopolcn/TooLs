<?php !defined('DEBUG') AND exit('Access Denied.');
$action = param(3);
// 初始化参数数据
$kv = kv_get('wechat_notice');
if (!$kv) {
    $kv = array(
        'template_id' => 'TUl8C_xUz9MDB5zMRSdaP65KpKVh_qYadP-KKeE5Eeo', 
        'reply_content_field' => 'first',
        'thread_title_field' => 'keyword1',
        'reply_nick_field' => 'keyword2',//端口
        'reply_time_field' => "keyword3",
              
    );
    kv_set('wechat_notice', $kv);
}
if(empty($action)) {
    if ($method == 'GET') {//设置页面
      	  
        include _include(APP_PATH . 'plugin/zz_iqismart_wechat/setting.htm');
    } elseif ($method == "POST") {
         
      	$template_id=param('template_id');
      	$reply_content_field=param('reply_content_field');
      $thread_title_field=param('thread_title_field');
      $reply_nick_field=param('reply_nick_field');
      $reply_time_field=param('reply_time_field');
      
      $kv = array();
      if(!$kv) {
        $kv = array(
            'template_id' => $template_id, 
            'reply_content_field' => $reply_content_field,
            'thread_title_field' => $thread_title_field,
            'reply_nick_field' => $reply_nick_field, 
            'reply_time_field' => $reply_time_field,

        );
        kv_cache_delete('wechat_notice');
        kv_set('wechat_notice', $kv);

      }

      message(0,'设置成功！');
       
    }
}

 
?>