# 路由
index.htm——展示链接和搜索
bbs.htm——展示讨论区（论坛）帖子（可被关闭）
sitemap.htm——展示链接分类和讨论区（论坛）分类
about_us.htm——关于我们（和经典的四个页面）
link-submit.htm——前台提交链接

# 帖子到链接的映射关系
帖子标题-链接名称
缩略图-链接图标
跳转地址-链接地址
帖子内容-链接介绍

相关推荐-随机抓取同分类里的帖子

# 设置
## 选择要成为链接分类的板块 link_category_selection
选择后，该板块可以通过link-category-ID访问
该板块下的连接可以通过link-view-ID访问，并会获得专属的连接展示页面

## 链接分类在主页中的排序 link_category_sort_order
数字越小越靠前，选择零则不在主页直接展示。推荐选择10的整数倍，便于后增加的分类快速定位到理想位置

## 主页的每个分类显示多少链接 links_per_category_on_homepage
推荐设置为4的整数倍。链接分类中展示的链接数量与网站设置中的一样。