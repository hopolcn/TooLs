<?php
/* 【开始】配置 */

$data = array(
  'panels' => [
    'welcome_about' => [
      'title' => '欢迎使用',
      'sections' => [
        'about_theme' => [
          'title' => '关于 ' . $PLUGIN_PROFILE['name'],
          'options' => [
            'cp_notice' => [
              'label' => '<b>重要提示</b>',
              'type' => 'label',
              'default' => '<strong class=text-danger>当心啦</strong>，<b>非官方的主题</b>可能包含恶意代码！会影响网站的安全性与速度，这可要小心了哦~<br>这个主题没有加密，所以你可以随便查看、学习和修改哦！但是<strong class=text-danger>别</strong>拿去加密和/或私自出售噢~'
            ],
            'authors' => [
              'label' => '作者',
              'type' => 'label',
              'default' => '<a href="https://xiunobbs.cn/user-thread-1109.htm">Tillreetree</a>'
            ],
            'credits' => [
              'label' => '鸣谢',
              'type' => 'label',
              'default' => implode('<br>', [
                'ThemeSelection - 外观设计',
                'Geticer - 制作协力',
                'NDNAV - 灵感提供、致敬',
                '七濑胡桃 - 精神支持',
              ])
            ],
            'thank_you_beta_testers' => [
              'label' => '感谢Beta测试者',
              'type' => 'label',
              'default' => implode('<br>', ['俊霖'])
            ],
            'thank_you_users' => [
              'label' => '感谢用户提供的建议',
              'type' => 'label',
              'default' => implode('<br>', [])
            ],
            'C0FFEE' => [
              'label' => $PLUGIN_PROFILE['nothing_to_see_here_move_along'][0],
              'description' => '你的支持是我<abbr title="字面意思">维护本主题的动力！</abbr>',
              'type' => 'label',
              'default' => '<img src="' . str_rot13($PLUGIN_PROFILE['nothing_to_see_here_move_along'][4] . ';' . $PLUGIN_PROFILE['nothing_to_see_here_move_along'][2]) . ',' . $PLUGIN_PROFILE['nothing_to_see_here_move_along'][1] . '" class="img-thumbnail img-fluid w-50 w-px-300 mx-auto" style="' . str_rot13($PLUGIN_PROFILE['nothing_to_see_here_move_along'][3]) . '" />'
            ]
          ],
        ],
      ],
    ],
    'global' => [
      'title' => '全局',
      'sections' => [
        'setting' => [
          'title' => '总开关',
          'options' => [
            'forum_functionality' => [
              'label' => '☆社区论坛功能',
              'type' => 'toggle',
              'default' => true,
              'description' => '选择“否”，将会完全隐藏论坛功能，适合只想做网站导航的用户。现有的论坛板块及帖子不会受到影响。<em>关闭后可以让网站符合“非交互式网站”的相关定义。</em>'
            ],
          ],
        ],
        'icon' => [
          'title' => '标志',
          '_cols' => 2,
          'options' => [
            'logo' => [
              'label' => '网站标志（Logo）',
              'type' => 'text',
              'default' => $conf['logo_pc_url'],
              'description' => '输入图标的网址'
            ],
            'favicon' => [
              'label' => '浏览器图标（Favicon）',
              'type' => 'text',
              'default' => $conf['logo_mobile_url'],
              'description' => '输入图标的网址'
            ],
          ],
        ],
      ]
    ],
    'ui' => [
      'title' => '外观',
      'sections' => [
        'global' => [
          'title' => '全局',
          'options' => [
            'semitransparent_card' => [
              'label' => '半透明卡片',
              'description' => '开启后，会让所有的“卡片”变成半透明且具有磨砂质感效果。适合搭配复杂的背景图片使用。',
              'type' => 'toggle',
              'default' => false,
            ],
            'bordered_card' => [
              'label' => '无阴影卡片',
              'description' => '开启后，会让所有的“卡片”的阴影消失，并增强边框，外观更“扁平”。按钮的阴影依旧存在。',
              'type' => 'toggle',
              'default' => false,
            ],
          ],
        ],
        'layout' => [
          'title' => '布局',
          'options' => [
            'link_list' => [
              'label' => '链接列表',
              'description' => '选择链接列表展现方式。',
              'type' => 'select',
              'default' => 'v1',
              'choices' => [
                'v1' => '宽松：一行四个链接，显示图标、名称、简介、查看次数、直链',
                'v2' => '紧凑：一行六个链接，显示图标、名称',
              ],
            ],
          ],
        ],
        'color' => [
          'title' => '颜色',
          '_cols' => 2,
          'options' => [
            'mode' => [
              'label' => '默认颜色模式',
              'description' => '如果用户没有设置颜色模式的话，就会使用这里选择的颜色模式（浅色/深色/自动）。',
              'type' => 'select',
              'default' => 'auto',
              'choices' => [
                'light' => '浅色（日间）',
                'dark' => '深色（夜间）',
                'auto' => '自动（根据时间切换）',
              ],
            ],
            'theme' => [
              'label' => '配色（主色调）',
              'description' => '',
              'type' => 'color',
              'default' => '#9055fd',
            ],

            'color_body_light' => [
              'label' => '文字颜色（浅色模式）',
              'description' => '',
              'type' => 'color',
              'default' => '#89868d',
            ],
            'color_body_dark' => [
              'label' => '文字颜色（深色模式）',
              'description' => '',
              'type' => 'color',
              'default' => '#9e9ab5',
            ],
            'color_body_bright_light' => [
              'label' => '着重文字颜色（浅色模式）',
              'description' => '如标题等文字。',
              'type' => 'color',
              'default' => '#544f5a',
            ],
            'color_body_bright_dark' => [
              'label' => '着重文字颜色（深色模式）',
              'description' => '如标题等文字。',
              'type' => 'color',
              'default' => '#cfcbe5',
            ],
            'color_card_light' => [
              'label' => '卡片背景颜色（浅色模式）',
              'description' => '',
              'type' => 'color',
              'default' => '#ffffff',
            ],
            'color_card_dark' => [
              'label' => '卡片背景颜色（深色模式）',
              'description' => '',
              'type' => 'color',
              'default' => '#2b2c40',
            ],
          ],
        ],
        'auto_dark_mode_config' => [
          'title' => '自动切换颜色模式',
          '_cols' => '2',
          'options' => [
            'begin_time' => [
              'label' => '何时切换到深色模式？',
              'description' => '建议设置到日落时间，或18:00之后',
              'type' => 'time',
              'default' => '18:00'
            ],
            'end_time' => [
              'label' => '何时切换到浅色模式？',
              'description' => '建议设置到日出时间，或08:00之前',
              'type' => 'time',
              'default' => '08:00'
            ],
          ],
        ],
        'background' => [
          'title' => '页面背景',
          'options' => [
            'style' => [
              'label' => '背景样式',
              'description' => '选择网站的背景样式。“【上半部分】纯色+图片”将只给页面的上半部分添加背景图片，页面主体使用纯色，让页面主体保持清爽。',
              'type' => 'select',
              'default' => 'default',
              'choices' => [
                'default' => '默认 *适合自动切换颜色模式*',
                'color_full' => '【整个页面】纯色',
                'image_full' => '【整个页面】纯色+图片',
                'image_part' => '【上半部分】纯色+图片',
              ],
            ],
            'color_light' => [
              'label' => '背景颜色-浅色模式',
              'type' => 'color',
              'default' => '#f5f5f9',
            ],
            'color_dark' => [
              'label' => '背景颜色-深色模式',
              'type' => 'color',
              'default' => '#28243d',
            ],
            'image' => array(
              'label' => '选择图片',
              'description' => '如果图片是透明的，则会透出背景颜色。',
              'type' => 'css_background_image',
              'default' => array( /* 默认值 */
                'background-url' => 'plugin/abs_theme_boundlessnav/view/img/4.jpg',
                'background-repeat' => 'no-repeat',
                'background-position' => 'center center',
                'background-size' => 'cover',
                'background-attachment' => 'fixed'
              ),
            ),
            'background_color_mode' => [
              'label' => '背景图片颜色模式',
              'description' => '当选用了背景图片时，背景图片的主色是深色还是浅色？影响搜索框的文字颜色，选择“深色”，则文字颜色使用浅色，反之亦然。',
              'type' => 'select',
              'default' => 'dark',
              'choices' => [
                'light' => '浅色',
                'dark' => '深色',
              ],
            ],
          ],

        ],
      ],
    ],
    'main' => [
      'title' => '【导航设置】',
      'sections' => [
        'nav_setting' => [
          'title' => '导航设置',
          'options' => [
            'allow_guest_submit' => [
              'label' => '☆允许用户提交链接？',
              'description' => '将会同步开关“提交链接”按钮与页面。用户提交后您可以<a href="' . url('plugin-setting-abs_theme_boundlessnav-links_pending') . '">在这里</a>审核链接。<em>关闭后可以让网站符合“非交互式网站”的相关定义。</em>',
              'type' => 'toggle',
              'default' => true
            ],
            'open_link_on_new_tab' => [
              'label' => '链接地址新窗口打开',
              'description' => '启用后，链接列表中的“直达”链接与链接详情页面中的“访问网站”按钮会打开新的页面。',
              'type' => 'toggle',
              'default' => false
            ],
            'link_category_selection' => [
              'label' => '选择要成为链接分类的板块',
              'description' => '选择后，该板块可以通过link-category-(ID).htm访问，并且该板块下的连接可以通过link-view-(ID).htm访问，并会获得专属的链接展示页面。',
              'type' => 'forumlist_multi',
              'default' => [1],
            ],
            'link_category_sort_order' => [
              'label' => '链接分类在主页中的排序',
              'description' => '数字越小越靠前。推荐选择10的整数倍，便于后增加的分类快速定位到理想位置',
              'type' => 'number_per_forum',
              'min' => 1,
              'max' => 10000,
              'step' => 1,
              'default' => [1 => 10, 2 => 20, 3 => 30, 4 => 40, 5 => 50, 6 => 60, 7 => 70, 8 => 80, 9 => 90, 10 => 100,],
              /* 提示：$bn_link_category = array_intersect_key($bn_link_category_order,$bn_link_category_selection);
              asort($bn_link_category);
              $bn_link_category = array_flip($bn_link_category);
              $bn_link_category = array_values($bn_link_category);
              var_dump($bn_link_category); 
              foreach($bn_link_category as ...) {...}
              */
            ],
            'links_per_category_on_homepage' => [
              'label' => '主页的每个分类显示多少链接',
              'description' => '链接分类中展示的链接数量与<a href="' . url('forum-list') . '">网站设置</a>中的一样。',
              'type' => 'number',
              'default' => 8,
              'min' => 1,
              'max' => 200,
              'step' => 1
            ],
          ],

        ],
        'search_engine_setting' => [
          'title' => '搜索框设置',
          'options' => [
            'show' => [
              'label' => '☆显示搜索框？',
              'description' => '<em>关闭后可以让网站符合“非交互式网站”的相关定义。</em>',
              'type' => 'toggle',
              'default' => true
            ],
            'search_input_placeholder' => [
              'label' => '搜索框占位文字',
              'description' => '当用户还没输入文字时显示的内容',
              'type' => 'text',
              'default' => '搜一搜'
            ],
            'search_engines' => [
              'label' => '搜索引擎配置',
              'description' => '',
              'type' => 'matrix_text',
              'columns_label' => ['所属分类名', 'ID', 'Get请求地址', '显示名称'],
              'default' => [
                ["常用", "wuzhui", "https://www.wuzhuiso.com/s?q=", "无追搜索"],
                ["常用", "baidu", "https://www.baidu.com/s?wd=", "百度"],
                ["常用", "google", "https://www.google.com/search?q=", "Google"],
                ["常用", "so360", "https://www.so.com/s?q=", "360"],
                ["常用", "sogou", "https://www.sogou.com/web?query=", "搜狗"],
                ["常用", "bing", "https://cn.bing.com/search?q=", "必应"],
                ["常用", "shenma", "https://yz.m.sm.cn/s?q=", "神马"],
                ["工具", "rank", "http://rank.chinaz.com/all/", "权重查询"],
                ["工具", "friendlink", "http://link.chinaz.com/", "友链检测"],
                ["工具", "icp", "https://icp.aizhan.com/", "备案查询"],
                ["工具", "ping", "http://ping.chinaz.com/", "PING检测"],
                ["工具", "deadlink", "http://tool.chinaz.com/Links/?DAddress=", "死链检测"],
                ["社区", "zhihu", "https://www.zhihu.com/search?type=content&q=", "知乎"],
                ["社区", "weixin", "http://weixin.sogou.com/weixin?type=2&query=", "微信"],
                ["社区", "weibo", "https://s.weibo.com/weibo?q=", "微博"],
                ["社区", "douban", "https://www.douban.com/search?q=", "豆瓣"],
                ["社区", "stackoverflow", "https://stackoverflow.com/search?q=", "Stack Overflow"],
                ["社区", "segmentfault", "https://segmentfault.com/search?type=all&q=", "Segment Fault"],
                ["社区", "bilibili", "https://search.bilibili.com/all?keyword=", "BiliBili"],
                ["灵感", "huaban", "https://www.huaban.com/search/?q=", "花瓣"],
                ["灵感", "dribbble", "https://dribbble.com/search/", "Dribbble"],
                ["灵感", "behance", "https://www.behance.net/search?search=", "Behance"],
                ["灵感", "zcool", "http://www.zcool.com.cn/search/content?&word=", "站酷"],
                ["灵感", "unsplash", "https://unsplash.com/search?query=", "Unsplash"],
                ["灵感", "pixabay", "https://pixabay.com/search/?q=", "Pixabay"],
                ["灵感", "giphy", "https://giphy.com/search/?q=", "Giphy"],
                ["开发", "GitHub", "https://github.com/", "GitHub"],
                ["开发", "gitee", "https://gitee.com/", "码云"],
                ["开发", "gitlab", "https://gitlab.com/search?search=", "GitLab"],
                ["开发", "jsfiddle", "https://jsfiddle.net/api/search/?q=", "JSFiddle"],
                ["开发", "caniuse", "https://caniuse.com/?search=", "Can I Use"],
                ["开发", "codepen", "https://codepen.io/search/pens?q=", "CodePen"],
                ["开发", "devdocs", "https://devdocs.io/#q=", "DevDocs"],
                ["学术", "cnk", "https://www.cnki.net/search?keyword=", "中国知网"],
                ["学术", "vip", "https://www.cqvip.com/search-results.html?&searchText=", "维普资讯"],
                ["学术", "wanf", "http://www.wanfangdata.com.cn/search/index.html?keyword=", "万方数据"],
                ["其他", "Wolf", "http://www.wolframalpha.com/input/?i=", "WolframAlpha"],
                ["其他", "Wiki", "http://zh.wikipedia.org/w/index.php?i=", "Wikipedia"],
                ["其他", "Linguee", "https://cn.linguee.com/?query=", "Linguee"],
                ["其他", "Pai", "http://zh.numberempire.com/primenumbers.php?number=", "素数发生器"],
                ["其他", "EmojiAll", "https://www.emojiall.com/zh-hans/search_results?keywords=", "EmojiAll"],
                ["其他", "book", "https://www.amazon.com/s?k=", "Amazon书籍搜索"],
                ["其他", "coursera", "https://www.coursera.org/search?query=", "Coursera"],
              ],
            ],
            'explained' => [
              'label' => '搜索引擎配置详解',
              'type' => 'label',
              'default' => '点击减号按钮会立即去掉该项，如果你还未保存设置的话，刷新页面可撤销。<h4>如何添加新的搜索引擎</h4><p>要添加新的搜索引擎，只需点击加号按钮，然后输入以下信息：</p><h5>所属分类名</h5><p>所属分类名会在搜索框的上半部分显示。<i>例如</i>，你可以将搜索引擎分类为“<samp>常用</samp>”、“学术”、“图片”等，填写<b>相同的分类名称</b>会让搜索引擎<b>出现在相同的分类中</b>这有助于用户更快地找到他们想要使用的搜索引擎。如果在前台页面中出现了重复的分类名称，请务必检查此项中是否有空格等不可见字符。</p><h5>ID</h5><p>ID可为这个搜索引擎的缩写，但<b>必须保证唯一</b>。<i>例如</i>，对于“搜狗”搜索引擎，你可以将其ID设置为“<samp>sogou</samp>”。</p><h5>GET请求的地址前缀</h5><p>地址前缀<b>会与输入的文字连接后形成完整的地址</b>。<i>例如</i>，对于“搜狗”搜索引擎，地址前缀可以设置为“<samp>https://www.sogou.com/web?query=</samp>”。当用户输入搜索关键词时，程序会将关键词拼接到这个地址前缀后，形成完整的搜索地址，如“<samp>https://www.sogou.com/web?query=hello</samp>”。</p><h5>显示名称</h5><p>顾名思义。显示名称会在搜索框的下半部分显示，方便用户识别和选择。<i>例如</i>，对于“搜狗”搜索引擎，显示名称可以设置为“<samp>搜狗</samp>”。</p>',
            ],
          ],
        ],
        'widget_setting' => [
          'title' => '【小工具】设置',
          'options' => [
            'display_on_homepage' => [
              'label' => '在主页显示以下四个小工具？',
              'type' => 'toggle',
              'default' => true
            ],
          ],
        ],
        'widget_newlinks_setting' => [
          'title' => '【小工具】最新链接设置',
          'options' => [
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '最新'
            ],
            'icon' => [
              'label' => '图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'la la-link'
            ],
            'icon_color' => [
              'label' => '图标颜色',
              'type' => 'select',
              'default' => 'success',
              'choices' => [
                'primary' => '主题主色调',
                'secondary' => '灰色',
                'info' => '青蓝色',
                'success' => '绿色',
                'warning' => '橙黄色',
                'danger' => '红色',
              ],
            ],

          ],
        ],
        'widget_weather_setting' => [
          'title' => '【小工具】天气设置',
          'options' => [
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '天气'
            ],
            'icon' => [
              'label' => '图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'la la-cloud'
            ],
            'icon_color' => [
              'label' => '图标颜色',
              'type' => 'select',
              'default' => 'info',
              'choices' => [
                'primary' => '主题主色调',
                'secondary' => '灰色',
                'info' => '青蓝色',
                'success' => '绿色',
                'warning' => '橙黄色',
                'danger' => '红色',
              ],
            ],

          ],
        ],
        'widget_tool_setting' => [
          'title' => '【小工具】工具设置',
          'options' => [
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '工具'
            ],
            'icon' => [
              'label' => '图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'la la-wrench'
            ],
            'icon_color' => [
              'label' => '图标颜色',
              'type' => 'select',
              'default' => 'primary',
              'choices' => [
                'primary' => '主题主色调',
                'secondary' => '灰色',
                'info' => '青蓝色',
                'success' => '绿色',
                'warning' => '橙黄色',
                'danger' => '红色',
              ],
            ],
            'tools' => [
              'label' => '工具列表配置',
              'description' => '',
              'type' => 'matrix_text',
              'columns_label' => ['图标', '颜色', '地址', '显示名称'],
              'default' => [
                ['la la-calendar', 'secondary', '#', 'Calendar'],
                ['la la-copy', 'secondary', '#', 'Invoice'],
                ['la la-user', 'secondary', '#', 'User'],
                ['la la-users', 'secondary', '#', 'Role'],
                ['la la-pie-chart', 'secondary', '#', 'Dashboard'],
                ['la la-cog', 'secondary', '#', 'Setting'],
              ],
            ],
            'explained' => [
              'label' => '工具列表配置详解',
              'type' => 'label',
              'default' => '点击减号按钮会立即去掉该项，如果你还未保存设置的话，刷新页面可撤销。<h4>如何添加新的工具</h4><p>要添加新的工具擎，只需点击加号按钮，然后输入以下信息：</p><h5>图标</h5><p>输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的**标绿部**）。</p><h5>地址</h5><p>点击后会到达哪里。</p><h5>颜色</h5><p>支持以下值：</p><ul><li><code>primary</code> 主题主色调</li><li><code>secondary</code> 灰色</li><li><code>info</code> 青蓝色</li><li><code>success</code> 绿色</li><li><code>warning</code> 橙黄色</li><li><code>danger</code> 红色</li></ul><h5>显示名称</h5><p>顾名思义。推荐设置为小于等于6个汉字，或小于等于10英文字母的单词。</p>',
            ],
          ],
        ],
        'widget_carousel_setting' => [
          'title' => '【小工具】推荐轮播图设置',
          'options' => [
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '推荐'
            ],
            'icon' => [
              'label' => '图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'la la-images'
            ],
            'icon_color' => [
              'label' => '图标颜色',
              'type' => 'select',
              'default' => 'warning',
              'choices' => [
                'primary' => '主题主色调',
                'secondary' => '灰色',
                'info' => '青蓝色',
                'success' => '绿色',
                'warning' => '橙黄色',
                'danger' => '红色',
              ],
            ],
            'slides' => [
              'label' => '轮播图配置',
              'description' => '',
              'type' => 'matrix_text',
              'columns_label' => ['图片地址', '地址', '文字内容'],
              'default' => [
                ['./plugin/abs_theme_boundlessnav/view/img/1.jpg', 'https://xiunobbs.cn/thread-5724.htm', '欢迎使用净界导航主题'],
                ['./plugin/abs_theme_boundlessnav/view/img/2.jpg', 'https://xiunobbs.cn/user-thread-1109.htm', '作者：Tillreetree'],
                ['./plugin/abs_theme_boundlessnav/view/img/3.jpg', 'https://xiunobbs.cn/thread-3888.htm', '也来看看更加优秀的Stately主题吧！'],
              ],
            ],
            'explained' => [
              'label' => '工具列表配置详解',
              'type' => 'label',
              'default' => '点击减号按钮会立即去掉该项，如果你还未保存设置的话，刷新页面可撤销。',
            ],
          ],
        ],
      ],
    ],
    'monetize' => [
      'title' => '收益化',
      'sections' => [
        'ad' => [
          'title' => '广告位设置',
          'options' => [
            'header' => [
              'label' => '全局页眉',
              'type' => 'textarea_html',
              'default' => '',
              'description' => '可输入HTML。'
            ], // bn_ad__header.htm

            'footer' => [
              'label' => '全局页脚',
              'type' => 'textarea_html',
              'default' => '',
              'description' => '可输入HTML。'
            ], // bn_ad_footer.htm

            'homepage_link_list_end' => [
              'label' => '主页“链接列表”之后，“社区资讯”之前的位置；',
              'type' => 'textarea_html',
              'default' => '',
              'description' => '可输入HTML。'
            ], // bn_ad_homepage_link_list_end.htm

            'link_single_before_recommended' => [
              'label' => '链接详情页，“相关链接”之前的位置；',
              'type' => 'textarea_html',
              'default' => '',
              'description' => '可输入HTML。'
            ], // bn_ad_link_single_before_recommended.htm

            'link_single_widget' => [
              'label' => '链接详情页右侧',
              'type' => 'textarea_html',
              'default' => '',
              'description' => '可输入HTML。'
            ], // bn_ad_link_single_widget.htm

          ]
        ]
      ]
    ],
    'custom_content' => [
      'title' => '自定义内容',
      'sections' => [
        'global' => [
          'title' => '全局',
          '_cols' => '2',
          'options' => [
            'footer_left_content' => [
              'label' => '页脚左侧文字',
              'description' => '可使用HTML',
              'type' => 'textarea_html',
              'default' => '&copy; ' . date('Y ') . 'Designed by <a href=\'https://themeselection.com\' target=\'_blank\' class=\'footer-link\'>ThemeSelection</a>'
            ],
            'footer_right_content' => [
              'label' => '页脚右侧文字',
              'description' => '可使用HTML',
              'type' => 'textarea_html',
              'default' => '<ul class="list-inline my-1 d-inline-block"><li class="list-inline-item">' . implode('</li><li class="list-inline-item">', [
                '<a href="' . url('about_us') . '">' . '关于本站</a>',
                '<a href="' . url('terms') . '">' . '网站规则</a>',
                '<a href="' . url('privacy') . '">' . '隐私政策</a>',
                '<a href="' . url('contact_us') . '">' . '联系我们</a>',
              ]) . '</li></ul>' . ' 自豪地采用Xiuno BBS'
            ],
          ],
        ],
        'link_single' => [
          'title' => '链接详情页面',
          'options' => [
            'disclaimer' => [
              'label' => '免责声明',
              'description' => '可使用HTML',
              'type' => 'textarea_html',
              'default' => '本站大部分下载资源收集于网络，只做学习和交流使用，版权归原作者所有。若您需要使用非免费的软件或服务，请购买正版授权并合法使用。本站发布的内容若侵犯到您的权益，请联系站长删除，我们将及时处理。'
            ],
          ],
        ]
      ],
    ],
    'page' => [
      'title' => '自定义内容—页面',
      'sections' => [
        'submit' => [
          'title' => '提交网址',
          'description' => '<a href="../' . url('link-submit') . '">进入页面</a>',
          'options' => [
            'title' => [
              'label' => '页面标题',
              'type' => 'text',
              'default' => '提交网址',
            ],
            'content' => [
              'label' => '页面内容',
              'type' => 'html',
              'default' => '<p><b>按照下面表格如实填写网站信息并提交，等待审核完毕，本站将为您创建一个页面并发布你的站点。</b></p><h3>申请收录条件：</h3><p>1、贵站必须是正规网站，不能含有不良内容的网站</p><p>2、本站不收录在正常情况下无法正常连接或打开时间太长的网站。</p><p>3、本站会不定期检查所有网站，如发现收录的网站违背我们的收录标准，我们将删除链接。</p><blockquote class="blockquote"><ul><li>本站名称：' . $conf['sitename'] . '</li><li>本站链接：' . $_SERVER['HTTP_HOST'] . '</li><li>本站描述：' . $conf['sitebrief'] . '</li><li>本站图标：' . $conf['logo_mobile_url'] . '</li></ul></blockquote>',
            ],
          ],
        ],
        'about' => [
          'title' => '关于本站',
          'description' => '<a href="../' . url('about_us') . '">进入页面</a>；因程序限制，暂无法实现“任意页面创建、编辑、删除”。若不希望某个页面对外展示，仅需清空内容并去掉链接即可。',
          'options' => [
            'icon' => [
              'label' => '页面图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'las la-edit',
            ],
            'title' => [
              'label' => '页面标题',
              'type' => 'text',
              'default' => '关于本站',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'text',
              'default' => 'About Us',
            ],
            'content' => [
              'label' => '页面内容',
              'type' => 'html',
              'default' => '<p>正在施工……若您看到了这段话，请联系站长补充。</p>',
            ],
          ],
        ],
        'terms' => [
          'title' => '网站规则/使用协议/版权声明',
          'description' => '<a href="../' . url('terms') . '">进入页面</a>',
          'options' => [
            'icon' => [
              'label' => '页面图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'las la-edit',
            ],
            'title' => [
              'label' => '页面标题',
              'type' => 'text',
              'default' => '网站规则',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'text',
              'default' => 'Site Rules',
            ],
            'content' => [
              'label' => '页面内容',
              'type' => 'html',
              'default' => '<p>本页面介绍了本站的网站规则/使用协议/版权声明。若您看到了这段话，请联系站长补充。</p>',
            ],
          ],
        ],
        'privacy' => [
          'title' => '隐私政策',
          'description' => '<a href="../' . url('privacy') . '">进入页面</a>',
          'options' => [
            'icon' => [
              'label' => '页面图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'las la-edit',
            ],
            'title' => [
              'label' => '页面标题',
              'type' => 'text',
              'default' => '隐私政策',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'text',
              'default' => 'Privacy Policy',
            ],
            'content' => [
              'label' => '页面内容',
              'type' => 'html',
              'default' => '<p>本页面介绍本站的隐私政策。若您看到了这段话，请联系站长补充。</p>',
            ],
          ],
        ],
        'contact' => [
          'title' => '联系我们',
          'description' => '<a href="../' . url('contact_us') . '">进入页面</a>',
          'options' => [
            'icon' => [
              'label' => '页面图标',
              'description' => '输入 <a href="https://igoutu.cn/line-awesome">Line Awesome</a> 图标名称（中的<span class="text-success">标绿部分</span>），留空则不显示图标',
              'type' => 'text',
              'default' => 'las la-edit',
            ],
            'title' => [
              'label' => '页面标题',
              'type' => 'text',
              'default' => '联系我们',
            ],
            'subtitle' => [
              'label' => '页面副标题',
              'type' => 'text',
              'default' => 'Contact Us',
            ],
            'content' => [
              'label' => '页面内容',
              'type' => 'html',
              'default' => '<h3>网站问题、举报投诉、建议意见</h3><ul><li>Email：</li><li>QQ群：</li></ul><p>或者到建议以及意见反馈专区发帖。</p><h3>商务合作</h3><ul><li>联系人：</li><li>Email：</li><li>QQ：</li></ul><p>若您看到了这段话，请联系站长补充。</p>',
            ],
          ],
        ],
      ],
    ],
  ],
  'kumquat_config' => [ /* 金桔框架——框架设置 */
    'allow_delete_plugin_settings' => true, /* 允许删除插件设置 */
    'allow_reset_settings' => false, /* 允许重置插件设置 */
    'show_all_vars_table' => false, /* 显示“全部变量”框，只在调试模式显示 */
  ],
  'kumquat_flag' => [ /* 金桔框架——FLAG；保存在插件设置中，除非有必要，否则勿动 */
    'delete_plugin_settings' => false, /* 删除插件设置，若为true则会在卸载时删除插件设置 */
    'reset_settings' => false, /* 重置插件设置，若为true则重置 */
  ],
);

/* 【结束】配置 */