<?php exit;

$menus_menu_bn = array(
	'bn_links_pending' => array(
		'url' => url('plugin-setting-abs_theme_boundlessnav-links_pending'),
		'text' => '待审链接',
		'icon' => 'icon-link',
	)
);
$menu += $menus_menu_bn;