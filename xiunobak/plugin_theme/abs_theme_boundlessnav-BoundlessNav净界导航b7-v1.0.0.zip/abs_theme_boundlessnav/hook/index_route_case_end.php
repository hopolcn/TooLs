case'link':
include _include(APP_PATH.'plugin/abs_theme_boundlessnav/route/link.php');
break;

case'about_us':
include _include(APP_PATH.'plugin/abs_theme_boundlessnav/route/about.php');
break;

case'terms':
include _include(APP_PATH.'plugin/abs_theme_boundlessnav/route/terms.php');
break;

case'privacy':
include _include(APP_PATH.'plugin/abs_theme_boundlessnav/route/privacy.php');
break;

case'contact_us':
include _include(APP_PATH.'plugin/abs_theme_boundlessnav/route/contact.php');
break;