
/**
 * 读取帖子内容（缓存版）
 * 真正利用了缓存功能，性能更上一层楼
 * @param int $pid
 * @return array
 */
function post_read_cache_bn($pid) {
	$r = cache_get('post_' . $pid);
    if(is_null($r)) {
        $r = post_read_cache($pid);
        cache_set('post_' . $pid, $r, 3600);
    }
    return $r;
}

