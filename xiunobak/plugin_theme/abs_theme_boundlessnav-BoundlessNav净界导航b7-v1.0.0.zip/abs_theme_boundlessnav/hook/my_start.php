

if(!isset($abs_theme_boundlessnav_setting)) {
	$abs_theme_boundlessnav_setting = ( !is_null(setting_get('abs_theme_boundlessnav_setting')) ? setting_get('abs_theme_boundlessnav_setting') : kv_get('setting')["abs_theme_boundlessnav_setting"] );
}

if(!$abs_theme_boundlessnav_setting['global']['setting']['forum_functionality']) {
    if(isset($gid) && intval($gid) !== 1) {
        message(message(-1, lang('user_group_insufficient_privilege')));
    }
}

