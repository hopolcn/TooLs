<?php
!defined('DEBUG') and exit('Access Denied.');


$action = param(1, '');

// 生成四位数字验证码
function generate_ketchup() {
	$ketchup = '';
	for ($i = 0; $i < 4; $i++) {
		$ketchup .= rand(0, 9);
	}
	return $ketchup;
}

function generate_arithmetic_expression() {
	// 生成两个随机数
	$num1 = rand(1, 16000);
	$num2 = rand(1, 16000);
	$answer = 0;
	$operator = rand(1, 4);
	switch ($operator) {
	  case 1:
		$operator = "+";
		break;
	  case 2:
		$operator = "-";
		break;
	  case 3:
		$operator = "×";
		break;
	  case 4:
		$operator = "÷";
		break;
	}
  
	switch ($operator) {
	  case "+":
		$answer = $num1 + $num2;
		break;
	  case "-":
		$answer = $num1 - $num2;
		break;
	  case "×":
		$answer = $num1 * $num2;
		break;
	  case "÷":
		$answer = $num1 / $num2;
		break;
	}

	return array(
		'question' => "$num1 $operator $num2 =", 
		'answer' => $answer);
  }

// 检查输入的验证码是否与存储在会话中的验证码匹配
function check_ketchup($input_ketchup) {
	$session_ketchup = $_SESSION['ketchup'];
	if (intval($input_ketchup) === intval($session_ketchup)) {
		unset($_SESSION['ketchup']);
		return true;
	} else {
		return false;
	}
}

function toChinaseNumber($num) {
	$char = array('零', '一', '二', '三', '四', '五', '六', '七', '八', '九');
	$dw = array("", '十', '百', '千', '万', '亿', '兆',);
	$result = "";
	$proZero = false;
	for ($i = 0; $i < strlen($num); $i++) {
		if ($i > 0) {
			$temp = (int)(($num % pow(10, $i + 1)) / pow(10, $i));
		} else {
			$temp = (int)($num % pow(10, 1));
		}
		$temp = abs($temp);
		if ($proZero == true && $temp == 0) {
			continue;
		}

		$proZero = boolval($temp == 0);

		if ($proZero) {
			if (empty($result)) {
				continue;
			}
			$result = $char[$temp] . $result;
		} else {
			$result = $char[$temp] . $dw[$i] . $result;
		}
	}
	$result = str_replace('一十', '十', $result);
	return $result;
}

if (!isset($abs_theme_boundlessnav_setting)) {
	$abs_theme_boundlessnav_setting = (!is_null(setting_get('abs_theme_boundlessnav_setting')) ? setting_get('abs_theme_boundlessnav_setting') : kv_get('setting')["abs_theme_boundlessnav_setting"]);
}

switch ($action) {
	case 'category':
		if ($method !== "POST") {
			/* 与forum.php类似 */

			// hook forum_start.php
			$fid = param(2, 0);
			$page = param(3, 1);
			$orderby = param('orderby');
			$extra = array(); // 给插件预留

			$active = 'default';
			!in_array($orderby, array('tid', 'lastpid')) and $orderby = 'lastpid';
			$extra['orderby'] = $orderby;

			$forum = forum_read($fid);
			if (empty($forum)) {
				message(3, lang('forum_not_exists'));
			}
			forum_access_user($fid, $gid, 'allowread') or message(-1, lang('insufficient_visit_forum_privilege'));
			$pagesize = $conf['pagesize'];

			if (!in_array(strval($fid), $abs_theme_boundlessnav_setting['main']['nav_setting']['link_category_selection'])) {
				header('Location: ' . url('forum-' . $fid));
			}

			// hook forum_top_list_before.php

			$toplist = $page == 1 ? thread_top_find($fid) : array();

			// 从默认的地方读取主题列表
			$thread_list_from_default = 1;

			// hook forum_thread_list_before.php

			if ($thread_list_from_default) {
				$pagination = pagination(url("link-category-$fid-{page}"), $forum['threads'], $page, $pagesize);
				$threadlist = thread_find_by_fid($fid, $page, $pagesize, $orderby);
			}

			$header['title'] = $forum['seo_title'] ? $forum['seo_title'] : $forum['name'] . '-' . $conf['sitename'];
			$header['mobile_title'] = $forum['name'];
			$header['mobile_link'] = url("forum-$fid");
			$header['keywords'] = '';
			$header['description'] = $forum['brief'];

			$_SESSION['fid'] = $fid;

			// hook forum_end.php

			$bn_single_category_links = $threadlist;

			include _include(APP_PATH . 'plugin/abs_theme_boundlessnav/view/htm/bn_link_page_category.htm');

			unset($bn_single_category_links);
		} else {
			message(0, 'Bad Request');
		}

		break;
	case 'view':
		if ($method !== "POST") {

			/* 与thread.php类似 */

			$tid = param(2, 0);
			$page = 1;
			$pagesize = 1;
			// hook thread_info_start.php

			$thread = thread_read($tid);
			empty($thread) and message(-1, lang('thread_not_exists'));

			$fid = $thread['fid'];
			$forum = forum_read($fid);
			empty($forum) and message(3, lang('forum_not_exists'));

			if (!in_array(strval($fid), $abs_theme_boundlessnav_setting['main']['nav_setting']['link_category_selection'])) {
				header('Location: ' . url('thread-' . $tid));
			}

			$postlist = post_find_by_tid($tid, $page, $pagesize);
			empty($postlist) and message(4, lang('post_not_exists'));


			empty($postlist[$thread['firstpid']]) and message(-1, lang('data_malformation'));
			$first = $postlist[$thread['firstpid']];
			unset($postlist[$thread['firstpid']]);
			$attachlist = $imagelist = $filelist = array();

			// 如果是大站，可以用单独的点击服务，减少 db 压力
			// if request is huge, separate it from mysql server
			thread_inc_views($tid);


			$keywordurl = '';

			$allowpost = forum_access_user($fid, $gid, 'allowpost') ? 1 : 0;
			$allowupdate = forum_access_mod($fid, $gid, 'allowupdate') ? 1 : 0;
			$allowdelete = forum_access_mod($fid, $gid, 'allowdelete') ? 1 : 0;

			forum_access_user($fid, $gid, 'allowread') or message(-1, lang('user_group_insufficient_privilege'));


			$header['title'] = $thread['subject'] . '-' . $forum['name'] . '-' . $conf['sitename'];

			$header['mobile_title'] = $forum['name'];
			$header['mobile_link'] = url("forum-$fid");
			$header['keywords'] = '';
			$header['description'] = $thread['subject'];
			$_SESSION['fid'] = $fid;
			// hook thread_info_end.php

			include _include(APP_PATH . 'plugin/abs_theme_boundlessnav/view/htm/bn_link_page_single.htm');
		} else {
			message(0, 'Bad Request');
		}

		break;
	case 'submit':
		if ($abs_theme_boundlessnav_setting['main']['nav_setting']['allow_guest_submit']) {

			// 生成验证码并存储在会话中
			if (!isset($_SESSION['ketchup']) || !isset($_SESSION['ketchup_question'])) {
				$ketchup = generate_arithmetic_expression();
				$question = $ketchup['question'];
				$_SESSION['ketchup_question'] = $ketchup['question'];
				$_SESSION['ketchup'] = $ketchup['answer'];
			} else {
				$question = $_SESSION['ketchup_question'];
				$ketchup =  $_SESSION['ketchup'];
			}

			if ($method !== "POST") {
				include _include(APP_PATH . 'plugin/abs_theme_boundlessnav/view/htm/bn_link_page_submit.htm');
			} else {
				$websiteName = param('websiteName', '');
				$websiteLink = param('websiteLink', '');
				$websiteIcon = param('websiteIcon', '');
				$websiteKeywords = param('websiteKeywords', '');
				$websiteTagId = param('tagid', array(0));
				$websiteCategory = param('websiteCategory', 0);
				$websiteDescription = param('websiteDescription', '');
				$ketchup = param('ketchup', -1);

				// 使用 array_filter() 函数过滤数组中的0
				$websiteTagId = array_filter($websiteTagId, function($value) {
					return $value !== 0;
				});

				if ($websiteCategory === 0) {
					message(1,'请选择网站分类');
					die;
				}
				

				if (check_ketchup($ketchup)) {

					$tagcatemap = $forumlist[$websiteCategory]['tagcatemap'];
					foreach($forumlist[$websiteCategory]['tagcatemap'] as $cate) {
						$defaulttagid = $cate['defaulttagid'];
						$isforce = $cate['isforce'];
						$catetags = array_keys($cate['tagmap']);
						$intersect = array_intersect($catetags, $tagids); // 比较数组交集
						// 判断是否强制
						if($isforce) {
							if(empty($intersect)) {
								message(1, '请选择'.$cate['name']);
							}
						}
					}

					$links_pending_kv = kv_get('bn_links_pending');
					if (is_array($links_pending_kv)) {
						$links_pending_kv[] = [
							'time' => time(),
							'name' => $websiteName,
							'link' => $websiteLink,
							'icon' => $websiteIcon,
							'tag_id' => $websiteTagId,
							'keywords' => $websiteKeywords,
							'category' => $websiteCategory,
							'description' => $websiteDescription,
						];
						kv_set('bn_links_pending', $links_pending_kv);
						unset($_SESSION['ketchup'],$_SESSION['ketchup_question']);
						message(0, '您的链接已提交，请等待管理员审核。感谢您的贡献。');

					} else {
						message(-1, '发生内部错误｛' . __LINE__ . '｝');
					}
				} else {
					message(1, '验证码错误');
				}
			}
		} else {
			message(0, '提交链接通道暂时关闭，请联系管理员。');
		}

		break;
	default:
		message(0, 'Bad Request');
		break;
}
