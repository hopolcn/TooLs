<?php
!defined('DEBUG') AND exit('Access Denied.');

include _include(APP_PATH . 'plugin/abs_theme_boundlessnav/view/htm/privacy.htm');
