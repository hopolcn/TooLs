<?php
!defined('DEBUG') and exit('Access Denied.');
/* 【开始】金桔框架——常量定义 */
//如果网站在子目录下，这个很有必要
$BASE_URL = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$BASE_URL = empty($BASE_URL) ? '/' : '/' . trim($BASE_URL, '/') . '/';
$HTTP_TYPE = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
//网站的URL
define('WEBSITE_DIR', $_SERVER["HTTP_HOST"] . $BASE_URL);
//这个插件的文件夹URL
define('PLUGIN_DIR', 'plugin/' . param(2) . '/');
//这个插件的view文件夹URL
define('PLUGIN_VIEW_DIR', WEBSITE_DIR . PLUGIN_DIR . "view/");
//插件ID
define('PLUGIN_NAME', param(2));
//插件的conf.json文件
$plugin_profile_file = file_get_contents(APP_PATH . PLUGIN_DIR . 'conf.json');
//插件的conf
$PLUGIN_PROFILE = json_decode($plugin_profile_file, true);
//插件设置
$PLUGIN_SETTING = setting_get(PLUGIN_NAME . '_setting');
//金桔框架的位置
$kumquat_location = APP_PATH . PLUGIN_DIR . '/inc/';
//导入框架所需文件
include_once($kumquat_location . 'kumquat_utility.func.php');
include_once($kumquat_location . 'kumquat_core.func.php');
include_once($kumquat_location . 'kumquat_form.func.php');
include_once(APP_PATH . PLUGIN_DIR . 'conf.php');
//kumquat_init(PLUGIN_NAME);
/* 【结束】金桔框架——常量定义 */

if ($method == 'GET') {
	//var_dump($data);
	//var_dump($PLUGIN_SETTING);
	//var_dump(group_list_cache());
	//echo serialize($PLUGIN_SETTING);
	switch (param(3, '')) {
		case 'links_pending':
			$data = kv_get('bn_links_pending');
			if (!is_array($data)) {
				kv_set('bn_links_pending', []);
			}
			include _include(APP_PATH . PLUGIN_DIR . 'setting_links_pending.htm');
			break;
		default:
			include _include(APP_PATH . PLUGIN_DIR . 'setting.htm');
			break;
	}
} else {
	switch (param(3, '')) {
		case 'links_pending':
			$data = kv_get('bn_links_pending');
			$item = param('item', 0);
			switch (param('action', '')) {
				case 'pass_item':
					$fid = $data[$item]['category'];
					$subject = $data[$item]['name'];
					$url = $data[$item]['link'];
					$message = $data[$item]['description'];
					$keywords = $data[$item]['keywords'];
					$cover = $data[$item]['icon'];

					$forum = forum_read($fid);
					empty($forum) and message('fid', lang('forum_not_exists'));

					$r = forum_access_user($fid, $gid, 'allowthread');
					!$r and message(-1, lang('user_group_insufficient_privilege'));

					$doctype = 0;

					$thread = array(
						'fid' => $fid,
						'uid' => $uid,
						'sid' => $sid,
						'subject' => $subject,
						'message' => $message,
						'time' => $time,
						'longip' => $longip,
						'doctype' => $doctype,
					);

					$tid = thread_create($thread, $pid);
					$pid === FALSE and message(-1, lang('create_post_failed') . __LINE__);
					$tid === FALSE and message(-1, lang('create_thread_failed') . __LINE__);

					$thread_update_cover_url = thread_update($tid,['cover' => $cover]);
					$thread_update_cover_url === false and message(-1,'封面图地址更新失败' . __LINE__);
					$thread_update_redirect_url = thread_update($tid,['redirect_url' => $url]);
					$thread_update_redirect_url === false and message(-1,'链接地址更新失败' . __LINE__);
					$db_insert_nciaer_keydesc = db_insert('nciaer_keydesc', array('tid' => $tid, 'keywords' => $keywords, 'description' => $message));
					$db_insert_nciaer_keydesc === false and message(-1,'关键词与描述信息更新失败' . __LINE__);
					foreach($data[$item]['tag_id'] as $tagid) {
						$tagid AND tag_thread_create($tagid, $tid);
					}

					unset($data[$item]);
					kv_set('bn_links_pending', $data);

					message(0, '已接受申请，' . lang('create_thread_sucessfully'));

					break;
				case 'del_item':
					unset($data[$item]);
					kv_set('bn_links_pending', $data);
					message(0, '已拒绝申请');

					break;
				default:
					massage(0, 'Nothing to do');
					break;
			}
			break;
		default:
			($data['kumquat_config']['allow_reset_settings'] && param('kumquat_flag/reset_settings'))
				? setting_set(PLUGIN_NAME . '_setting', kumquat_reset_setting($data))
				: setting_set(PLUGIN_NAME . '_setting', kumquat_save_setting($data));
			message(0, lang('modify_successfully'));
			break;
	}
}
