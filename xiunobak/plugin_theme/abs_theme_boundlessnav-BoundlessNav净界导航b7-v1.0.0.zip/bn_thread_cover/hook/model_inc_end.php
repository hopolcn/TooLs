

include _include(APP_PATH.'plugin/bn_thread_cover/model/till_thread_cover.func.php');
