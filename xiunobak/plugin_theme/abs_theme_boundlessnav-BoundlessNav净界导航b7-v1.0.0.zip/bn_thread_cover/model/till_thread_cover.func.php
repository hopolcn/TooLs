<?php
function bn_thread_cover_remove($file){
    if(!empty($file)){
        return xn_unlink('./' . $file);
    }
}