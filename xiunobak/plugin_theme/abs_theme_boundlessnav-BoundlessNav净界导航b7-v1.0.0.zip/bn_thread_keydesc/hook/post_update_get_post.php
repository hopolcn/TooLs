<?php exit;

$rs = db_find_one('nciaer_keydesc', array('tid' => $tid));
if($rs) {
    $keywords = $rs['keywords'];
    $description = $rs['description'];
} else {
    $keywords = $description = '';
}
