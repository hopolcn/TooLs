<?php exit;

if($isfirst) {
    $keywords = param('keywords', '');
    $description = param('description', '');
    db_replace('nciaer_keydesc', array('tid' => $tid, 'keywords' => $keywords, 'description' => $description));
}