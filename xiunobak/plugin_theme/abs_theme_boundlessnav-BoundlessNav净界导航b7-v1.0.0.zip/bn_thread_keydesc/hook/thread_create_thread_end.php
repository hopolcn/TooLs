<?php exit;

$keywords = param('keywords', '');
$description = param('description', '');

if(!empty($keywords) || !empty($description)) {

    $rrr = db_insert('nciaer_keydesc', array('tid' => $tid, 'keywords' => $keywords, 'description' => $description));
    if (!$rrr) {
        message(-1, '关键字与描述保存失败｛' . __LINE__ . '｝');
    }

}
