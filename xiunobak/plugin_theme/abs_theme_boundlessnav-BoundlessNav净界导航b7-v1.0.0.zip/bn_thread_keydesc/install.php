<?php
!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}nciaer_keydesc (
	tid int(11) unsigned NOT NULL AUTO_INCREMENT,
	keywords varchar(250) NOT NULL DEFAULT '',			
	description varchar(350) NOT NULL DEFAULT '',			
	PRIMARY KEY (tid)
) ENGINE=MyISAM DEFAULT CHARSET=utf8";
$r = db_exec($sql);

