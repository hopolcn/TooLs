<?php 
function bn_keydesc_read($tid) {
    $rs = cache_get('bn_keydesc_t_' . $tid);
    if(is_null($rs)) {
        $rs = db_find_one('nciaer_keydesc', array('tid' => $tid));
        cache_set('bn_keydesc_t_' . $tid, $rs, 3600);
    }
    return $rs;
} 