if($isfirst) {
    $arr['redirect_url'] = param('redirect_url','');
	$arr AND thread_update($tid, $arr) === FALSE AND message(-1, lang('update_thread_failed'));
}