

thread_update($tid, ['redirect_url' => param('redirect_url','')]) === FALSE AND message(-1, lang('update_thread_failed'));

