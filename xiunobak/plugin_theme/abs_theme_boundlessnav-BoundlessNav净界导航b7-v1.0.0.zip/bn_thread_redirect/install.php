<?php
 
!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

db_exec("ALTER TABLE {$tablepre}thread ADD COLUMN redirect_url VARCHAR(8192) DEFAULT '';");

?>