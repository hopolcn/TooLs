<?php
/* 【开始】配置 */

$data = array(
  'panels' => array(
    'global' => array(
      'title' => '全局设置',
      'sections' => array(
        'settings' => array(
          'title' => '通用设置',
          'options' => array(
            'is_pace_shown' => array(
              'label' => '显示加载进度条',
              'type' => 'toggle',
              'default' => false,
              'description' => '勾选后，会在加载时显示一个加载进度条。加载完成后消失。'
            ),
            /*
            'is_thread_list_ajax' => array(
              'label' => '帖子列表无限滚动',
              'type' => 'toggle',
              'default' => false,
              'description' => '实验性功能'
            ),
            */
          ),
        )
      ),
    ),
    'homepage' => array(
      'title' => '主页设置',
      'sections' => array(
        'naslov' => array(
          'title' => '主页黑板报（公告）',
          'options' => array(
            'enable' => array(
              'label' => '启用？',
              'type' => 'toggle',
              'default' => true,
            ),
            'title' => array(
              'label' => '标题',
              'type' => 'text',
              'default' => (isset($conf) ? $conf['sitename'] : 'flano')
            ),
            'content' => array(
              'label' => '内容',
              'type' => 'textarea',
              'default' => (isset($conf) ? $conf['sitebrief'] : '欢迎来到我们的社区！请通知站长修改此处文字。')
            ),
          )
        ),
      ),
    ),
    'bbs' => array(
      'title' => '论坛设置',
      'sections' => array(
        'allforums' => array(
          'title' => '所有板块页面',
          'options' => array(
            'cols' => array(
              'label' => '论坛板块的列数',
              'description' => '在手机上固定为一列',
              'type' => 'radio',
              'default' => 4,
              'choices' => array(
                1 => '1列',
                2 => '2列',
                3 => '3列',
                4 => '4列',
              )
            )
          )
        )
      ),
    ),
    'ui' => array(
      'title' => '外观',
      'sections' => array(
        'color' => array(
          'title' => '颜色设置',
          'options' => array(
            'schemes' => array(
              'label' => '颜色主题',
              'type' => 'color_schemes',
              'default' => 'default',
              'description' => '若选择“自定义CSS”，请打开<code>网站根目录/plugin/abs_theme_flano/assets/css/theme/custom.css</code>进行修改。',
              'choices' => array(
                'default' => array(
                  'label' => '默认',
                  'colors' => array('#222', '#5B8EFF', '#9c4dff', '#fff')/* 文字，主要，次要，背景 */
                ),
                'vapor' => array(
                  'label' => '霓虹',
                  'colors' => array('#32fbe2', '#6f42c1', '#ea39b8', '#1a0933')
                ),
                'slate' => array(
                  'label' => '静谧',
                  'colors' => array('#aaa', 'linear-gradient(#484e55, #3a3f44 60%, #313539)', 'linear-gradient(#101112,#17191b 40%,#1b1e20)', '#272b30')
                ),
                'midnight' => array(
                  'label' => '午夜',
                  'colors' => array('#adafae', '#2a9fd6', '#060606')
                ),
                'lite_red' => array(
                  'label' => '清新红',
                  'colors' => array('#656D78', '#FD6565', '#f7f7f7', '#fff')
                ),
                'lite_green' => array(
                  'label' => '清新绿',
                  'colors' => array('#656D78', '#31C177', '#f7f7f7', '#fff')
                ),
                'lite_blue' => array(
                  'label' => '清新蓝',
                  'colors' => array('#656D78', '#08f', '#f7f7f7', '#fff')
                ),
                'red' => array(
                  'label' => '红色',
                  'colors' => array('#adafae', '#FD6565', '#FFD3A5', '#fafafa')
                ),
                'orange' => array(
                  'label' => '橙色',
                  'colors' => array('#555', '#f93', '#F2F2F2')
                ),
                'tea' => array(
                  'label' => '茶色',
                  'colors' => array('#000', 'linear-gradient(to bottom,#5b6289,#30385c)', '#eee6cb', '#f8f0dd')
                ),
                'crafty' => array(
                  'label' => '小镇',
                  'colors' => array('#8c6235', '#689232', '#e0c287', '#feb')
                ),
                'sky' => array(
                  'label' => '天空',
                  'colors' => array('#444', '#4CBEE0', '#F0F1F5')
                ),
                'mint' => array(
                  'label' => '薄荷',
                  'colors' => array('#555e5d', '#8cd5cc', '#5fbdc9', '#fafafa')
                ),
                'blue' => array(
                  'label' => '蓝色',
                  'colors' => array('#444', '#08f', '#f7f7f7')
                ),
                'yukari' => array(
                  'label' => '紫色',
                  'colors' => array('#726D7B', '#531dad', '#fff')
                ),
                'pink' => array(
                  'label' => '粉色',
                  'colors' => array('#444', '#FD4C86', '#fd8d4c', '#F8F9FB')
                ),
                'nutshell' => array(
                  'label' => '过客',
                  'colors' => array('#4C4C4C', '#2ea1cf', '#85C155', '#fff')
                  /* 纪念果壳小组 */
                ),
                'custom' => array(
                  'label' => '自定义CSS',
                  'colors' => array('var(--dark)', 'var(--primary)', 'var(--secondary)', 'var(--light)'),
                ),
              )
            )
          )
        )
      ),
    ),
    'others' => array(
      'title' => '帮助·关于',
      'sections' => array(
        'help' => array(
          'title' => '帮助',
          'options' => array(
            'forumcolor' => array(
              'label' => '如何给论坛板块上色？',
              'default' => '点击后台“板块”菜单项，找到想要更改颜色的板块，点击“编辑”，然后在“颜色”框里输入颜色值。颜色值可以通过Photoshop或GIMP或F12工具或QQ截图工具获得。',
              'type' => 'label'
            ),
            'customstyle' => array(
              'label' => '如何使用“自定义CSS”颜色主题？',
              'default' => '这项是为有一定CSS基础的人使用的。选择此项后，通过FTP或服务器管理面板的“文件管理器”找到并打开<code>网站根目录/plugin/abs_theme_flano/assets/css/theme/custom.css</code>，修改其中的变量值后保存回服务器即可看到颜色更新。同时，该文件也适合存放自定义的CSS样式，您可以拷贝其他颜色主题里的内容到这个文件里。',
              'type' => 'label',
              'description' => '如果您认为自己没有CSS经验，请看完<a href="http://c.biancheng.net/css3/">这个系列教程</a>再尝试。'
            )
          ),
        ),
        'about' => array(
          'title' => '关于本主题',
          'options' => array(
            'authors' => array(
              'label' => '作者',
              'type' => 'label',
              'default' => '<a href="https://www.geticer.eu.org">Geticer</a>、Tillreetree'
            ),
            'homepage' => array(
              'label' => '主页（获取新版）',
              'type' => 'label',
              'default' => '<a href="https://xiunobbs.cn/thread-3638.htm" class="btn btn-outline-primary">点击进入</a>',
            ),
          ),
        ),
      ),
    ),
  ),
  'kumquat_config' => array( /* 金桔框架——框架设置 */
    'allow_delete_plugin_settings' => true, /* 允许删除插件设置 */
    'allow_reset_settings' => true, /* 允许重置插件设置 */
  ),
  'kumquat_flag' => array( /* 金桔框架——标志；除非有必要，否则勿动 */
    'delete_plugin_settings' => false, /* 删除插件设置，若为true则会在卸载时删除插件设置 */
    'reset_settings' => false, /* 重置插件设置，若为true则重置 */
  ),
  'THIS_LOCATION_FRONTEND' => './' . PLUGIN_DIR,/* 该插件的位置，不需要动 */
  'THIS_LOCATION' => PLUGIN_DIR,/* 该插件的位置，不需要动 */
);
/* 【结束】配置 */