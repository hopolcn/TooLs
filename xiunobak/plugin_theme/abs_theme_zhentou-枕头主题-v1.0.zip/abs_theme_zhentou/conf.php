<?php
/* 【开始】配置 */

$data = array(
  'panels' => [
    'ui' => [
      'title' => '外观',
      'sections' => [
        'color' => [
          'title' => '颜色',
          '_cols' => 2,
          'options' => [
            'accent_color' => [
              'label' => '主色调',
              'description' => '用于主要操作按钮',
              'type' => 'color',
              'default' => '#6A4EE9',
            ],
            'decoration_color' => [
              'label' => '副色调',
              'description' => '用于次要操作按钮和点缀元素',
              'type' => 'color',
              'default' => '#FF2AAC',
            ],
            'background_color' => [
              'label' => '页面背景颜色',
              'type' => 'color',
              'default' => '#FAF8FF',
            ],
            'boxes_background_color' => [
              'label' => '容器背景颜色',
              'type' => 'color',
              'default' => '#ffffff',
            ],
            'general_border_color' => [
              'label' => '全局边框颜色',
              'type' => 'color',
              'default' => '#E9E8FF',
            ],
            'boxes_border_color' => [
              'label' => '容器边框颜色',
              'type' => 'color',
              'default' => '#E9E8FF',
            ],
            'body_color' => [
              'label' => '文字颜色',
              'type' => 'color',
              'default' => '##282424',
            ],
            'muted_color' => [
              'label' => '次要文字颜色',
              'type' => 'color',
              'default' => '#4D6385',
            ],
            'ref' => [
              'label' => '配色抄作业',
              'type' => 'label',
              'default' => nl2br("复制颜色代码到以上颜色选择框中即可。
              # 浅色：

              ## 默认：
               css
              主色调: #6a4ee9;
              副色调: #ff2aac;
              页面背景颜色: #faf8ff;
              容器背景颜色: #ffffff;
              全局边框颜色: #e9e8ff;
              容器边框颜色: #e9e8ff;
              文字颜色: #000000;
              次要文字颜色: #4d6385;
               
              ## 薰衣草：
               css
              主色调: #8e44ad; 
              副色调: #64b5f6; 
              页面背景颜色: #f8f9fa; 
              容器背景颜色: #ffffff; 
              全局边框颜色: #dee2e6; 
              容器边框颜色: #dee2e6; 
              文字颜色: #333333; 
              次要文字颜色: #748899; 
               
              ## 珊瑚：
               css
              主色调: #ff6f61;
              副色调: #ffc107; 
              页面背景颜色: #fcfcfc; 
              容器背景颜色: #ffffff; 
              全局边框颜色: #e9ecef; 
              容器边框颜色: #e9ecef; 
              文字颜色: #333333; 
              次要文字颜色: #6c757d; 
               
              ## 薄荷：
               css
              主色调: #4caf50; 
              副色调: #5fb7c5; 
              页面背景颜色: #f1f3f5; 
              容器背景颜色: #ffffff; 
              全局边框颜色: #d1ecf1; 
              容器边框颜色: #d1ecf1; 
              文字颜色: #333333; 
              次要文字颜色: #6c757d; 
               
              ## 极地：
               css
              主色调: #86ace9; 
              副色调: #8da3b6; 
              页面背景颜色: #f0f8ff; 
              容器背景颜色: #ffffff; 
              全局边框颜色: #e6faff; 
              容器边框颜色: #e6faff; 
              文字颜色: #333333; 
              次要文字颜色: #6c757d; 
               
              深色：
              
              ## 默认：
               css
              主色调: #6a4ee9; 
              副色调: #ff2aac; 
              页面背景颜色: #121212;
              容器背景颜色: #1c1c1c; 
              全局边框颜色: #333333; 
              容器边框颜色: #333333; 
              文字颜色: #ffffff; 
              次要文字颜色: #aaaaaa; 
               
              ## 海洋：
               css
              主色调: #0abde3;
              副色调: #feca57; 
              页面背景颜色: #000026; 
              容器背景颜色: #000046; 
              全局边框颜色: #1a1a3c; 
              容器边框颜色: #1a1a3c;
              文字颜色: #eee5d2; 
              次要文字颜色: #9999cc;
               
              ## 竹林：
               css
              主色调: #2ecc71; 
              副色调: #48604b; 
              页面背景颜色: #0d1117; 
              容器背景颜色: #161b22; 
              全局边框颜色: #21262d; 
              容器边框颜色: #21262d; 
              文字颜色: #c5daca; 
              次要文字颜色: #82b288; 
               
              ## 薰衣草：
               css
              主色调: #9b59b6; 
              副色调: #e67e22;
              页面背景颜色: #101214; 
              容器背景颜色: #1b1e21; 
              全局边框颜色: #36393f; 
              容器边框颜色: #36393f; 
              文字颜色: #ffffff; 
              次要文字颜色: #888888; 
              "),
            ],
          ],
        ],
      ],
    ],
    'custom_content' => [
      'title' => '自定义内容',
      'sections' => [
        'homepage_hero' => [
          'title' => '主页-开场白',
          'options' => [
            'enable' => [
              'label' => '显示该部分？',
              'type' => 'toggle',
              'default' => true,
            ],
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '欢迎来到' . $conf['sitename'] . '！',
            ],
            'content' => [
              'label' => '内容',
              'type' => 'html',
              'default' => '<p>登录后探索更多精彩内容！</p>'
            ],
            'image' => [
              'label' => '图片地址',
              'description' => '输入图片的网址包含“http(s)://”前缀。亦可输入相对路径。',
              'type' => 'text',
              'default' => $HTTP_TYPE . str_replace('/admin', '', WEBSITE_DIR) . PLUGIN_DIR . 'assets/about.webp'
            ],
          ],
        ],
        'homepage_hot_forums' => [
          'title' => '主页-热门分类',
          'options' => [
            'enable' => [
              'label' => '显示该部分？',
              'type' => 'toggle',
              'default' => true,
            ],
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '⚡ 热门分类',
            ],
          ],
        ],
        'all_forums' => [
          'title' => '页面-所有分类',
          'options' => [
            'title' => [
              'label' => '标题',
              'type' => 'text',
              'default' => '所有分类',
            ],
            'content' => [
              'label' => '内容',
              'type' => 'html',
              'default' => ''
            ],
          ],
        ],
        'auth' => [
          'title' => '页面-登录、注册、找回密码',
          'options' => [
            'image' => [
              'label' => '图片地址',
              'description' => '输入图片的网址包含“http(s)://”前缀。亦可输入相对路径。',
              'type' => 'text',
              'default' => $HTTP_TYPE . str_replace('/admin', '', WEBSITE_DIR) . PLUGIN_DIR . 'assets/bridge.webp'
            ],
          ],
        ],
      ],

    ],
  ],
  'kumquat_config' => [ /* 金桔框架——框架设置 */
    'allow_delete_plugin_settings' => true, /* 允许删除插件设置 */
    'allow_reset_settings' => false, /* 允许重置插件设置 */
    'show_all_vars_table' => true, /* 显示“全部变量”框，只在调试模式显示 */
  ],
  'kumquat_flag' => [ /* 金桔框架——FLAG；保存在插件设置中，除非有必要，否则勿动 */
    'delete_plugin_settings' => true, /* 删除插件设置，若为true则会在卸载时删除插件设置 */
    'reset_settings' => false, /* 重置插件设置，若为true则重置 */
  ],

);

/* 【结束】配置 */