case'bbs':
include _include(APP_PATH.'plugin/abs_theme_zhentou/route/bbs.php');
break;
