<?php
!defined('DEBUG') AND exit('Access Denied.');

include _include(APP_PATH . 'plugin/abs_theme_zhentou/view/htm/bbs.htm');
