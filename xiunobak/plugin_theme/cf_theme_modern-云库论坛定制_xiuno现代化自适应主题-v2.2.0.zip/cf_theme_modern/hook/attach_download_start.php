<?php
exit;
$method != 'GET' AND message(-1,lang('method_error'));