<?php
exit;
'cf_theme_modern'=>'现代化主题', 