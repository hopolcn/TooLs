<?php
exit;
$agreebbrule_url=empty($cf_theme_modern['agreebbrule_url'])?'':$cf_theme_modern['agreebbrule_url'];