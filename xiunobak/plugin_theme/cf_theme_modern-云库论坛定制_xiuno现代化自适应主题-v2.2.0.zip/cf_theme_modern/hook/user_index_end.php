<?php
exit;
$header['title'] = $_user['username'].lang('de').lang('homepage').' - '.$conf['sitename'];
$header['mobile_title'] = $_user['username'].lang('de').lang('homepage').' - '.$conf['sitename'];
