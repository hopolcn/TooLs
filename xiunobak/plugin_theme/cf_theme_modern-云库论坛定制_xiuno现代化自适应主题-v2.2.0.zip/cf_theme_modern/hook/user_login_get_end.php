<?php
exit;
$register_img_url=empty($cf_theme_modern['register_img_url'])?'plugin/cf_theme_modern/img/register_tips.png':$cf_theme_modern['register_img_url'];