<?php
exit;
$method != 'POST' AND message(-1,lang('method_error'));