<?php
exit;
$method != 'GET' AND message(-1,lang('trigger_xss_protection'));