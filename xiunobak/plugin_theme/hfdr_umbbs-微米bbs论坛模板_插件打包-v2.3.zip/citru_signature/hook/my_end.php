elseif($action == 'citru_signature') {

if($method == 'GET') {

include _include(APP_PATH.'plugin/citru_signature/view/my_signature.htm');

} elseif($method == 'POST') {

$signature = param('signature');

 empty($signature) AND message(-1, '不可以为空');
	xn_strlen($signature,"utf-8") > 20 AND message(-1, '不可以超过20个字'); 	
		

$r = user_update($uid, array('signature' => $signature));
$r === FALSE AND message(-1, '修改失败！');

message(0, '保存成功！');

}
}