<?php

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$r = db_exec("alter table {$tablepre}user add signature VARCHAR(255) default 'Ta很懒，什么签名也没有哦'");
$r === FALSE AND message(-1, '创建表结构失败'); // 中断，安装失败。

?>