<?php

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$r = db_exec("alter table {$tablepre}user drop signature");


?>