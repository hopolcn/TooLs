case 'plate': include _include(APP_PATH.'plugin/hfdr_umbbs/route/plate.php'); break;
case 'plate': include _include(APP_PATH.'plugin/hfdr_umbbs/route/?plate.php'); break;