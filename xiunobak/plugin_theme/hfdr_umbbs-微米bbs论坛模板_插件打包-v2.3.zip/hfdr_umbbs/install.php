<?php

/*

*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}themegame (
  themegameid bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  rank smallint(11) NOT NULL DEFAULT '0',
   formid char(64) NOT NULL DEFAULT '',
  name char(32) NOT NULL DEFAULT '',
  viewnum char(64) NOT NULL DEFAULT '',
  icoimg varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (themegameid)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8
";
$r = db_exec($sql);
$sql = "INSERT INTO {$tablepre}themegame SET rank='2', icoimg='home',  name='版主推荐', formid=' 1 2 3', viewnum='12'";
$r = db_exec($sql);
$sql = "INSERT INTO {$tablepre}themegame SET rank='1', icoimg='home', name='最新游戏', formid=' 4 5 6 7', viewnum='4'";
$r = db_exec($sql);
$sql = "INSERT INTO {$tablepre}themegame SET rank='0', icoimg='home', name='实时资讯', formid=' 6 7', viewnum='6'";
$r = db_exec($sql);
?>