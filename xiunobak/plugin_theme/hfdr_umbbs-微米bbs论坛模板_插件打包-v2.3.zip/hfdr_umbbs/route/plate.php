<?php
!defined('DEBUG') AND exit('Access Denied.');
include APP_PATH.'plugin/hfdr_umbbs/view/plate.htm';
?>
