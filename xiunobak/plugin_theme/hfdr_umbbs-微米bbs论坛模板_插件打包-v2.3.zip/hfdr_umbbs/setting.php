<?php

/*

*/

!defined('DEBUG') AND exit('Access Denied.');

$action = param(3);

if(empty($action)) {
	
	$themegamelist = db_find('themegame', array(), array('rank'=>-1), 1, 1000, 'themegameid');
	$maxid = db_maxid('themegame', 'themegameid');
	
	if($method == 'GET') {
		
		$config = kv_get('links_show');
		include _include(APP_PATH.'plugin/hfdr_umbbs/setting.htm');
		
	} else {
		
		$rowidarr = param('rowid', array(0));
		$icoimgarr = param('icoimg', array(''));
		$namearr = param('name', array(''));
		$formidarr = param('formid', array(''));
		$viewnumarr = param('viewnum', array(''));
		$rankarr = param('rank', array(0));
		
		$arrlist = array();
		foreach($rowidarr as $k=>$v) {
			if(empty($icoimgarr[$k]) && empty($namearr[$k]) && empty($formidarr[$k]) && empty($viewnumarr[$k])&& empty($picheightarr[$k]) && empty($rankarr[$k])) continue;
			$arr = array(
				'themegameid'=>$k,
				'icoimg'=>$icoimgarr[$k],
				'name'=>$namearr[$k],
				'formid'=>$formidarr[$k],
				'viewnum'=>$viewnumarr[$k],
				'rank'=>$rankarr[$k],
			);
			if(!isset($themegamelist[$k])) {
				db_create('themegame', $arr);
			} else {
				db_update('themegame', array('themegameid'=>$k), $arr);
			}
		}
		$config['show_yes'] = param('show_yes');
		$config['show_tuione'] = param('show_tuione');
		$config['show_tuitwo'] = param('show_tuitwo');
		$config['show_sign'] = param('show_sign');
		$config['show_logo'] = param('show_logo');
		$config['show_number'] = param('show_number');
		kv_set('links_show', $config);

		
		// 删除
		$deletearr = array_diff_key($themegamelist, $rowidarr);
		foreach($deletearr as $k=>$v) {
			db_delete('themegame', array('themegameid'=>$k));
		}
		
		message(0, '保存成功');
	}
}
?>