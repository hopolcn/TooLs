<?php

/*
	Xiuno BBS 4.0 拓展设置
*/

!defined('DEBUG') AND exit('Forbidden');


?>