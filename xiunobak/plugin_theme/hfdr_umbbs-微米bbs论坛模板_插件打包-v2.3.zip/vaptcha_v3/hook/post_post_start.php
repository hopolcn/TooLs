include APP_PATH.'plugin/vaptcha_v3/util/validate.php';
validate('quick_reply');
