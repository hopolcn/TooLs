<?php

/*
	Xiuno BBS 4.0 大白小镇风格
*/

!defined('DEBUG') AND exit('Forbidden');








?>