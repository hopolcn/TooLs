<?php
/* 【开始】配置 */

$data = array(
  'panels' => [
    'ui' => [
      'title' => '外观',
      'sections' => [
        'global' => [
          'title' => '全局',
          'options' => [
            'container_width' => [
              'label' => '页面内容宽度',
              'description' => '在移动端为100%宽度',
              'type' => 'select',
              'default' => 'lg',
              'choices' => [
                'sm' => '更窄（540px）',
                'md' => '窄（720px）',
                'lg' => '中等（960px）',
                'xl' => '宽（1140px）',
                'xxl' => '更宽（1320px）',
              ],
            ],
          ],
        ],
        'topimg' => [
          'title' => '头图',
          'options' => [
            'mode' => [
              'label' => '头图展示模式',
              'description' => '当选择“多张随机”模式时，请将所有希望展示的图片放在<code>plugin/msto_theme_VerdantZen/view/img/topimg/</code>中；<br>如果希望使用第三方的随机图片API服务，请选择“单张”模式，然后在“头图地址”中输入随机图片API网址。',
              'type' => 'select',
              'default' => 'single',
              'choices' => [
                'single' => '单张',
                'random' => '多张随机'
              ],
            ],
            'img_src' => [
              'label' => '头图地址',
              'description' => '仅对于“单张”模式有效',
              'type' => 'text',
              'default' => 'plugin/msto_theme_VerdantZen/view/img/start.png'
            ],
            'img_alt' => [
              'label' => '头图描述文字',
              'description' => '将鼠标放在上面可看到该文字',
              'type' => 'text',
              'default' => 'Hello, world!'
            ],
            'img_href' => [
              'label' => '头图跳转网址',
              'description' => '输入<code>.</code>为网站主页',
              'type' => 'text',
              'default' => './'
            ],
            'img_height' => [
              'label' => '头图高度',
              'description' => '单位为像素；注意：图片会填满整个空间，而不会被拉伸。同时，图片会对齐到左上角。',
              'type' => 'number',
              'default' => 200,
              'min' => 16,
              'max' => 2048,
              'step' => 1
            ],
          ],
        ],
        'homepage' => [
          'title' => '首页',
          'options' => [
            'show_sitebrief' => [
              'label' => '显示站点介绍？',
              'type' => 'toggle',
              'default' => false,
            ],
          ],
        ],
        'threadlist' => [
          'title' => '帖子列表',
          'options' => [
            'style' => [
              'label' => '样式',
              'type' => 'select',
              'default' => 'compact',
              'choices' => [
                'compact' => '紧凑',
                'classic' => '经典',
                'graphic_list_horizontal' => '图文列表（横向）',
                'graphic_list_vertical' => '图文列表（纵向）',
              ],
            ]
          ],
        ],
      ],
    ],
  ],
  'kumquat_config' => [ /* 金桔框架——框架设置 */
    'allow_delete_plugin_settings' => true, /* 允许删除插件设置 */
    'allow_reset_settings' => true, /* 允许重置插件设置 */
    'show_all_vars_table' => true, /* 显示“全部变量”框，只在调试模式显示 */
  ],
  'kumquat_flag' => [ /* 金桔框架——FLAG；保存在插件设置中，除非有必要，否则勿动 */
    'delete_plugin_settings' => false, /* 删除插件设置，若为true则会在卸载时删除插件设置 */
    'reset_settings' => false, /* 重置插件设置，若为true则重置 */
  ],
);

/* 【结束】配置 */

