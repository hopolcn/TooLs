<?php exit;

case 'topimgapi': include _include(APP_PATH.'plugin/msto_theme_VerdantZen/route/topimgapi.php'); break;