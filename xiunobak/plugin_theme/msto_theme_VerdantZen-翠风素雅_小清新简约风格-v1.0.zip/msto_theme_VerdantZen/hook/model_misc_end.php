

function bootstrap_breakpoint_name_to_grid_columns($key) {  
    $map = [  
        'sm' => 12,  
        'md' => 6,  
        'lg' => 4,  
        'xl' => 3, 
        'xxl' => 3, 
        'xxxl' => 2,
        'x4k' => 2,
    ];  
    if (array_key_exists($key, $map)) {  
        return $map[$key];  
    } else {  
        // throw new Exception("Unknown Bootstrap breakpoint: $key");  
        return 12; 
    }  
}

