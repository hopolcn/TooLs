<?php

/*
	金桔框架——插件安装
	admin/plugin-install-PLUGIN_NAME.htm
*/

!defined('DEBUG') and exit('Forbidden');

/* 【开始】金桔框架——常量定义 */

$BASE_URL = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$BASE_URL = empty($BASE_URL) ? '/' : '/' . trim($BASE_URL, '/') . '/';

define('WEBSITE_DIR', $_SERVER["HTTP_HOST"] . $BASE_URL);
define('PLUGIN_DIR', 'plugin/' . param(2) . '/');
define('PLUGIN_NAME', param(2));
$plugin_profile_file = file_get_contents(APP_PATH . PLUGIN_DIR . 'conf.json');
$PLUGIN_PROFILE = json_decode($plugin_profile_file, true);
$PLUGIN_SETTING = setting_get(PLUGIN_NAME . '_setting');
include_once(APP_PATH . PLUGIN_DIR . 'conf.php');


/* 【结束】金桔框架——常量定义 */

/**
 * 金桔框架——初始化设置
 * @param array $data 要导入的设置数组。
 * @return array 每一个设置项
 */
function kumquat_setting_init($data) {
	$setting = array();
	if (!isset($data['panels'])) {
		return $setting;
	} else {
		foreach ($data['panels'] as $panel => $value) {
			#$controller_name_panel = $panel;
			foreach ($value['sections'] as $section => $value) {
				#$controller_name_section = $controller_name_panel.'/'.$section;
				foreach ($value['options'] as $option => $control) {
					#$controller_name = $controller_name_section.'/'.$option;
					if (isset($control['default'])) {
						$setting[$panel][$section][$option] = $control['default'];
						#$setting[$controller_name] = $control['default'];
					} else {
						$setting[$panel][$section][$option] = 0;
						#$setting[$controller_name] = 0;
					}
				}
			}
		}
	}
	$setting['THIS_LOCATION_FRONTEND'] = WEBSITE_DIR . PLUGIN_DIR;
	$setting['THIS_LOCATION'] = PLUGIN_DIR;
	$setting['kumquat_flag'] = $data['kumquat_flag'];
	return $setting;
}

if (empty($PLUGIN_SETTING)) {
	$setting = kumquat_setting_init($data);
	setting_set(PLUGIN_NAME . '_setting', $setting);
}