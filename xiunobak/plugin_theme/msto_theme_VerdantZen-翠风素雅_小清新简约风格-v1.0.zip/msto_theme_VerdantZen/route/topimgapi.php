<?php
const DS = DIRECTORY_SEPARATOR;
if (!defined('APP_PATH')) {
    define('APP_PATH','..' . DS . '..' . DS . '..' . DS);
}
$TOPIMG_PATH = APP_PATH . 'plugin' . DS . 'msto_theme_VerdantZen' . DS . 'view' . DS . 'img' . DS . 'topimg' . DS;

// 1. 读取目录下的所有文件和文件夹  
$files = scandir($TOPIMG_PATH);  
  
// 2. 过滤掉特殊文件和文件夹  
$images = array_filter($files, function($file) use ($TOPIMG_PATH) {  
    return !in_array($file, ['.', '..']) && is_file($TOPIMG_PATH . $file) && preg_match('/\.(jpg|jpeg|png|gif|webp|avif)$/i', $file);  
});  
  
// 如果没有图片，则直接退出  
if (empty($images)) {  
    $image = imagecreatetruecolor(145, 20);  
  
    $white = imagecolorallocate($image, 255, 255, 255); 
    $red = imagecolorallocate($image, 255, 0, 0);  
  
    imagefill($image, 0, 0, $white);  
  
    $fontNumber = 5; // 内置字体编号，这个编号可能因环境而异  
  
    // 添加文字  
    imagestring($image, $fontNumber, 1, 1, 'No images found.', $red);  
  
    header('Content-Type: image/png');  
  
    imagepng($image);  
  
    imagedestroy($image);  
  
    exit;  
}  
  
// 3. 随机选择一个图片  
$randomImage = $images[array_rand($images)];  
// 4. 获取图片MIME类型  
$finfo = finfo_open(FILEINFO_MIME_TYPE); // 返回 mime 类型  
$mimeType = finfo_file($finfo, $TOPIMG_PATH . $randomImage);  
finfo_close($finfo);  

// 5. 设置HTTP响应头  
header('Content-Type: ' . $mimeType);  

// 6. 读取并输出图片内容  
readfile($TOPIMG_PATH . $randomImage);  