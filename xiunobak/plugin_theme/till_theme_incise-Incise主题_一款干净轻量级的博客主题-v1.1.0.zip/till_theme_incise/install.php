<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件安装
	admin/plugin-install-till_theme_incise.htm
*/

!defined('DEBUG') and exit('Forbidden');

$setting = setting_get('till_theme_incise_setting');
if (empty($setting)) {
	$setting = array(
		'cover_image' => '',
		'footer_copyright' => 'Powered by Xiuno BBS',
		'post_meta_template' => '由 %1$s 于 %2$s 发布在 %3$s',
		'threadlist_cols' => 'one',
		'threadlist_border' => true,
		'post_excerpt_length' => 140,
	);
	setting_set('till_theme_incise_setting', $setting);
}