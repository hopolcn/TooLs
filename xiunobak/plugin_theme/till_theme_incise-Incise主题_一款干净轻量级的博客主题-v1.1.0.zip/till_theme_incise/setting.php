<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件设置
	admin/plugin-setting-till_theme_incise.htm
*/

!defined('DEBUG') and exit('Access Denied.');

$setting = setting_get('till_theme_incise_setting');

if ($method == 'GET') {

	$input = array();
	$input['cover_image'] = form_text('cover_image', $setting['cover_image']);
	$input['footer_copyright'] = form_text('footer_copyright', $setting['footer_copyright']);
	$input['post_meta_template'] = form_text('post_meta_template', $setting['post_meta_template']);
	$input['threadlist_cols'] = form_radio('threadlist_cols', array('one' => '一列', 'two' => '两列'), $setting['threadlist_cols']);
	$input['threadlist_border'] = form_radio_yes_no('threadlist_border', $setting['threadlist_border']);
	$input['post_excerpt_length'] = form_text('post_excerpt_length', $setting['post_excerpt_length']);

	include _include(APP_PATH . 'plugin/till_theme_incise/setting.htm');
} else {

	$setting['cover_image'] = param('cover_image', '', FALSE);
	$setting['footer_copyright'] = param('footer_copyright', '', FALSE);
	$setting['post_meta_template'] = param('post_meta_template', '', FALSE);
	$setting['threadlist_cols'] = param('threadlist_cols', '', FALSE);
	$setting['threadlist_border'] = param('threadlist_border', '', FALSE);
	$setting['post_excerpt_length'] = param('post_excerpt_length', 0);

	setting_set('till_theme_incise_setting', $setting);

	message(0, '修改成功');
}