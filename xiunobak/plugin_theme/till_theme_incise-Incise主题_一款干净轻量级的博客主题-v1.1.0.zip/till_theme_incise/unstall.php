<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件卸载
	admin/plugin-unstall-till_theme_incise.htm
*/

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('till_theme_incise_setting');
