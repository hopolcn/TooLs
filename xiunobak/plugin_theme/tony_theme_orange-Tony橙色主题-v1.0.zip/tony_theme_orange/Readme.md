 # Xiuno BBS 4.0 插件：Tony 橙色主题
 
 * Desc:Xiuno BBS 4.0 插件实例：Tony 橙色主题   plugin/plugin-setting-tony_theme_orange
 * Author: Tony
 * Blog: www.abmbio.xin
 * Date: 2018-07-31
 
 ### 安装：
 1、 上传文件夹tony_theme_orange到xiuluo BBS的plugin中
 2、 登入后台进入本地插件，点击安装即可
 
 ### Q & A
 1、 点击安装，显示安装成功了，但是后台没有任何动作？
 
 -- 请确保tony_theme_orange的conf.json可写
 ```shell
 chmod 777 conf.json
 ```
 
 2、 修改局部显示效果，前台并无任何变化？
 
 --  请检查是否刷新了缓存