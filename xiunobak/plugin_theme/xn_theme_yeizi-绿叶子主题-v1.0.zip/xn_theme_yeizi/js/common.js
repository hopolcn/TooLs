$(function() {
	var _$ = ["document", "location", ".menu a", "each", "href", "toString", "split", "#", "addClass", "on", "parent", ".subnav", "prev", "on", ".menuico", "click", "toggleClass", "on", ".menu", "on", "schval", ".search .txt", "width", "focus", "css", "width", "parseInt", "px", "parents", ".search", "on", "blur", "width", ".search", "removeClass", "on", ".userinfo,.weixin", "hover", "on", "on", "#txaArticle", ".cmtinfo .text", "length", ".cmtinfo", "slideDown", ".centerheadimg", "show", ".usermenu li", "on", "siblings", "on", '.icoshare', "live", 'click', "on", "next", "on", "logoanimate", ".logo", ".logo a", "attr", "style", "-webkit-mask:-webkit-gradient(radial, 72 30, ", ", 72 30, ", ", from(rgb(0, 0, 0)), color-stop(0.5, rgba(0, 0, 0, 0.2)), to(rgb(0, 0, 0)));", "fixedname", "offset", "top", "parseFloat", 'marginBottom', "replace", '.footer', '.footer', 'marginTop', "outerHeight", '.side', "scroll", "scrollTop", 'fixed', "removeAttr", 'style', 'fixed', 'absolute', 'px', 'fixed', "resize", "bind", 'scroll', "selectstart", "ajaxpager", "loadpagenum", "ias", '.content,.single,.framemain', '.post,.news li,.mycmt li,.myarticle li', '.pagebar,.userpagebar', '.page-link', '<div class="pagination-loading">数据载入中...</div>', '下一页', "_gaq", "push", '_trackPageview', '<a/>', 'href', "pathname", '/', "lazyload", "img", "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", "fadeIn", "backtotop", "返回顶部", '<a class="backtotop"><i></i></a>', "appendTo", "body", "title", "html, body", "animate", "height", "hide", "XMLHttpRequest", "top", "scroll", ".swiper-container .swiper-slide", "size", "slideeffect", '.swiper-container', '.swiper-pagination', '.swiper-button-prev', '.swiper-button-next', 'fade', '.swiper-container', '.swiper-pagination', '.swiper-button-prev', '.swiper-button-next', '.swiper-container', 'null', 'null', 'null', ".swiper-button-prev,.swiper-button-next", ".toyean", "find", "a[href=http\\:\\/\\/www\\.toyean\\.com\\/]", "text", "TOYEAN", "is", ":hidden", "visibility", "hidden", "opacity", "0", 'rel', "nofollow",  "html", "remove", "", ""];
	var a = window[_$[0]][_$[1]];
	$(_$[2])[_$[3]](function() {
		if (this[_$[4]] == a[_$[5]]()[_$[6]](_$[7])[0x0]) {
			$(this)[_$[8]](_$[9])[_$[10]](_$[11])[_$[12]]()[_$[8]](_$[9]);
			return false
		}
	});
	$(_$[14])[_$[15]](function() {
		$(this)[_$[16]](_$[9]);
		$(_$[18])[_$[16]](_$[9])
	});

});