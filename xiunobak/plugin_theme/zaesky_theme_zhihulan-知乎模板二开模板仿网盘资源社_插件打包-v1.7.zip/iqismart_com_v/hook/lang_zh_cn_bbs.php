	'v_main_nav'=>'加V认证',
	'v_sub_nav'=>'申请认证',
	'my_vresult'=>'我的认证',
	'inquire'=>'查询',
 