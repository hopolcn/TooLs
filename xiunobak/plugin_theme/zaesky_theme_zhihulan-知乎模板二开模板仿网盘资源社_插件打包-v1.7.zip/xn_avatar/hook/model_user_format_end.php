	
	$user['avatar_auto'] AND $user['avatar_url'] = $user['avatar_auto'] ;
