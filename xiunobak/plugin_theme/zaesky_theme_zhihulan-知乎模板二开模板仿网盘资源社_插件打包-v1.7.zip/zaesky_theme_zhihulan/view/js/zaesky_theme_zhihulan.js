// 导航条
$(function(){
var nav=$("#nav_pc_2"); //得到导航对象
var win=$(window); //得到窗口对象
var sc=$(document);//得到document文档对象。
win.scroll(function(){
  if(sc.scrollTop()>=55){
    nav.addClass("nav_pc_2"); 
   $(".navTmp").fadeIn(); 
  }else{
   nav.removeClass("nav_pc_2");
   $(".navTmp").fadeOut();
  }
})  
})


// 帖子列表hover
function   openThread(tid){
location.href='thread-'+tid+'.htm';
return false;
}
$(function(){
$('.threadclick').bind('mouseover',function(){
    $(this).css('background-color','#f1f1f1');
      $(this).css('border-left',' 2px solid #0084ff');
})
  $('.threadclick').bind('mouseout',function(){
    $(this).css('background-color','');
      $(this).css('border-left',' 2px solid #FFF');
})
  $("input[type='checkbox']").click(function(e){
    e.stopPropagation(); 
});
  
})  
 console.log("\n %c Copyright © 2023 资源否二开 %c | www.zyfou.com %c | 一次购买，永久更新 ", "color:#fff;background:#3983e2;padding:5px 0;", "color:#eee;background:#ffbd4a;padding:5px 10px;", "color:#fff;background:#3983e2;padding:5px 0;");