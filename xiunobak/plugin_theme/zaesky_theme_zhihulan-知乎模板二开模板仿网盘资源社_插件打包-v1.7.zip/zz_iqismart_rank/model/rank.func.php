<?php
function get_site_new_user1($num=16){
	$userlist =cache_get('get_site_new_user');
	if(empty($userlist)){
		$userlist =db_find('user',array(),array('uid'=>-1),1,$num,'uid');
		foreach ($userlist as &$user) {
			$username =$user['username'];
			xn_strlen($username)>4 &&$username =xn_substr($username,0,4);
			$user['dname'] =$username;
		}
		cache_set('get_site_new_user',$userlist,600);
	}
	return $userlist;
}

function get_site_sort_user($num=16,$sort){
	$userlist =cache_get('get_site_'.$sort.'_user');
	if(empty($userlist)){
		$userlist =db_find('user',array(),array($sort=>-1),1,$num,'uid');
		foreach ($userlist as &$user) {
			$username =$user['username'];
			xn_strlen($username)>4 &&$username =xn_substr($username,0,4);
			$user['dname'] =$username;
		}
		cache_set('get_site_'.$sort.'_user',$userlist,86400);
	}
	return $userlist;
}
?>