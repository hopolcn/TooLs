<?php exit;
    global $time;
    $todaystarttime = strtotime(date('Y-m-d', $time));
    $runtime['todayusers'] = user_count(array('create_date'=>array('>'=>$todaystarttime)));
    $runtime['todayposts'] = post_count(array('create_date'=>array('>'=>$todaystarttime)));
    $runtime['todaythreads'] = thread_count(array('create_date'=>array('>'=>$todaystarttime)));
    $runtime['todayposts'] -= $runtime['todaythreads'];
    $runtime['cron_1_last_date'] = $todaystarttime;
    $runtime['cron_2_last_date'] = $todaystarttime;
    cache_set('runtime', $runtime);
?>