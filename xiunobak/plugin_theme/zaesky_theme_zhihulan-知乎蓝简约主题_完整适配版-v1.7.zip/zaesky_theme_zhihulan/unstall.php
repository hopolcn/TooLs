<?php

/*
	Xiuno BBS 4.0 知乎蓝简约主题
*/

!defined('DEBUG') AND exit('Forbidden');


?>