<?php

/*
	Xiuno BBS 4.0 插件实例：广告插件卸载
	admin/plugin-unstall-xn_ad.htm
*/

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('xn_ad_setting');

?>