<?php

!defined('DEBUG') AND exit('Forbidden');

kv_delete('mobile_setting');

?>