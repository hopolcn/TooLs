case 'index': 	include _include(APP_PATH.'plugin/xn_nav_2/route/index.php'); 	break;
case 'bbs': 	include _include(APP_PATH.'route/index.php'); 		break;