<?php
exit;

150 => array(
	'url' => url('my-notice-150'), 
	'name' => lang('haya_post_like_notice'),
	'class' => 'success',
	'icon' => ''
),

?>