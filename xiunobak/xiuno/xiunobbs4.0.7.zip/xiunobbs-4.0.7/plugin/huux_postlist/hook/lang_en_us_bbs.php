	'huux_postlist_sort_asc'=>'Positive sequence',
	'huux_postlist_sort_desc'=>'Reverse order',
	'huux_postlist_all'=>'Look at all',
	'huux_postlist_author'=>'Look at author',