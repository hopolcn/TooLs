<?php

/*
	Xiuno BBS 4.0 大白插件
	http://www.huux.cc
*/

!defined('DEBUG') AND exit('Forbidden');








?>