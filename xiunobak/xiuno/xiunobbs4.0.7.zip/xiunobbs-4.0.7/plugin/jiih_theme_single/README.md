# jiih_theme_single
single theme for xiuno bbs 4.0

## 演示

单栏首页：
![image](https://raw.githubusercontent.com/jiix/jiih_theme_single/master/screenshot.png)

板块列表：
![1057402836](https://raw.githubusercontent.com/jiix/jiih_theme_single/master/screenshot2.png)

帖子页：
![image](https://raw.githubusercontent.com/jiix/jiih_theme_single/master/screenshot3.png)